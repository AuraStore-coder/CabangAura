# Aura Cabang Pro 2.0.0

Launcher yang membuka aplikasi cabang secara bertahap:

- **Step 1**: aplikasi 1 → terakhir, jeda bisa diatur (bawaan 8 detik)
- **Step 2**: terbalik (terakhir → 1, disarankan) atau maju (1 → terakhir), jeda bisa diatur
- Selama berjalan: wake lock + layar tetap menyala, tampilan launcher ditutup agar hemat RAM
- **Pembaca log real time** (butuh izin READ_LOGS): menampilkan ID server tiap aplikasi,
  menandai ID yang **KEMBAR**, dan mendeteksi aplikasi yang **RELOG** (proses dimulai ulang)
  atau **DIMATIKAN** sistem
- Mode rekam log untuk diagnosa (file teks di folder Download)

## Izin baca log (sekali saja)

Di aShell (Shizuku):

    pm grant com.aurastore.cabangpro android.permission.READ_LOGS

Dari komputer:

    adb shell pm grant com.aurastore.cabangpro android.permission.READ_LOGS

## Build lewat GitHub

Unggah isi folder ini ke repo GitHub. Tab **Actions → Build APK** akan membuat APK
(unduh dari bagian *Artifacts*). Untuk rilis ke customer, ganti `signingConfig` dengan keystore sendiri.

## Catatan

Aplikasi ini hanya membuka aplikasi lain dan **membaca** log sistem. Tidak mengubah isi aplikasi lain.
