package com.aurastore.cabangpro;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    static final int BG = 0xFF170F13, CARD = 0xFF24181E, ACCENT = 0xFFE0457B, TEXT = 0xFFF5EEF1,
            MUTED = 0xFFB9A7AF, GREEN = 0xFF4CC38A, AMBER = 0xFFF2B33D, RED = 0xFFF06A6A, LINE = 0xFF3A2A32;

    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<String[]> allApps = new ArrayList<>(); // {pkg, label}
    private final Set<String> selected = new HashSet<>();

    private LinearLayout permBox, appList, resultBox, eventBox;
    private TextView selCount, summaryText, runState;
    private EditText filter, delay1, delay2, pattern;
    private RadioButton rbReverse, rbForward;
    private CheckBox cbClose, cbBack, cbPanel, cbRecord;
    private Button startBtn;
    private int shownVersion = -1;
    private boolean visible;

    private final Runnable poll = new Runnable() {
        @Override public void run() {
            if (!visible) return;
            int v; synchronized (AuraState.LOCK) { v = AuraState.version; }
            if (v != shownVersion) { shownVersion = v; renderResults(); }
            renderRunButton();
            handler.postDelayed(this, 1000);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("cfg", MODE_PRIVATE);
        selected.addAll(prefs.getStringSet("selected", new HashSet<>()));
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        setContentView(buildUi());
        loadApps();
    }

    @Override protected void onResume() {
        super.onResume();
        visible = true;
        renderPermissions();
        shownVersion = -1;
        handler.post(poll);
    }

    @Override protected void onPause() {
        visible = false;
        saveSettings();
        super.onPause();
    }

    // ---------------- UI ----------------

    private View buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(32));
        sv.addView(root);

        TextView title = text("Aura Cabang Pro", 22, TEXT, true);
        root.addView(title);
        TextView sub = text("Buka aplikasi bertahap · Step 1 & Step 2 · baca ID server", 13, MUTED, false);
        sub.setPadding(0, dp(2), 0, dp(12));
        root.addView(sub);

        // Izin
        LinearLayout c1 = card(root, "1. Izin");
        permBox = new LinearLayout(this);
        permBox.setOrientation(LinearLayout.VERTICAL);
        c1.addView(permBox);

        // Aplikasi
        LinearLayout c2 = card(root, "2. Pilih aplikasi");
        filter = edit(prefs.getString("filter", "com.am"), "Saring nama paket, mis. com.am", false);
        filter.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b2, int c) {}
            public void onTextChanged(CharSequence s, int a, int b2, int c) {}
            public void afterTextChanged(Editable s) { renderAppList(); }
        });
        c2.addView(filter);
        LinearLayout row = hrow();
        row.addView(button("Pilih semua (tersaring)", v -> { for (String[] a : filtered()) selected.add(a[0]); renderAppList(); }), weight());
        row.addView(space(8));
        row.addView(button("Kosongkan", v -> { selected.clear(); renderAppList(); }), weight());
        c2.addView(row);
        selCount = text("", 13, MUTED, false);
        selCount.setPadding(0, dp(8), 0, dp(4));
        c2.addView(selCount);
        appList = new LinearLayout(this);
        appList.setOrientation(LinearLayout.VERTICAL);
        c2.addView(appList);

        // Pengaturan
        LinearLayout c3 = card(root, "3. Pengaturan");
        LinearLayout dr = hrow();
        LinearLayout d1 = labeled("Jeda Step 1 (detik)");
        delay1 = edit(String.valueOf(prefs.getInt("delay1", 8)), "8", true);
        d1.addView(delay1);
        LinearLayout d2 = labeled("Jeda Step 2 (detik)");
        delay2 = edit(String.valueOf(prefs.getInt("delay2", 8)), "8", true);
        d2.addView(delay2);
        dr.addView(d1, weight()); dr.addView(space(8)); dr.addView(d2, weight());
        c3.addView(dr);

        TextView ol = text("Urutan Step 2", 13, MUTED, false);
        ol.setPadding(0, dp(10), 0, 0);
        c3.addView(ol);
        RadioGroup rg = new RadioGroup(this);
        rbReverse = radio("Terbalik: aplikasi terakhir → pertama (disarankan, paling sedikit relog)");
        rbForward = radio("Maju: aplikasi pertama → terakhir");
        rbReverse.setId(View.generateViewId()); rbForward.setId(View.generateViewId());
        rg.addView(rbReverse); rg.addView(rbForward);
        (prefs.getBoolean("reverse2", true) ? rbReverse : rbForward).setChecked(true);
        c3.addView(rg);

        cbClose = check("Tutup tampilan launcher saat berjalan (hemat RAM)", prefs.getBoolean("close", true));
        cbBack = check("Kembali ke launcher setelah selesai", prefs.getBoolean("back", true));
        cbPanel = check("Tampilkan panel info melayang (Step, aplikasi, ID server)", prefs.getBoolean("panel", true));
        cbRecord = check("Rekam log untuk diagnosa (disimpan ke folder Download)", prefs.getBoolean("record", false));
        c3.addView(cbClose); c3.addView(cbBack); c3.addView(cbPanel); c3.addView(cbRecord);

        TextView pl = text("Pola ID server (lanjutan, biarkan jika tidak paham)", 13, MUTED, false);
        pl.setPadding(0, dp(10), 0, 0);
        c3.addView(pl);
        pattern = edit(prefs.getString("pattern", LogWatcher.DEFAULT_PATTERN), LogWatcher.DEFAULT_PATTERN, false);
        pattern.setTypeface(Typeface.MONOSPACE);
        pattern.setTextSize(12);
        c3.addView(pattern);
        c3.addView(button("Kembalikan pola bawaan", v -> pattern.setText(LogWatcher.DEFAULT_PATTERN)));

        // Mulai
        startBtn = new Button(this);
        startBtn.setAllCaps(false);
        startBtn.setTextSize(17);
        startBtn.setTypeface(Typeface.DEFAULT_BOLD);
        startBtn.setTextColor(Color.WHITE);
        startBtn.setOnClickListener(v -> onStartStop());
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56));
        sp.topMargin = dp(16);
        root.addView(startBtn, sp);
        runState = text("", 13, MUTED, false);
        runState.setGravity(Gravity.CENTER);
        runState.setPadding(0, dp(6), 0, 0);
        root.addView(runState);

        // Hasil
        LinearLayout c4 = card(root, "4. Hasil");
        summaryText = text("", 14, TEXT, true);
        c4.addView(summaryText);
        resultBox = new LinearLayout(this);
        resultBox.setOrientation(LinearLayout.VERTICAL);
        resultBox.setPadding(0, dp(8), 0, 0);
        c4.addView(resultBox);
        TextView legend = text("Hidup = tidak dimulai ulang · RELOG = aplikasi dimulai ulang dari awal · "
                + "KEMBAR = ID server sama dengan aplikasi lain", 12, MUTED, false);
        legend.setPadding(0, dp(8), 0, 0);
        c4.addView(legend);

        LinearLayout c5 = card(root, "Catatan proses");
        eventBox = new LinearLayout(this);
        eventBox.setOrientation(LinearLayout.VERTICAL);
        c5.addView(eventBox);
        return sv;
    }

    private void renderPermissions() {
        if (permBox == null) return;
        permBox.removeAllViews();
        boolean overlay = Settings.canDrawOverlays(this);
        permRow("Tampil di atas aplikasi lain", "Wajib: untuk membuka aplikasi dari latar & menjaga layar tetap menyala",
                overlay, "Aktifkan", v -> open(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))));
        boolean notif = Build.VERSION.SDK_INT < 33 || checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED;
        permRow("Notifikasi", "Untuk tombol Hentikan & progres", notif, "Aktifkan", v -> {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        });
        PowerManager pm = getSystemService(PowerManager.class);
        boolean batt = pm.isIgnoringBatteryOptimizations(getPackageName());
        permRow("Abaikan optimasi baterai", "Agar launcher tidak dihentikan di tengah proses", batt, "Aktifkan",
                v -> open(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName()))));
        boolean logs = LogWatcher.hasPermission(this);
        String cmd = "pm grant " + getPackageName() + " android.permission.READ_LOGS";
        permRow("Izin baca log (ID server & relog)",
                logs ? "Aktif" : "Diberikan sekali lewat aShell (Shizuku) atau komputer. Tekan Salin, tempel di aShell, Enter, lalu tutup & buka lagi launcher ini.",
                logs, "Salin perintah", v -> {
                    ClipboardManager cm = getSystemService(ClipboardManager.class);
                    cm.setPrimaryClip(ClipData.newPlainText("cmd", cmd));
                    Toast.makeText(this, "Disalin: " + cmd, Toast.LENGTH_LONG).show();
                });
        if (!logs) {
            TextView t = text(cmd + "\nDari komputer: adb shell " + cmd, 11, MUTED, false);
            t.setTypeface(Typeface.MONOSPACE);
            t.setTextIsSelectable(true);
            permBox.addView(t);
        }
    }

    private void permRow(String name, String desc, boolean ok, String action, View.OnClickListener l) {
        LinearLayout r = hrow();
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(6), 0, dp(6));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text((ok ? "✓  " : "✗  ") + name, 14, ok ? GREEN : AMBER, true));
        col.addView(text(desc, 12, MUTED, false));
        r.addView(col, weight());
        if (!ok) { r.addView(space(8)); r.addView(button(action, l)); }
        permBox.addView(r);
    }

    private void loadApps() {
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> ris = pm.queryIntentActivities(i, 0);
            ArrayList<String[]> list = new ArrayList<>();
            HashSet<String> seen = new HashSet<>();
            for (ResolveInfo ri : ris) {
                String p = ri.activityInfo.packageName;
                if (p.equals(getPackageName()) || !seen.add(p)) continue;
                String label;
                try { label = String.valueOf(ri.loadLabel(pm)); } catch (Exception e) { label = p; }
                list.add(new String[]{p, label});
            }
            Collections.sort(list, (a, b2) -> a[0].compareTo(b2[0]));
            handler.post(() -> { allApps.clear(); allApps.addAll(list); renderAppList(); });
        }).start();
    }

    private List<String[]> filtered() {
        String f = filter.getText().toString().trim().toLowerCase();
        ArrayList<String[]> out = new ArrayList<>();
        for (String[] a : allApps)
            if (f.isEmpty() || a[0].toLowerCase().contains(f) || a[1].toLowerCase().contains(f)) out.add(a);
        return out;
    }

    private ArrayList<String[]> selectedOrdered() {
        ArrayList<String[]> out = new ArrayList<>();
        for (String[] a : allApps) if (selected.contains(a[0])) out.add(a);
        return out;
    }

    private void renderAppList() {
        appList.removeAllViews();
        List<String[]> f = filtered();
        ArrayList<String[]> sel = selectedOrdered();
        for (String[] a : f) {
            CheckBox cb = new CheckBox(this);
            int n = indexOf(sel, a[0]);
            cb.setText((n >= 0 ? (n + 1) + ".  " : "") + a[1] + "\n" + a[0]);
            cb.setTextColor(TEXT);
            cb.setTextSize(13);
            cb.setChecked(selected.contains(a[0]));
            cb.setButtonTintList(android.content.res.ColorStateList.valueOf(ACCENT));
            cb.setOnCheckedChangeListener((v, on) -> {
                if (on) selected.add(a[0]); else selected.remove(a[0]);
                handler.post(this::renderAppList);
            });
            appList.addView(cb);
        }
        if (allApps.isEmpty()) appList.addView(text("Memuat daftar aplikasi…", 13, MUTED, false));
        else if (f.isEmpty()) appList.addView(text("Tidak ada aplikasi yang cocok dengan saringan.", 13, MUTED, false));
        selCount.setText("Dipilih: " + sel.size() + " aplikasi (urut sesuai nama paket). Ditampilkan: " + f.size());
    }

    private static int indexOf(List<String[]> l, String p) {
        for (int i = 0; i < l.size(); i++) if (l.get(i)[0].equals(p)) return i;
        return -1;
    }

    private void onStartStop() {
        if (RunService.isRunning()) {
            startService(new Intent(this, RunService.class).setAction(RunService.ACTION_STOP));
            return;
        }
        ArrayList<String[]> sel = selectedOrdered();
        if (sel.isEmpty()) { toast("Pilih minimal satu aplikasi dulu"); return; }
        if (!Settings.canDrawOverlays(this)) { toast("Aktifkan izin 'Tampil di atas aplikasi lain' dulu (bagian 1)"); return; }
        int d1 = parse(delay1, 8), d2 = parse(delay2, 8);
        if (d1 < 2 || d2 < 2) { toast("Jeda minimal 2 detik"); return; }
        saveSettings();

        AuraState.reset(sel);
        ArrayList<String> pkgs = new ArrayList<>();
        for (String[] a : sel) pkgs.add(a[0]);
        Intent i = new Intent(this, RunService.class).setAction(RunService.ACTION_START)
                .putStringArrayListExtra("pkgs", pkgs)
                .putExtra("delay1", d1 * 1000L)
                .putExtra("delay2", d2 * 1000L)
                .putExtra("reverse2", rbReverse.isChecked())
                .putExtra("back", cbBack.isChecked())
                .putExtra("panel", cbPanel.isChecked())
                .putExtra("record", cbRecord.isChecked())
                .putExtra("pattern", pattern.getText().toString());
        RunService.start(this, i);
        if (cbClose.isChecked()) finish();
    }

    private void renderRunButton() {
        boolean run = RunService.isRunning();
        startBtn.setText(run ? "HENTIKAN" : "MULAI");
        startBtn.setBackground(round(run ? RED : ACCENT, 14));
        String s;
        synchronized (AuraState.LOCK) {
            s = run ? "Berjalan · Step " + AuraState.step + " · " + AuraState.pos + "/" + AuraState.apps.size()
                    + (AuraState.logReaderActive ? " · pembaca log aktif" : "") : "";
        }
        runState.setText(s);
    }

    private void renderResults() {
        resultBox.removeAllViews();
        eventBox.removeAllViews();
        int withId = 0, dup = 0, relog = 0, killed = 0;
        HashSet<String> ids = new HashSet<>();
        ArrayList<String> ev;
        synchronized (AuraState.LOCK) {
            int n = 0;
            for (AuraState.AppEntry e : AuraState.apps) {
                n++;
                int d = AuraState.duplicatesOf(e);
                if (!e.server.isEmpty()) { withId++; ids.add(e.server); }
                if (d > 0) dup++;
                if (e.restarts > 0) relog++;
                if (e.kills > 0) killed++;
                LinearLayout r = hrow();
                r.setPadding(0, dp(5), 0, dp(5));
                r.addView(text(n + ".", 13, MUTED, false), new LinearLayout.LayoutParams(dp(28), -2));
                r.addView(text(e.pkg, 13, TEXT, false), weight());
                r.addView(text(e.server.isEmpty() ? "–" : e.server, 13, d > 0 ? RED : TEXT, true),
                        new LinearLayout.LayoutParams(dp(62), -2));
                String st; int col;
                if (e.restarts > 0) { st = "RELOG ×" + e.restarts; col = RED; }
                else if (e.kills > 0) { st = "DIMATIKAN"; col = AMBER; }
                else if (e.launched2) { st = "Hidup"; col = GREEN; }
                else if (e.launched1) { st = "Step 1"; col = MUTED; }
                else { st = "Menunggu"; col = MUTED; }
                if (d > 0) st = st + " · KEMBAR";
                TextView sv = text(st, 12, col, true);
                sv.setGravity(Gravity.END);
                r.addView(sv, new LinearLayout.LayoutParams(dp(104), -2));
                resultBox.addView(r);
                View line = new View(this);
                line.setBackgroundColor(LINE);
                resultBox.addView(line, new LinearLayout.LayoutParams(-1, 1));
            }
            ev = new ArrayList<>(AuraState.events);
            if (AuraState.apps.isEmpty()) summaryText.setText("Belum ada proses.");
            else summaryText.setText("ID terbaca " + withId + "/" + AuraState.apps.size() + " · server unik " + ids.size()
                    + " · kembar " + dup + "\nRelog " + relog + " · dimatikan sistem " + killed);
        }
        int max = Math.min(ev.size(), 60);
        for (int i = 0; i < max; i++) {
            String s = ev.get(i);
            int c = s.contains("RELOG") || s.contains("GAGAL") ? RED : s.contains("DIMATIKAN") ? AMBER
                    : s.contains("ID server") ? GREEN : MUTED;
            TextView t = text(s, 12, c, false);
            t.setTypeface(Typeface.MONOSPACE);
            eventBox.addView(t);
        }
        if (ev.isEmpty()) eventBox.addView(text("Belum ada catatan.", 12, MUTED, false));
    }

    private void saveSettings() {
        if (prefs == null || delay1 == null) return;
        prefs.edit()
                .putStringSet("selected", new HashSet<>(selected))
                .putString("filter", filter.getText().toString())
                .putInt("delay1", parse(delay1, 8))
                .putInt("delay2", parse(delay2, 8))
                .putBoolean("reverse2", rbReverse.isChecked())
                .putBoolean("close", cbClose.isChecked())
                .putBoolean("back", cbBack.isChecked())
                .putBoolean("panel", cbPanel.isChecked())
                .putBoolean("record", cbRecord.isChecked())
                .putString("pattern", pattern.getText().toString())
                .apply();
    }

    // ---------------- helpers ----------------

    private void open(Intent i) {
        try { startActivity(i); } catch (Exception e) {
            try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))); }
            catch (Exception ignored) {}
        }
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    private static int parse(EditText e, int def) {
        try { return Integer.parseInt(e.getText().toString().trim()); } catch (Exception x) { return def; }
    }

    private LinearLayout card(LinearLayout parent, String title) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(12), dp(14), dp(14));
        c.setBackground(round(CARD, 16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(12);
        parent.addView(c, lp);
        TextView t = text(title, 16, TEXT, true);
        t.setPadding(0, 0, 0, dp(6));
        c.addView(t);
        return c;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private EditText edit(String value, String hint, boolean number) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setHint(hint);
        e.setTextColor(TEXT);
        e.setHintTextColor(MUTED);
        e.setTextSize(15);
        e.setSingleLine(true);
        e.setBackground(round(0xFF2F2028, 10));
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        if (number) e.setInputType(InputType.TYPE_CLASS_NUMBER);
        return e;
    }

    private LinearLayout labeled(String label) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        TextView t = text(label, 13, MUTED, false);
        t.setPadding(0, 0, 0, dp(4));
        l.addView(t);
        return l;
    }

    private Button button(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setTextColor(TEXT);
        b.setBackground(round(0xFF3A2631, 10));
        b.setPadding(dp(12), 0, dp(12), 0);
        b.setMinHeight(dp(40)); b.setMinimumHeight(dp(40));
        b.setOnClickListener(l);
        return b;
    }

    private RadioButton radio(String s) {
        RadioButton r = new RadioButton(this);
        r.setText(s);
        r.setTextColor(TEXT);
        r.setTextSize(13);
        r.setButtonTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        return r;
    }

    private CheckBox check(String s, boolean on) {
        CheckBox c = new CheckBox(this);
        c.setText(s);
        c.setTextColor(TEXT);
        c.setTextSize(13);
        c.setChecked(on);
        c.setButtonTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        return c;
    }

    private LinearLayout hrow() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    private View space(int w) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(w), 1));
        return v;
    }

    private static LinearLayout.LayoutParams weight() { return new LinearLayout.LayoutParams(0, -2, 1f); }

    private GradientDrawable round(int color, int r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
