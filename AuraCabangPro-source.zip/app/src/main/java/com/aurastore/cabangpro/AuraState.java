package com.aurastore.cabangpro;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/** Status bersama antara layar, layanan, dan pembaca log. Semua akses lewat LOCK. */
public final class AuraState {
    public static final Object LOCK = new Object();

    public static final class AppEntry {
        public final String pkg;
        public final String label;
        public String server = "";
        public boolean launched1, launched2;
        public boolean initialStartSeen;
        public int restarts;   // proses dimulai ulang = relog
        public int kills;      // proses dimatikan sistem
        public String lastKillReason = "";

        AppEntry(String pkg, String label) { this.pkg = pkg; this.label = label; }
    }

    public static final ArrayList<AppEntry> apps = new ArrayList<>();
    public static final HashMap<String, AppEntry> byPkg = new HashMap<>();
    public static boolean running;
    public static int step;          // 0 = belum, 1, 2
    public static int pos;           // posisi dalam step (1..n)
    public static String currentPkg = "";
    public static boolean logReaderActive;
    public static String logReaderError = "";
    public static final ArrayList<String> events = new ArrayList<>();
    public static int version;       // naik setiap ada perubahan, untuk refresh UI

    private AuraState() {}

    public static void reset(List<String[]> pkgLabels) {
        synchronized (LOCK) {
            apps.clear(); byPkg.clear(); events.clear();
            for (String[] pl : pkgLabels) {
                AppEntry e = new AppEntry(pl[0], pl[1]);
                apps.add(e); byPkg.put(pl[0], e);
            }
            step = 0; pos = 0; currentPkg = ""; logReaderError = "";
            version++;
        }
    }

    public static void event(String msg) {
        String t = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        synchronized (LOCK) {
            events.add(0, t + "  " + msg);
            while (events.size() > 150) events.remove(events.size() - 1);
            version++;
        }
    }

    /** Jumlah aplikasi lain yang punya ID server sama. Panggil di dalam LOCK. */
    public static int duplicatesOf(AppEntry e) {
        if (e.server.isEmpty()) return 0;
        int n = 0;
        for (AppEntry o : apps) if (o != e && e.server.equals(o.server)) n++;
        return n;
    }
}
