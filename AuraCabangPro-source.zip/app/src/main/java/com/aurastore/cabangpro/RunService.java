package com.aurastore.cabangpro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Layanan ringan yang membuka aplikasi satu per satu.
 * Step 1: 1 -> N. Step 2: N -> 1 (terbalik) atau 1 -> N (maju). Jeda per aplikasi bisa diatur.
 * Selama berjalan: wake lock + layar tetap menyala (lewat panel melayang) agar aplikasi tidak dibekukan.
 */
public class RunService extends Service {
    public static final String ACTION_START = "com.aurastore.cabangpro.START";
    public static final String ACTION_STOP = "com.aurastore.cabangpro.STOP";
    private static final String CHANNEL = "aura_run";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private ArrayList<String> pkgs = new ArrayList<>();
    private ArrayList<Integer> order = new ArrayList<>();
    private int idx;
    private long delay1 = 8000, delay2 = 8000;
    private boolean reverse2 = true, backToLauncher = true, showPanel = true;
    private PowerManager.WakeLock wakeLock;
    private WindowManager wm;
    private View overlay;
    private TextView overlayText;
    private LogWatcher watcher;
    private Icon smallIcon;

    private final Runnable tick = this::step;
    private final Runnable refresh = new Runnable() {
        @Override public void run() {
            updateOverlay();
            handler.postDelayed(this, 1000);
        }
    };

    public static boolean isRunning() { synchronized (AuraState.LOCK) { return AuraState.running; } }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Proses buka aplikasi", NotificationManager.IMPORTANCE_LOW));
        startForeground(1, buildNotification());

        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            AuraState.event("Dihentikan oleh Anda");
            finishRun(false);
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(action) || isRunning()) {
            if (!isRunning()) stopSelf();
            return START_NOT_STICKY;
        }

        ArrayList<String> list = intent.getStringArrayListExtra("pkgs");
        if (list == null || list.isEmpty()) { stopSelf(); return START_NOT_STICKY; }
        pkgs = list;
        delay1 = Math.max(2000, intent.getLongExtra("delay1", 8000));
        delay2 = Math.max(2000, intent.getLongExtra("delay2", 8000));
        reverse2 = intent.getBooleanExtra("reverse2", true);
        backToLauncher = intent.getBooleanExtra("back", true);
        showPanel = intent.getBooleanExtra("panel", true);
        boolean record = intent.getBooleanExtra("record", false);
        String pattern = intent.getStringExtra("pattern");

        synchronized (AuraState.LOCK) {
            AuraState.running = true; AuraState.step = 1; AuraState.pos = 0; AuraState.version++;
        }
        AuraState.event("Mulai: " + pkgs.size() + " aplikasi · jeda Step 1 " + delay1 / 1000 + " dtk · Step 2 "
                + delay2 / 1000 + " dtk (" + (reverse2 ? "terbalik" : "maju") + ")");

        acquireWakeLock();
        addOverlay();
        if (LogWatcher.hasPermission(this)) {
            watcher = new LogWatcher(this, pattern, record);
            watcher.start();
            AuraState.event("Pembaca log aktif: ID server & relog dipantau");
        } else {
            AuraState.event("Izin baca log belum aktif: ID server & relog tidak terbaca");
        }

        order = buildOrder(1);
        idx = 0;
        AuraState.event("— Step 1 dimulai —");
        handler.post(tick);
        handler.post(refresh);
        return START_NOT_STICKY;
    }

    private ArrayList<Integer> buildOrder(int step) {
        ArrayList<Integer> o = new ArrayList<>();
        int n = pkgs.size();
        if (step == 2 && reverse2) for (int i = n - 1; i >= 0; i--) o.add(i);
        else for (int i = 0; i < n; i++) o.add(i);
        return o;
    }

    private void step() {
        int curStep;
        synchronized (AuraState.LOCK) { curStep = AuraState.step; }
        if (idx >= order.size()) {
            if (curStep == 1) {
                synchronized (AuraState.LOCK) { AuraState.step = 2; AuraState.pos = 0; AuraState.version++; }
                order = buildOrder(2);
                idx = 0;
                AuraState.event("— Step 2 dimulai (" + (reverse2 ? "terbalik" : "maju") + ") —");
                curStep = 2;
            } else {
                summary();
                // beri waktu sebentar agar log terakhir sempat terbaca
                handler.postDelayed(() -> finishRun(backToLauncher), 3000);
                return;
            }
        }
        String pkg = pkgs.get(order.get(idx));
        idx++;
        synchronized (AuraState.LOCK) {
            AuraState.pos = idx;
            AuraState.currentPkg = pkg;
            AuraState.AppEntry e = AuraState.byPkg.get(pkg);
            if (e != null) { if (curStep == 1) e.launched1 = true; else e.launched2 = true; }
            AuraState.version++;
        }
        boolean ok = launch(pkg);
        AuraState.event("Step " + curStep + " · " + idx + "/" + order.size() + " · " + (ok ? "Buka " : "GAGAL buka ") + pkg);
        updateNotification();
        handler.postDelayed(tick, ok ? (curStep == 1 ? delay1 : delay2) : 700);
    }

    private boolean launch(String pkg) {
        try {
            Intent li = getPackageManager().getLaunchIntentForPackage(pkg);
            if (li == null) return false;
            li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(li);
            return true;
        } catch (Exception e) {
            AuraState.event("Error " + pkg + ": " + e.getMessage());
            return false;
        }
    }

    private void summary() {
        int withId = 0, unique, dup = 0, relog = 0, killed = 0;
        java.util.HashSet<String> ids = new java.util.HashSet<>();
        synchronized (AuraState.LOCK) {
            for (AuraState.AppEntry e : AuraState.apps) {
                if (!e.server.isEmpty()) { withId++; ids.add(e.server); if (AuraState.duplicatesOf(e) > 0) dup++; }
                if (e.restarts > 0) relog++;
                if (e.kills > 0) killed++;
            }
        }
        unique = ids.size();
        AuraState.event("Selesai. ID terbaca " + withId + " · server unik " + unique + " · kembar " + dup
                + " · relog " + relog + " · dimatikan sistem " + killed);
    }

    private void finishRun(boolean openLauncher) {
        handler.removeCallbacksAndMessages(null);
        synchronized (AuraState.LOCK) { AuraState.running = false; AuraState.currentPkg = ""; AuraState.version++; }
        if (watcher != null) { watcher.shutdown(); watcher = null; }
        removeOverlay();
        releaseWakeLock();
        if (openLauncher) {
            try {
                startActivity(new Intent(this, MainActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
            } catch (Exception ignored) {}
        }
        stopForeground(true);
        stopSelf();
    }

    @Override public void onDestroy() {
        if (isRunning()) finishRun(false);
        super.onDestroy();
    }

    // ---------- wake lock & panel melayang ----------

    private void acquireWakeLock() {
        try {
            PowerManager pm = getSystemService(PowerManager.class);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "aura:run");
            wakeLock.acquire(6 * 60 * 60 * 1000L);
        } catch (Exception ignored) {}
    }

    private void releaseWakeLock() {
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Exception ignored) {}
        wakeLock = null;
    }

    private void addOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            AuraState.event("Izin tampil di atas aplikasi lain belum aktif: layar bisa mati sendiri");
            return;
        }
        wm = getSystemService(WindowManager.class);
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        WindowManager.LayoutParams lp;
        if (showPanel) {
            TextView tv = new TextView(this);
            tv.setTextColor(Color.WHITE);
            tv.setTextSize(11);
            tv.setPadding(dp(10), dp(5), dp(10), dp(5));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xCC1B1220);
            bg.setCornerRadius(dp(14));
            tv.setBackground(bg);
            overlayText = tv;
            overlay = tv;
            lp = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            lp.y = dp(28);
        } else {
            overlay = new View(this);
            lp = new WindowManager.LayoutParams(1, 1,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
        }
        lp.alpha = 0.75f; // di bawah 0.8 agar sentuhan tetap tembus ke game (Android 12+)
        try {
            wm.addView(overlay, lp);
            updateOverlay();
        } catch (Exception e) {
            overlay = null; overlayText = null;
            AuraState.event("Panel melayang gagal tampil: " + e.getMessage());
        }
    }

    private void removeOverlay() {
        try { if (overlay != null && wm != null) wm.removeView(overlay); } catch (Exception ignored) {}
        overlay = null; overlayText = null;
    }

    private void updateOverlay() {
        if (overlayText == null) return;
        String text;
        synchronized (AuraState.LOCK) {
            AuraState.AppEntry e = AuraState.byPkg.get(AuraState.currentPkg);
            int relog = 0;
            for (AuraState.AppEntry a : AuraState.apps) if (a.restarts > 0) relog++;
            text = "Step " + AuraState.step + " · " + AuraState.pos + "/" + AuraState.apps.size()
                    + (e == null ? "" : " · " + e.pkg)
                    + "\nServer: " + (e == null || e.server.isEmpty() ? "-" : e.server)
                    + (AuraState.logReaderActive ? " · relog: " + relog : "");
        }
        overlayText.setText(text);
    }

    // ---------- notifikasi ----------

    private Notification buildNotification() {
        String text;
        synchronized (AuraState.LOCK) {
            text = AuraState.running ? "Step " + AuraState.step + " · membuka " + AuraState.pos + "/" + AuraState.apps.size()
                    + (AuraState.currentPkg.isEmpty() ? "" : " · " + AuraState.currentPkg) : "Menyiapkan…";
        }
        PendingIntent open = PendingIntent.getActivity(this, 2, new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 1, new Intent(this, RunService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Aura Cabang Pro")
                .setContentText(text)
                .setSmallIcon(icon())
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder((Icon) null, "Hentikan", stop).build());
        synchronized (AuraState.LOCK) {
            if (AuraState.running && !AuraState.apps.isEmpty()) b.setProgress(AuraState.apps.size() * 2,
                    (AuraState.step - 1) * AuraState.apps.size() + AuraState.pos, false);
        }
        return b.build();
    }

    private void updateNotification() {
        try { getSystemService(NotificationManager.class).notify(1, buildNotification()); } catch (Exception ignored) {}
    }

    private Icon icon() {
        if (smallIcon == null) {
            int s = 48;
            Bitmap bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bmp);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(Color.WHITE);
            c.drawCircle(s / 2f, s / 2f, s / 2f - 2, p);
            p.setColor(Color.TRANSPARENT);
            p.setXfermode(new android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.CLEAR));
            c.drawCircle(s / 2f, s / 2f, s / 5f, p);
            smallIcon = Icon.createWithBitmap(bmp);
        }
        return smallIcon;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    static void start(Context c, Intent i) { c.startForegroundService(i); }
}
