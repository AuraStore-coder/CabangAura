package com.aurastore.cabangpro;

import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Membaca log sistem (logcat) secara real time. Hanya MEMBACA, tidak mengubah aplikasi lain.
 * Butuh izin READ_LOGS yang diberikan sekali lewat: pm grant <paket> android.permission.READ_LOGS
 *
 * Yang dideteksi:
 *  - ID server dari baris log aplikasi target (pola bisa diatur)
 *  - proses aplikasi target dimulai ulang (= relog) dan dimatikan sistem
 */
public final class LogWatcher extends Thread {
    public static final String DEFAULT_PATTERN = "(?i)(?:zone|server|svr)[ _]?(?:id)?\\D{0,12}(5\\d{4})";

    private static final Pattern THREADTIME_UID = Pattern.compile(
            "^\\d\\d-\\d\\d \\d\\d:\\d\\d:\\d\\d\\.\\d+\\s+(\\S+)\\s+(\\d+)\\s+\\d+\\s+[VDIWEFAS]\\s+(.*)$");
    private static final Pattern THREADTIME = Pattern.compile(
            "^\\d\\d-\\d\\d \\d\\d:\\d\\d:\\d\\d\\.\\d+\\s+(\\d+)\\s+\\d+\\s+[VDIWEFAS]\\s+(.*)$");
    private static final Pattern AM_PROC_START = Pattern.compile(
            "am_proc_start\\s*:\\s*\\[\\d+,(\\d+),(\\d+),([^,\\]]+),");
    private static final Pattern START_PROC = Pattern.compile("Start proc (\\d+):([^/\\s]+)/");
    private static final Pattern AM_KILL = Pattern.compile(
            "am_kill\\s*:\\s*\\[\\d+,(\\d+),([^,\\]]+),(-?\\d+),([^\\]]*)\\]");
    private static final Pattern KILLING = Pattern.compile("Killing (\\d+):([^/\\s]+)/\\S+ \\(adj (-?\\d+)\\): (.*)");
    private static final Pattern LMKD = Pattern.compile("Kill '([^']+)' \\((\\d+)\\)");
    private static final Pattern DIED = Pattern.compile("Process ([^\\s]+) \\(pid (\\d+)\\) has died");
    private static final Pattern UID_NAME = Pattern.compile("^u(\\d+)_([ai])(\\d+)$");
    private static final Pattern FIVE_DIGIT = Pattern.compile("\\b\\d{5}\\b");

    private final Context ctx;
    private final PackageManager pm;
    private final Pattern serverPattern;
    private final boolean record;
    private final ArrayList<String> recorded = new ArrayList<>();
    private final HashMap<Integer, String> uidPkg = new HashMap<>();
    private final HashMap<Integer, String> pidPkg = new HashMap<>();
    private final HashSet<Integer> startedPids = new HashSet<>();
    private final HashSet<Integer> killedPids = new HashSet<>();
    private volatile boolean stopped;
    private Process proc;

    public LogWatcher(Context ctx, String pattern, boolean record) {
        super("aura-logwatcher");
        this.ctx = ctx.getApplicationContext();
        this.pm = this.ctx.getPackageManager();
        Pattern p;
        try {
            p = Pattern.compile(pattern == null || pattern.trim().isEmpty() ? DEFAULT_PATTERN : pattern.trim());
        } catch (Exception e) {
            p = Pattern.compile(DEFAULT_PATTERN);
            AuraState.event("Pola ID server tidak valid, memakai pola bawaan");
        }
        this.serverPattern = p;
        this.record = record;
        setDaemon(true);
    }

    public static boolean hasPermission(Context c) {
        return c.checkSelfPermission("android.permission.READ_LOGS") == PackageManager.PERMISSION_GRANTED;
    }

    public void shutdown() {
        stopped = true;
        try { if (proc != null) proc.destroy(); } catch (Exception ignored) {}
        interrupt();
    }

    @Override public void run() {
        String[][] commands = {
                {"logcat", "-v", "threadtime", "-v", "uid", "-b", "main", "-b", "system", "-b", "events", "-T", "1"},
                {"logcat", "-v", "threadtime", "-b", "main", "-b", "system", "-b", "events", "-T", "1"},
        };
        for (String[] cmd : commands) {
            if (stopped) break;
            long t0 = System.currentTimeMillis();
            int lines = readFrom(cmd);
            if (stopped) break;
            if (lines > 5 || System.currentTimeMillis() - t0 > 5000) break; // berjalan normal lalu berhenti
        }
        synchronized (AuraState.LOCK) { AuraState.logReaderActive = false; AuraState.version++; }
        if (record) saveRecording();
    }

    private int readFrom(String[] cmd) {
        int count = 0;
        try {
            proc = new ProcessBuilder(cmd).redirectErrorStream(true).start();
            synchronized (AuraState.LOCK) { AuraState.logReaderActive = true; AuraState.version++; }
            BufferedReader r = new BufferedReader(new InputStreamReader(proc.getInputStream(), StandardCharsets.UTF_8));
            String line;
            while (!stopped && (line = r.readLine()) != null) {
                count++;
                try { handle(line); } catch (Exception ignored) {}
            }
        } catch (Exception e) {
            synchronized (AuraState.LOCK) { AuraState.logReaderError = String.valueOf(e.getMessage()); }
        } finally {
            try { if (proc != null) proc.destroy(); } catch (Exception ignored) {}
        }
        return count;
    }

    private void handle(String line) {
        String uidTok = null; int pid = -1; String msg = line;
        Matcher m = THREADTIME_UID.matcher(line);
        if (m.matches()) {
            uidTok = m.group(1); pid = parseInt(m.group(2)); msg = m.group(3);
        } else {
            Matcher m2 = THREADTIME.matcher(line);
            if (m2.matches()) { pid = parseInt(m2.group(1)); msg = m2.group(2); }
        }

        if (handleSystem(msg)) return;

        String pkg = null;
        int uid = parseUid(uidTok);
        if (uid >= 10000) pkg = pkgForUid(uid);
        if (pkg == null && pid > 0) pkg = pidPkg.get(pid);
        if (pkg == null && uid < 0) {
            synchronized (AuraState.LOCK) { pkg = AuraState.currentPkg; }
        }
        if (pkg == null) return;
        AuraState.AppEntry e;
        synchronized (AuraState.LOCK) { e = AuraState.byPkg.get(pkg); }
        if (e == null) return;

        Matcher sm = serverPattern.matcher(msg);
        if (sm.find()) {
            String id = sm.groupCount() >= 1 && sm.group(1) != null ? sm.group(1) : sm.group();
            boolean changed;
            synchronized (AuraState.LOCK) {
                changed = !id.equals(e.server);
                if (changed) { e.server = id; AuraState.version++; }
            }
            if (changed) AuraState.event("ID server " + shortName(pkg) + " = " + id);
        }
        if (record && recorded.size() < 40000 && FIVE_DIGIT.matcher(msg).find()) {
            recorded.add("[" + pkg + "] " + line);
        }
    }

    /** Baris dari sistem tentang proses dimulai / dimatikan. Return true jika sudah ditangani. */
    private boolean handleSystem(String msg) {
        Matcher m;
        if ((m = AM_PROC_START.matcher(msg)).find()) { onStart(parseInt(m.group(1)), m.group(3)); rec(msg); return true; }
        if ((m = START_PROC.matcher(msg)).find()) { onStart(parseInt(m.group(1)), m.group(2)); rec(msg); return true; }
        if ((m = AM_KILL.matcher(msg)).find()) { onKill(parseInt(m.group(1)), m.group(2), m.group(4)); rec(msg); return true; }
        if ((m = KILLING.matcher(msg)).find()) { onKill(parseInt(m.group(1)), m.group(2), m.group(4)); rec(msg); return true; }
        if ((m = LMKD.matcher(msg)).find()) { onKill(parseInt(m.group(2)), m.group(1), "memori penuh (lmkd)"); rec(msg); return true; }
        if ((m = DIED.matcher(msg)).find()) { onKill(parseInt(m.group(2)), m.group(1), "proses berhenti"); rec(msg); return true; }
        return false;
    }

    private void rec(String msg) {
        if (record && recorded.size() < 40000) recorded.add("[sistem] " + msg);
    }

    private void onStart(int pid, String procName) {
        String pkg = procName.contains(":") ? procName.substring(0, procName.indexOf(':')) : procName;
        pidPkg.put(pid, pkg);
        if (procName.contains(":") || !startedPids.add(pid)) return; // hanya proses utama, sekali per pid
        AuraState.AppEntry e; String msg = null;
        synchronized (AuraState.LOCK) {
            e = AuraState.byPkg.get(pkg);
            if (e == null) return;
            if (!e.initialStartSeen && AuraState.step == 1 && pkg.equals(AuraState.currentPkg)) {
                e.initialStartSeen = true;
            } else if (e.launched1) {
                e.restarts++;
                msg = "RELOG: " + shortName(pkg) + " dimulai ulang dari awal (Step " + AuraState.step + ")";
            } else {
                e.initialStartSeen = true;
            }
            AuraState.version++;
        }
        if (msg != null) AuraState.event(msg);
    }

    private void onKill(int pid, String procName, String reason) {
        if (procName.contains(":")) return;
        if (pid > 0 && !killedPids.add(pid)) return;
        String pkg = procName;
        String msg;
        synchronized (AuraState.LOCK) {
            AuraState.AppEntry e = AuraState.byPkg.get(pkg);
            if (e == null) return;
            e.kills++;
            e.lastKillReason = reason == null ? "" : reason.trim();
            AuraState.version++;
            msg = "DIMATIKAN SISTEM: " + shortName(pkg) + (e.lastKillReason.isEmpty() ? "" : " (" + e.lastKillReason + ")");
        }
        AuraState.event(msg);
    }

    private String pkgForUid(int uid) {
        if (uidPkg.containsKey(uid)) return uidPkg.get(uid);
        String found = null;
        try {
            String[] pk = pm.getPackagesForUid(uid);
            if (pk != null) {
                synchronized (AuraState.LOCK) {
                    for (String p : pk) if (AuraState.byPkg.containsKey(p)) { found = p; break; }
                }
                if (found == null && pk.length > 0) found = "";
            }
        } catch (Exception ignored) {}
        uidPkg.put(uid, found);
        return found == null || found.isEmpty() ? null : found;
    }

    private static int parseUid(String tok) {
        if (tok == null) return -1;
        tok = tok.trim();
        Matcher m = UID_NAME.matcher(tok);
        if (m.matches()) {
            int user = parseInt(m.group(1));
            int id = parseInt(m.group(3));
            return user * 100000 + ("a".equals(m.group(2)) ? 10000 + id : 99000 + id);
        }
        if (tok.matches("\\d+")) return parseInt(tok);
        return 0; // root/system/dll
    }

    private static int parseInt(String s) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return -1; }
    }

    static String shortName(String pkg) { return pkg; }

    private void saveRecording() {
        StringBuilder sb = new StringBuilder();
        sb.append("Aura Cabang Pro - rekaman log\n");
        synchronized (AuraState.LOCK) {
            for (AuraState.AppEntry e : AuraState.apps)
                sb.append(e.pkg).append(" server=").append(e.server).append(" relog=").append(e.restarts)
                        .append(" dimatikan=").append(e.kills).append('\n');
        }
        sb.append("\n");
        for (String l : recorded) sb.append(l).append('\n');
        String name = "aura_cabang_log_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".txt";
        byte[] bytes = sb.toString().getBytes(StandardCharsets.UTF_8);
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain");
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new IllegalStateException("tidak bisa membuat file");
                try (OutputStream os = ctx.getContentResolver().openOutputStream(uri)) { os.write(bytes); }
                AuraState.event("Rekaman log disimpan: Download/" + name);
            } else {
                File f = new File(ctx.getExternalFilesDir(null), name);
                try (FileOutputStream os = new FileOutputStream(f)) { os.write(bytes); }
                AuraState.event("Rekaman log disimpan: " + f.getAbsolutePath());
            }
        } catch (Exception e) {
            AuraState.event("Gagal menyimpan rekaman log: " + e.getMessage());
        }
    }
}
