package com.aurastore.cabangpro;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Panggilan ke server lisensi. Selalu di thread terpisah; hasil dikembalikan di thread utama. */
final class Api {
    static final class Result {
        int status;          // 0 = tidak ada koneksi
        JSONObject json;     // isi balasan (bisa null)
        String error = "";   // kode error dari server, mis. "code_invalid"
        boolean ok() { return status >= 200 && status < 300 && json != null; }
    }

    interface Cb { void on(Result r); }

    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private Api() {}

    static void post(final String path, final JSONObject body, final String adminKey, final Cb cb) {
        new Thread(new Runnable() {
            @Override public void run() {
                final Result r = postSync(path, body, adminKey);
                MAIN.post(new Runnable() { @Override public void run() { cb.on(r); } });
            }
        }, "aura-api").start();
    }

    static Result postSync(String path, JSONObject body, String adminKey) {
        Result r = new Result();
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(Cfg.SERVER + path).openConnection();
            c.setConnectTimeout(12000);
            c.setReadTimeout(15000);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("content-type", "application/json");
            if (adminKey != null && adminKey.length() > 0) c.setRequestProperty("x-admin-key", adminKey);
            byte[] data = (body == null ? "{}" : body.toString()).getBytes("UTF-8");
            OutputStream os = c.getOutputStream();
            os.write(data);
            os.close();
            r.status = c.getResponseCode();
            InputStream is = r.status >= 400 ? c.getErrorStream() : c.getInputStream();
            if (is != null) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
                is.close();
                String s = bo.toString("UTF-8");
                try { r.json = new JSONObject(s); } catch (Exception ignored) {}
                if (r.json != null) r.error = r.json.optString("error", "");
            }
        } catch (Exception e) {
            r.status = 0;
            r.error = "network";
        } finally {
            if (c != null) c.disconnect();
        }
        return r;
    }

    /** Pesan error yang mudah dipahami. */
    static String nice(Result r) {
        String e = r.error;
        if (r.status == 0 || "network".equals(e)) return "Tidak ada koneksi ke server. Periksa internet lalu coba lagi.";
        if ("code_invalid".equals(e)) return "Kode tidak ditemukan. Periksa penulisan kode.";
        if ("revoked".equals(e)) return "Kode ini sudah dicabut. Hubungi admin Aura Store.";
        if ("other_device".equals(e)) return "Kode ini sudah dipakai di HP lain. Hubungi admin untuk Reset HP.";
        if ("expired".equals(e)) return "Kode sudah habis atau hangus. Hubungi admin Aura Store.";
        if ("wrong_app".equals(e)) return "Kode ini bukan untuk Aura Cabang Pro.";
        if ("not_activated".equals(e)) return "Kode belum diaktifkan di HP ini.";
        if ("bad_admin".equals(e)) return "Password owner salah.";
        if ("bad_request".equals(e)) return "Permintaan tidak lengkap.";
        if (r.status == 404) return "Server tidak ditemukan. Alamat server belum benar.";
        return "Gagal (" + (e.isEmpty() ? "kode " + r.status : e) + ")";
    }
}
