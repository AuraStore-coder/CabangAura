package com.aurastore.cabangpro;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

import moe.shizuku.api.BinderContainer;

/** Shizuku memanggil provider ini ("sendBinder") untuk menyerahkan koneksinya ke launcher. */
public class ShizukuProvider extends ContentProvider {
    @Override public boolean onCreate() { return true; }

    @Override public Bundle call(String method, String arg, Bundle extras) {
        if (extras == null) return null;
        if ("sendBinder".equals(method)) {
            try {
                extras.setClassLoader(BinderContainer.class.getClassLoader());
                BinderContainer c = extras.getParcelable("moe.shizuku.privileged.api.intent.extra.BINDER");
                if (c != null && c.binder != null && getContext() != null) {
                    ShizukuBridge.onBinderReceived(c.binder, getContext().getPackageName());
                }
            } catch (Throwable ignored) {}
        }
        return new Bundle();
    }

    @Override public Cursor query(Uri u, String[] p, String s, String[] a, String o) { return null; }
    @Override public String getType(Uri uri) { return null; }
    @Override public Uri insert(Uri uri, ContentValues values) { return null; }
    @Override public int delete(Uri uri, String s, String[] a) { return 0; }
    @Override public int update(Uri uri, ContentValues v, String s, String[] a) { return 0; }
}
