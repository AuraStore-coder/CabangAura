package com.aurastore.cabangpro;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/** Tab Owner: daftar penyewa Aura Cabang Pro, buat kode, perpanjang, reset HP, cabut. */
final class OwnerUi {
    private OwnerUi() {}

    private static final String[] PLAN_KEYS = {"15mnt", "30mnt", "1j", "2j", "3j", "5j", "24j", "1m", "2m", "3m", "1b", "1.5b", "2b", "3b", "beli"};
    private static final String[] PLAN_NAMES = {"15 Menit", "30 Menit", "1 Jam", "2 Jam", "3 Jam", "5 Jam", "24 Jam", "1 Minggu", "2 Minggu", "3 Minggu",
            "1 Bulan", "1,5 Bulan", "2 Bulan", "3 Bulan", "BELI PUTUS (Permanen)"};

    private static final ArrayList<JSONObject> data = new ArrayList<>();
    private static long serverNow;
    private static int filter;        // 0 semua, 1 aktif, 2 segera, 3 habis
    private static String query = "";
    private static boolean loading;
    private static String loadError = "";

    // kelompok status
    private static final int S_NEW = 0, S_ACTIVE = 1, S_SOON = 2, S_EXPIRED = 3, S_REVOKED = 4;

    private static int statusOf(JSONObject o) {
        if (o.optBoolean("revoked")) return S_REVOKED;
        long exp = o.optLong("expiresAt", 0);
        if (o.optLong("activatedAt", 0) == 0) return S_NEW;
        if (exp <= serverNow) return S_EXPIRED;
        if (exp - serverNow <= 2L * 86400000L) return S_SOON;
        return S_ACTIVE;
    }

    private static String left(JSONObject o) {
        int s = statusOf(o);
        if (s == S_REVOKED) return "dicabut";
        if (s == S_NEW) return "belum aktif";
        if (s == S_EXPIRED) return "habis";
        long ms = o.optLong("expiresAt", 0) - serverNow;
        long d = ms / 86400000L;
        if (d > 7300) return "permanen";
        long h = (ms % 86400000L) / 3600000L;
        if (d > 0) return d + "h " + h + "j";
        long m = (ms % 3600000L) / 60000L;
        return h + "j " + m + "m";
    }

    static void render(final Activity a, final LinearLayout box) {
        box.removeAllViews();
        box.addView(Theme.pageHead(a, "Owner · Daftar Penyewa", "Halo, selamat datang di Aura Store"));
        box.addView(Theme.text(a, "👑 " + data.size() + " penyewa", 14, Theme.AMBER, true), Theme.lp(a, 8));

        LinearLayout actions = new LinearLayout(a);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button mk = Theme.primary(a, "+ Buat Kode", v -> createDialog(a, box));
        mk.setTextSize(13);
        Button rl = Theme.ghost(a, "↻ Muat ulang", v -> reload(a, box));
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, -2, 1f);
        l1.rightMargin = Theme.dp(a, 5);
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, -2, 1f);
        l2.leftMargin = Theme.dp(a, 5);
        actions.addView(mk, l1);
        actions.addView(rl, l2);
        box.addView(actions, Theme.lp(a, 10));

        final EditText search = Theme.input(a, query, "🔎 Cari nama / kode / HP", false);
        search.setOnEditorActionListener((tv, id, ev) -> { query = tv.getText().toString().trim().toLowerCase(Locale.ROOT); render(a, box); return true; });
        box.addView(search, Theme.lp(a, 10));

        int cAll = 0, cAct = 0, cSoon = 0, cExp = 0;
        for (JSONObject o : data) {
            int s = statusOf(o);
            cAll++;
            if (s == S_ACTIVE) cAct++;
            else if (s == S_SOON) cSoon++;
            else if (s == S_EXPIRED) cExp++;
        }
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(a);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        hs.addView(chips);
        String[] names = {"Semua " + cAll, "Aktif " + cAct, "Segera " + cSoon, "Habis " + cExp};
        for (int i = 0; i < names.length; i++) {
            final int k = i;
            TextView t = Theme.plain(a, names[i], 12, i == filter ? Theme.NAVY : Theme.TEXT, true);
            t.setPadding(Theme.dp(a, 12), Theme.dp(a, 7), Theme.dp(a, 12), Theme.dp(a, 7));
            t.setBackground(i == filter ? Theme.gradient(a, 20) : Theme.outlined(a, 0x33101E45, Theme.STROKE, 20));
            t.setOnClickListener(v -> { filter = k; render(a, box); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = Theme.dp(a, 6);
            chips.addView(t, lp);
        }
        box.addView(hs, Theme.lp(a, 8));

        if (loading) box.addView(Theme.text(a, "Memuat…", 12, Theme.MUTED, false), Theme.lp(a, 10));
        if (loadError.length() > 0) box.addView(Theme.text(a, loadError, 12, Theme.AMBER, false), Theme.lp(a, 10));

        LinearLayout row = null;
        int shown = 0;
        for (final JSONObject o : data) {
            int s = statusOf(o);
            if (filter == 1 && s != S_ACTIVE) continue;
            if (filter == 2 && s != S_SOON) continue;
            if (filter == 3 && s != S_EXPIRED) continue;
            if (query.length() > 0) {
                String hay = (o.optString("note") + " " + o.optString("code") + " " + o.optString("deviceName")).toLowerCase(Locale.ROOT);
                if (!hay.contains(query)) continue;
            }
            if (row == null || row.getChildCount() >= 3) {
                row = new LinearLayout(a);
                row.setOrientation(LinearLayout.HORIZONTAL);
                box.addView(row, Theme.lp(a, 8));
            }
            LinearLayout cell = new LinearLayout(a);
            cell.setOrientation(LinearLayout.VERTICAL);
            int col = s == S_ACTIVE ? Theme.GREEN : s == S_SOON ? Theme.AMBER : s == S_NEW ? Theme.MUTED : Theme.RED;
            cell.setBackground(Theme.outlined(a, 0x99101E45, col, 12));
            cell.setPadding(Theme.dp(a, 8), Theme.dp(a, 8), Theme.dp(a, 8), Theme.dp(a, 8));
            String nm = o.optString("note");
            if (nm.length() == 0) nm = "(tanpa nama)";
            TextView t1 = Theme.plain(a, "• " + nm, 12, Theme.TEXT, true);
            t1.setSingleLine(true);
            t1.setEllipsize(android.text.TextUtils.TruncateAt.END);
            cell.addView(t1);
            cell.addView(Theme.plain(a, left(o), 12, col, true), Theme.lp(a, 2));
            cell.setOnClickListener(v -> detail(a, box, o));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            int n = row.getChildCount();
            lp.leftMargin = n == 0 ? 0 : Theme.dp(a, 3);
            lp.rightMargin = n == 2 ? 0 : Theme.dp(a, 3);
            row.addView(cell, lp);
            shown++;
        }
        if (row != null) {
            // isi ruang kosong di baris terakhir supaya kartu tidak melebar
            while (row.getChildCount() < 3) {
                View pad = new View(a);
                row.addView(pad, new LinearLayout.LayoutParams(0, 1, 1f));
            }
        }
        if (shown == 0 && !loading) box.addView(Theme.text(a, data.isEmpty() ? "Belum ada kode. Ketuk + Buat Kode." : "Tidak ada yang cocok.", 12, Theme.MUTED, false), Theme.lp(a, 10));
    }

    static void reload(final Activity a, final LinearLayout box) {
        loading = true;
        loadError = "";
        render(a, box);
        Api.post("/admin/list", new JSONObject(), Lic.adminKey(a), r -> {
            loading = false;
            if (r.ok()) {
                data.clear();
                serverNow = r.json.optLong("now", System.currentTimeMillis());
                JSONArray arr = r.json.optJSONArray("items");
                if (arr != null) {
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject o = arr.optJSONObject(i);
                        if (o != null && "cabang".equals(o.optString("app", "vg"))) data.add(o);
                    }
                }
            } else {
                loadError = Api.nice(r);
            }
            render(a, box);
        });
    }

    // ---------- buat kode ----------

    private static void createDialog(final Activity a, final LinearLayout box) {
        LinearLayout b = Theme.dialogBox(a, "Buat kode Aura Cabang Pro");
        final int[] plan = {7};
        final Button planBtn = Theme.ghost(a, "Paket: " + PLAN_NAMES[plan[0]], null);
        planBtn.setOnClickListener(v -> new AlertDialog.Builder(a).setTitle("Pilih paket").setItems(PLAN_NAMES, (d, which) -> {
            plan[0] = which;
            planBtn.setText("Paket: " + PLAN_NAMES[which]);
        }).show());
        b.addView(planBtn, Theme.lp(a, 10));
        final EditText note = Theme.input(a, "", "Catatan, mis. Hp oppo - Budi", false);
        b.addView(note, Theme.lp(a, 8));
        final EditText qty = Theme.input(a, "1", "Jumlah (1-50)", true);
        b.addView(qty, Theme.lp(a, 8));
        final TextView out = Theme.plain(a, "", 13, Theme.GREEN, true);
        final AlertDialog[] dlg = new AlertDialog[1];
        Button go = Theme.primary(a, "Buat Kode", null);
        go.setOnClickListener(v -> {
            int n = 1;
            try { n = Integer.parseInt(qty.getText().toString().trim()); } catch (Exception ignored) {}
            JSONObject req = new JSONObject();
            try {
                req.put("plan", PLAN_KEYS[plan[0]]);
                req.put("note", note.getText().toString().trim());
                req.put("count", Math.max(1, Math.min(50, n)));
                req.put("app", Cfg.APP);
            } catch (Exception ignored) {}
            go.setEnabled(false);
            Api.post("/admin/create", req, Lic.adminKey(a), r -> {
                go.setEnabled(true);
                if (!r.ok()) { out.setTextColor(Theme.AMBER); out.setText("Gagal: " + Api.nice(r)); return; }
                JSONArray codes = r.json.optJSONArray("codes");
                StringBuilder sb = new StringBuilder();
                if (codes != null) for (int i = 0; i < codes.length(); i++) sb.append(codes.optString(i)).append("\n");
                String txt = sb.toString().trim();
                copy(a, txt);
                out.setTextColor(Theme.GREEN);
                out.setText(txt + "\n\n(sudah disalin)");
                reload(a, box);
            });
        });
        b.addView(go, Theme.lp(a, 12));
        b.addView(out, Theme.lp(a, 8));
        Button close = Theme.ghost(a, "Tutup", v -> dlg[0].dismiss());
        b.addView(close, Theme.lp(a, 6));
        dlg[0] = Theme.dialog(a, b);
    }

    // ---------- detail penyewa ----------

    private static String dt(long t) {
        return new SimpleDateFormat("dd MMM yyyy HH:mm", new Locale("id", "ID")).format(new Date(t));
    }

    private static void detail(final Activity a, final LinearLayout box, final JSONObject o) {
        final String code = o.optString("code");
        String nm = o.optString("note");
        LinearLayout b = Theme.dialogBox(a, nm.length() == 0 ? "(tanpa nama)" : nm);
        int s = statusOf(o);
        String st = s == S_REVOKED ? "DICABUT" : s == S_NEW ? "Belum diaktifkan" : s == S_EXPIRED ? "Habis " + dt(o.optLong("expiresAt"))
                : left(o).equals("permanen") ? "PERMANEN (beli putus)" : "Aktif s.d. " + dt(o.optLong("expiresAt"));
        b.addView(Theme.plain(a, st, 13, s == S_ACTIVE ? Theme.GREEN : s == S_SOON ? Theme.AMBER : s == S_NEW ? Theme.MUTED : Theme.RED, true), Theme.lp(a, 6));
        b.addView(Theme.plain(a, code, 12, Theme.MUTED, false), Theme.lp(a, 4));
        String dev = o.optString("deviceName");
        if (dev.length() > 0) b.addView(Theme.plain(a, "HP: " + dev + (o.optInt("resets") > 0 ? " · reset " + o.optInt("resets") + "x" : ""), 12, Theme.MUTED, false), Theme.lp(a, 2));
        final AlertDialog[] dlg = new AlertDialog[1];
        b.addView(Theme.ghost(a, "Salin kode", v -> { copy(a, code); Toast.makeText(a, "Kode disalin", Toast.LENGTH_SHORT).show(); }), Theme.lp(a, 12));
        b.addView(Theme.ghost(a, "Perpanjang", v -> {
            new AlertDialog.Builder(a).setTitle("Tambah masa aktif").setItems(PLAN_NAMES, (d, which) -> {
                JSONObject req = new JSONObject();
                try { req.put("code", code); req.put("plan", PLAN_KEYS[which]); } catch (Exception ignored) {}
                act(a, box, "/admin/extend", req, dlg[0]);
            }).show();
        }), Theme.lp(a, 6));
        b.addView(Theme.ghost(a, "Reset HP (pindah HP)", v -> {
            JSONObject req = new JSONObject();
            try { req.put("code", code); } catch (Exception ignored) {}
            act(a, box, "/admin/reset-device", req, dlg[0]);
        }), Theme.lp(a, 6));
        b.addView(Theme.ghost(a, o.optBoolean("revoked") ? "Aktifkan lagi" : "Cabut kode", v -> {
            JSONObject req = new JSONObject();
            try { req.put("code", code); } catch (Exception ignored) {}
            act(a, box, "/admin/revoke", req, dlg[0]);
        }), Theme.lp(a, 6));
        b.addView(Theme.ghost(a, "Ubah catatan / nama", v -> {
            dlg[0].dismiss();
            noteDialog(a, box, code, o.optString("note"));
        }), Theme.lp(a, 6));
        Button del = Theme.ghost(a, "Hapus kode", v -> {
            new AlertDialog.Builder(a).setTitle("Hapus kode ini?").setMessage("Kode tidak bisa dipakai lagi dan tidak bisa dikembalikan.")
                    .setPositiveButton("Hapus", (d, w) -> {
                        JSONObject req = new JSONObject();
                        try { req.put("code", code); } catch (Exception ignored) {}
                        act(a, box, "/admin/delete", req, dlg[0]);
                    }).setNegativeButton("Batal", null).show();
        });
        del.setTextColor(Theme.RED);
        b.addView(del, Theme.lp(a, 6));
        b.addView(Theme.ghost(a, "Tutup", v -> dlg[0].dismiss()), Theme.lp(a, 6));
        dlg[0] = Theme.dialog(a, b);
    }

    private static void noteDialog(final Activity a, final LinearLayout box, final String code, String cur) {
        LinearLayout b = Theme.dialogBox(a, "Catatan / nama penyewa");
        final EditText ed = Theme.input(a, cur, "mis. Hp oppo - Budi", false);
        b.addView(ed, Theme.lp(a, 10));
        final AlertDialog[] dlg = new AlertDialog[1];
        b.addView(Theme.primary(a, "Simpan", v -> {
            JSONObject req = new JSONObject();
            try { req.put("code", code); req.put("note", ed.getText().toString().trim()); } catch (Exception ignored) {}
            act(a, box, "/admin/note", req, dlg[0]);
        }), Theme.lp(a, 12));
        b.addView(Theme.ghost(a, "Batal", v -> dlg[0].dismiss()), Theme.lp(a, 6));
        dlg[0] = Theme.dialog(a, b);
    }

    private static void act(final Activity a, final LinearLayout box, String path, JSONObject req, final AlertDialog toClose) {
        Api.post(path, req, Lic.adminKey(a), r -> {
            if (toClose != null && toClose.isShowing()) toClose.dismiss();
            if (r.ok()) { Toast.makeText(a, "Berhasil", Toast.LENGTH_SHORT).show(); reload(a, box); }
            else Toast.makeText(a, "Gagal: " + Api.nice(r), Toast.LENGTH_LONG).show();
        });
    }

    private static void copy(Context c, String s) {
        ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("kode", s));
    }
}
