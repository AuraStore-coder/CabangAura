package com.aurastore.cabangpro;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.RemoteException;

import java.io.InputStream;

/**
 * Jembatan kecil ke Shizuku (protokol API v13), tanpa pustaka tambahan.
 * Dipakai hanya untuk menjalankan "logcat" sebagai shell agar log bisa dibaca di HP yang
 * memblokir jendela izin akses log (seperti Vivo). Tidak menyentuh aplikasi lain.
 */
public final class ShizukuBridge {
    private static final String SERVICE = "moe.shizuku.server.IShizukuService";
    private static final String PROCESS = "moe.shizuku.server.IRemoteProcess";
    // kode transaksi = id AIDL + 1
    private static final int TX_NEW_PROCESS = 8, TX_REQUEST_PERMISSION = 15, TX_CHECK_SELF_PERMISSION = 16,
            TX_ATTACH_APPLICATION = 18;
    private static final int PX_GET_INPUT = 2, PX_WAIT_FOR = 4, PX_DESTROY = 6;

    private static volatile IBinder binder;
    private static volatile boolean granted;
    private static final AppStub APP = new AppStub();

    private ShizukuBridge() {}

    static void onBinderReceived(IBinder b, String packageName) {
        if (b == null) return;
        binder = b;
        try { attach(b, packageName); } catch (Throwable ignored) {}
        try { granted = checkSelfPermission(); } catch (Throwable ignored) {}
        bump();
    }

    public static boolean isConnected() {
        IBinder b = binder;
        return b != null && b.pingBinder();
    }

    public static boolean isGranted() {
        if (!isConnected()) return false;
        if (!granted) {
            try { granted = checkSelfPermission(); } catch (Throwable ignored) {}
        }
        return granted;
    }

    public static boolean requestPermission() {
        IBinder b = binder;
        if (b == null) return false;
        Parcel d = Parcel.obtain(), r = Parcel.obtain();
        try {
            d.writeInterfaceToken(SERVICE);
            d.writeInt(1);
            b.transact(TX_REQUEST_PERMISSION, d, r, 0);
            r.readException();
            return true;
        } catch (Throwable t) {
            return false;
        } finally { d.recycle(); r.recycle(); }
    }

    private static boolean checkSelfPermission() throws RemoteException {
        IBinder b = binder;
        if (b == null) return false;
        Parcel d = Parcel.obtain(), r = Parcel.obtain();
        try {
            d.writeInterfaceToken(SERVICE);
            b.transact(TX_CHECK_SELF_PERMISSION, d, r, 0);
            r.readException();
            return r.readInt() != 0;
        } finally { d.recycle(); r.recycle(); }
    }

    private static void attach(IBinder b, String packageName) throws RemoteException {
        Bundle args = new Bundle();
        args.putInt("shizuku:attach-api-version", 13);
        args.putString("shizuku:attach-package-name", packageName);
        Parcel d = Parcel.obtain(), r = Parcel.obtain();
        try {
            d.writeInterfaceToken(SERVICE);
            d.writeStrongBinder(APP);
            d.writeInt(1);
            args.writeToParcel(d, 0);
            b.transact(TX_ATTACH_APPLICATION, d, r, 0);
            r.readException();
        } finally { d.recycle(); r.recycle(); }
    }

    /** Menjalankan perintah sebagai shell lewat Shizuku. */
    public static RemoteProcess newProcess(String[] cmd) throws RemoteException {
        IBinder b = binder;
        if (b == null) throw new RemoteException("Shizuku belum terhubung");
        Parcel d = Parcel.obtain(), r = Parcel.obtain();
        try {
            d.writeInterfaceToken(SERVICE);
            d.writeStringArray(cmd);
            d.writeStringArray(null);
            d.writeString(null);
            b.transact(TX_NEW_PROCESS, d, r, 0);
            r.readException();
            IBinder p = r.readStrongBinder();
            if (p == null) throw new RemoteException("Shizuku menolak menjalankan perintah");
            return new RemoteProcess(p);
        } finally { d.recycle(); r.recycle(); }
    }

    public static final class RemoteProcess {
        private final IBinder p;
        RemoteProcess(IBinder p) { this.p = p; }

        public InputStream getInputStream() throws RemoteException {
            Parcel d = Parcel.obtain(), r = Parcel.obtain();
            try {
                d.writeInterfaceToken(PROCESS);
                p.transact(PX_GET_INPUT, d, r, 0);
                r.readException();
                if (r.readInt() == 0) throw new RemoteException("tidak ada output");
                ParcelFileDescriptor fd = ParcelFileDescriptor.CREATOR.createFromParcel(r);
                return new ParcelFileDescriptor.AutoCloseInputStream(fd);
            } finally { d.recycle(); r.recycle(); }
        }

        public int waitFor() {
            Parcel d = Parcel.obtain(), r = Parcel.obtain();
            try {
                d.writeInterfaceToken(PROCESS);
                p.transact(PX_WAIT_FOR, d, r, 0);
                r.readException();
                return r.readInt();
            } catch (Throwable t) {
                return -1;
            } finally { d.recycle(); r.recycle(); }
        }

        public void destroy() {
            Parcel d = Parcel.obtain(), r = Parcel.obtain();
            try {
                d.writeInterfaceToken(PROCESS);
                p.transact(PX_DESTROY, d, r, 0);
            } catch (Throwable ignored) {
            } finally { d.recycle(); r.recycle(); }
        }
    }

    /** Jalankan perintah singkat lalu tunggu selesai. Mengembalikan kode keluar (0 = sukses). */
    public static int run(String... cmd) {
        try {
            RemoteProcess rp = newProcess(cmd);
            int code = rp.waitFor();
            rp.destroy();
            return code;
        } catch (Throwable t) {
            return -1;
        }
    }

    private static void bump() { synchronized (AuraState.LOCK) { AuraState.version++; } }

    /** Callback dari Shizuku (bindApplication & hasil permintaan izin). */
    private static final class AppStub extends Binder implements IInterface {
        private static final String DESC = "moe.shizuku.server.IShizukuApplication";
        AppStub() { attachInterface(this, DESC); }
        @Override public IBinder asBinder() { return this; }

        @Override protected boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            if (code == INTERFACE_TRANSACTION) { if (reply != null) reply.writeString(DESC); return true; }
            if (code == 2) { // bindApplication(Bundle)
                data.enforceInterface(DESC);
                Bundle b = data.readInt() != 0 ? Bundle.CREATOR.createFromParcel(data) : null;
                if (b != null) granted = b.getBoolean("shizuku:attach-reply-permission-granted", granted);
                bump();
                return true;
            }
            if (code == 3) { // dispatchRequestPermissionResult(int, Bundle)
                data.enforceInterface(DESC);
                data.readInt();
                Bundle b = data.readInt() != 0 ? Bundle.CREATOR.createFromParcel(data) : null;
                granted = b != null && b.getBoolean("shizuku:request-permission-reply-allowed", false);
                bump();
                return true;
            }
            if (code == 10001) { // showPermissionConfirmation (hanya untuk Sui)
                data.enforceInterface(DESC);
                if (reply != null) reply.writeNoException();
                return true;
            }
            return super.onTransact(code, data, reply, flags);
        }
    }
}
