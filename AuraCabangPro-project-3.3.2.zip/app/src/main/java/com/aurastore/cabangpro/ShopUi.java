package com.aurastore.cabangpro;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Tab Toko: daftar layanan Aura Store. Owner bisa mengubah produk; tersimpan di server supaya semua customer melihatnya. */
final class ShopUi {
    private ShopUi() {}

    static final class Item {
        String name = "", price = "", btn = "Pesan", icon = "🛍";
        Item() {}
        Item(String icon, String name, String price, String btn) { this.icon = icon; this.name = name; this.price = price; this.btn = btn; }
    }

    private static List<Item> defaults() {
        ArrayList<Item> l = new ArrayList<>();
        l.add(new Item("📱", "Ready Cabang", "1 – 10 Server · 500p\n10 – 19 Server · 600p\n20 Server · 1k", "Pesan via WhatsApp"));
        l.add(new Item("🤖", "Sewa Cabang Otomatis", "", "Order ke PM"));
        l.add(new Item("🎮", "Joki Lvl Up", "Rp1.500/s", "Pesan"));
        l.add(new Item("🏆", "Misi 40 Win", "Rp14.000/s", "Pesan"));
        l.add(new Item("💎", "Jual SC & GG", "", "Order ke PM"));
        l.add(new Item("⚡", "Sewa Claim VG", "", "Order ke PM"));
        l.add(new Item("📢", "Jasa Posting", "", "Order ke PM"));
        l.add(new Item("🔍", "Apk Zona ID", "", "Tersedia"));
        return l;
    }

    static List<Item> load(Context c) {
        String s = c.getSharedPreferences("shop", Context.MODE_PRIVATE).getString("items", "");
        if (s.length() == 0) return defaults();
        try {
            JSONArray a = new JSONArray(s);
            ArrayList<Item> l = new ArrayList<>();
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Item it = new Item(o.optString("icon", "🛍"), o.optString("name"), o.optString("price"), o.optString("btn", "Pesan"));
                if (it.name.length() > 0) l.add(it);
            }
            return l.isEmpty() ? defaults() : l;
        } catch (Exception e) {
            return defaults();
        }
    }

    private static JSONArray toJson(List<Item> l) throws Exception {
        JSONArray a = new JSONArray();
        for (Item it : l) {
            JSONObject o = new JSONObject();
            o.put("name", it.name); o.put("price", it.price); o.put("btn", it.btn); o.put("icon", it.icon);
            a.put(o);
        }
        return a;
    }

    private static void save(Context c, List<Item> l) {
        try { c.getSharedPreferences("shop", Context.MODE_PRIVATE).edit().putString("items", toJson(l).toString()).apply(); }
        catch (Exception ignored) {}
    }

    /** Ambil daftar terbaru dari server (diam-diam). Server kosong = pakai bawaan. */
    static void refresh(final Context c, final Runnable after) {
        Api.post("/shop", new JSONObject(), null, new Api.Cb() {
            @Override public void on(Api.Result r) {
                if (r.ok()) {
                    JSONArray a = r.json.optJSONArray("items");
                    if (a != null && a.length() > 0) {
                        c.getSharedPreferences("shop", Context.MODE_PRIVATE).edit().putString("items", a.toString()).apply();
                        if (after != null) after.run();
                    }
                }
            }
        });
    }

    static void render(final Activity a, LinearLayout box, final boolean owner, final Runnable rerender) {
        box.removeAllViews();
        box.addView(Theme.pageHead(a, "Layanan Aura Store", "Halo, selamat datang di Aura Store"));
        box.addView(Theme.text(a, "Pilih layanan lalu pesan lewat WhatsApp", 12, Theme.MUTED, false), Theme.lp(a, 2));
        if (owner) {
            box.addView(Theme.ghost(a, "✎  Atur produk toko", new View.OnClickListener() {
                @Override public void onClick(View v) { editor(a, rerender); }
            }), Theme.lp(a, 10));
        }
        List<Item> items = load(a);
        LinearLayout row = null;
        for (int i = 0; i < items.size(); i++) {
            final Item it = items.get(i);
            boolean wide = i == 0;
            View card = itemCard(a, it, wide);
            if (wide) {
                box.addView(card, Theme.lp(a, 12));
                continue;
            }
            if (row == null || row.getChildCount() >= 3) {
                row = new LinearLayout(a);
                row.setOrientation(LinearLayout.HORIZONTAL);
                box.addView(row, Theme.lp(a, 10));
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1f);
            int pos = row.getChildCount();
            lp.leftMargin = pos == 0 ? 0 : Theme.dp(a, 3);
            lp.rightMargin = pos == 2 ? 0 : Theme.dp(a, 3);
            row.addView(card, lp);
        }
        if (Cfg.CHANNEL.length() > 0) {
            LinearLayout cc = Theme.card(a);
            cc.addView(Theme.plain(a, "📣  Saluran Aura Store", 16, Theme.TEXT, true));
            cc.addView(Theme.plain(a, "Info terbaru, promo, dan pembaruan aplikasi", 11, Theme.MUTED, false), Theme.lp(a, 2));
            cc.addView(Theme.primary(a, "Buka Saluran", new View.OnClickListener() {
                @Override public void onClick(View v) {
                    try { a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(Cfg.CHANNEL))); }
                    catch (Exception e) { Toast.makeText(a, "Saluran tidak bisa dibuka", Toast.LENGTH_SHORT).show(); }
                }
            }), Theme.lp(a, 8));
            box.addView(cc, Theme.lp(a, 12));
        }
        while (row != null && row.getChildCount() < 3) {
            View pad = new View(a);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 1, 1f);
            lp.leftMargin = Theme.dp(a, 3);
            row.addView(pad, lp);
        }
    }

    private static final int[] TILE = {0xFF3B82F6, 0xFFF59E0B, 0xFFA855F7, 0xFFFACC15, 0xFFEF4444, 0xFF14B8A6, 0xFF22C55E, 0xFFEC4899, 0xFF06B6D4};

    private static View itemCard(final Activity a, final Item it, boolean wide) {
        LinearLayout card = Theme.card(a);
        if (wide) {
            card.setGravity(Gravity.START);
            LinearLayout head = new LinearLayout(a);
            head.setOrientation(LinearLayout.HORIZONTAL);
            head.setGravity(Gravity.CENTER_VERTICAL);
            head.addView(Theme.plain(a, it.icon, 24, Theme.TEXT, true));
            TextView nm = Theme.plain(a, it.name, 17, Theme.TEXT, true);
            nm.setPadding(Theme.dp(a, 10), 0, 0, 0);
            head.addView(nm);
            card.addView(head);
            if (it.price.length() > 0) {
                String[] lines = it.price.split("\n");
                for (String ln : lines) {
                    if (ln.trim().length() == 0) continue;
                    String left = ln, right = "";
                    int k = ln.lastIndexOf(" · ");
                    if (k > 0) { left = ln.substring(0, k); right = ln.substring(k + 3); }
                    LinearLayout r = new LinearLayout(a);
                    r.setOrientation(LinearLayout.HORIZONTAL);
                    r.setGravity(Gravity.CENTER_VERTICAL);
                    r.setPadding(Theme.dp(a, 12), Theme.dp(a, 8), Theme.dp(a, 12), Theme.dp(a, 8));
                    android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
                    g.setColor(0x4D000000);
                    g.setCornerRadius(Theme.dp(a, 10));
                    r.setBackground(g);
                    TextView l = Theme.plain(a, left, 12, Theme.TEXT, true);
                    r.addView(l, new LinearLayout.LayoutParams(0, -2, 1f));
                    if (right.length() > 0) r.addView(Theme.plain(a, right, 13, Theme.AMBER, true));
                    card.addView(r, Theme.lp(a, 6));
                }
            }
            Button b = Theme.primary(a, it.btn, new View.OnClickListener() {
                @Override public void onClick(View v) { order(a, it); }
            });
            b.setTextSize(13);
            card.addView(b, Theme.lp(a, 10));
            return card;
        }
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(Theme.dp(a, 6), Theme.dp(a, 10), Theme.dp(a, 6), Theme.dp(a, 10));
        int idx = Math.abs(it.name.hashCode()) % TILE.length;
        TextView ic = Theme.plain(a, it.icon, 18, Theme.TEXT, true);
        ic.setGravity(Gravity.CENTER);
        android.graphics.drawable.GradientDrawable tg = new android.graphics.drawable.GradientDrawable();
        tg.setColor(TILE[idx]);
        tg.setCornerRadius(Theme.dp(a, 10));
        ic.setBackground(tg);
        card.addView(ic, new LinearLayout.LayoutParams(Theme.dp(a, 40), Theme.dp(a, 40)));
        TextView nm = Theme.plain(a, it.name, 11, Theme.TEXT, true);
        nm.setGravity(Gravity.CENTER);
        nm.setPadding(0, Theme.dp(a, 6), 0, 0);
        card.addView(nm);
        TextView pr = Theme.plain(a, it.price.length() > 0 ? it.price.replace("\n", " / ") : " ", 10, Theme.AMBER, true);
        pr.setGravity(Gravity.CENTER);
        pr.setPadding(0, Theme.dp(a, 3), 0, 0);
        card.addView(pr);
        Button b = Theme.primary(a, it.btn, new View.OnClickListener() {
            @Override public void onClick(View v) { order(a, it); }
        });
        b.setTextSize(10);
        b.setMinHeight(Theme.dp(a, 32)); b.setMinimumHeight(Theme.dp(a, 32));
        b.setPadding(Theme.dp(a, 4), 0, Theme.dp(a, 4), 0);
        card.addView(b, Theme.lp(a, 8));
        return card;
    }

    private static void order(Activity a, Item it) {
        String t = "Halo admin Aura Store, saya mau pesan: " + it.name + (it.price.length() > 0 ? " (" + it.price.replace("\n", ", ") + ")" : "");
        try {
            a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + Cfg.WA + "?text=" + Uri.encode(t))));
        } catch (Exception e) {
            Toast.makeText(a, "WhatsApp tidak bisa dibuka", Toast.LENGTH_SHORT).show();
        }
    }

    // ---------- editor owner ----------

    static void editor(final Activity a, final Runnable rerender) {
        final List<Item> items = load(a);
        LinearLayout box = Theme.dialogBox(a, "Atur produk toko");
        TextView hint = Theme.plain(a, "Ketuk produk untuk mengubah. Perubahan langsung terlihat di semua customer.", 11, Theme.MUTED, false);
        box.addView(hint, Theme.lp(a, 4));
        ScrollView sv = new ScrollView(a);
        LinearLayout list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list);
        box.addView(sv, new LinearLayout.LayoutParams(-1, Theme.dp(a, 320)));
        final AlertDialog[] dlg = new AlertDialog[1];
        for (int i = 0; i < items.size(); i++) {
            final int idx = i;
            Item it = items.get(i);
            TextView row = Theme.plain(a, it.icon + "  " + it.name + (it.price.length() > 0 ? "   ·   " + it.price.replace("\n", " / ") : ""), 13, Theme.TEXT, false);
            row.setPadding(Theme.dp(a, 10), Theme.dp(a, 11), Theme.dp(a, 10), Theme.dp(a, 11));
            row.setBackground(Theme.outlined(a, 0x33101E45, Theme.STROKE, 12));
            row.setOnClickListener(v -> { dlg[0].dismiss(); editItem(a, items, idx, rerender); });
            list.addView(row, Theme.lp(a, 6));
        }
        Button add = Theme.primary(a, "+ Tambah produk", v -> {
            dlg[0].dismiss();
            items.add(new Item("🛍", "", "", "Pesan"));
            editItem(a, items, items.size() - 1, rerender);
        });
        box.addView(add, Theme.lp(a, 10));
        Button close = Theme.ghost(a, "Tutup", v -> dlg[0].dismiss());
        box.addView(close, Theme.lp(a, 6));
        dlg[0] = Theme.dialog(a, box);
    }

    private static void editItem(final Activity a, final List<Item> items, final int idx, final Runnable rerender) {
        final Item it = items.get(idx);
        LinearLayout box = Theme.dialogBox(a, it.name.length() == 0 ? "Produk baru" : "Ubah produk");
        final EditText icon = Theme.input(a, it.icon, "Ikon (emoji)", false);
        final EditText name = Theme.input(a, it.name, "Nama produk", false);
        final EditText price = Theme.input(a, it.price, "Harga (boleh 2 baris)", false);
        price.setSingleLine(false);
        price.setMinLines(2);
        final EditText btn = Theme.input(a, it.btn, "Tulisan tombol", false);
        box.addView(icon, Theme.lp(a, 10));
        box.addView(name, Theme.lp(a, 8));
        box.addView(price, Theme.lp(a, 8));
        box.addView(btn, Theme.lp(a, 8));
        final AlertDialog[] dlg = new AlertDialog[1];
        Button save = Theme.primary(a, "Simpan", v -> {
            String n = name.getText().toString().trim();
            if (n.length() == 0) { Toast.makeText(a, "Nama produk wajib diisi", Toast.LENGTH_SHORT).show(); return; }
            it.icon = icon.getText().toString().trim().length() == 0 ? "🛍" : icon.getText().toString().trim();
            it.name = n;
            it.price = price.getText().toString().trim();
            it.btn = btn.getText().toString().trim().length() == 0 ? "Pesan" : btn.getText().toString().trim();
            dlg[0].dismiss();
            push(a, items, rerender);
        });
        box.addView(save, Theme.lp(a, 12));
        if (it.name.length() > 0) {
            Button del = Theme.ghost(a, "Hapus produk", v -> {
                items.remove(idx);
                dlg[0].dismiss();
                push(a, items, rerender);
            });
            del.setTextColor(Theme.RED);
            box.addView(del, Theme.lp(a, 6));
        }
        Button cancel = Theme.ghost(a, "Batal", v -> dlg[0].dismiss());
        box.addView(cancel, Theme.lp(a, 6));
        dlg[0] = Theme.dialog(a, box);
    }

    private static void push(final Activity a, final List<Item> items, final Runnable rerender) {
        final ArrayList<Item> clean = new ArrayList<>();
        for (Item it : items) if (it.name.length() > 0) clean.add(it);
        if (clean.isEmpty()) { Toast.makeText(a, "Minimal harus ada satu produk", Toast.LENGTH_SHORT).show(); return; }
        JSONObject b = new JSONObject();
        try { b.put("items", toJson(clean)); } catch (Exception e) { return; }
        Api.post("/admin/shop-set", b, Lic.adminKey(a), r -> {
            if (r.ok()) {
                save(a, clean);
                Toast.makeText(a, "Produk tersimpan", Toast.LENGTH_SHORT).show();
                if (rerender != null) rerender.run();
            } else {
                Toast.makeText(a, "Gagal menyimpan: " + Api.nice(r), Toast.LENGTH_LONG).show();
            }
        });
    }
}
