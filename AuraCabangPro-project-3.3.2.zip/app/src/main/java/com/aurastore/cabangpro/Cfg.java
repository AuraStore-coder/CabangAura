package com.aurastore.cabangpro;

/** Pengaturan tetap aplikasi. SERVER dan nomor WhatsApp bisa diganti di sini. */
final class Cfg {
    /** Alamat Worker lisensi (Cloudflare). */
    /** Link saluran WhatsApp Aura Store. Kosong = kartu Saluran disembunyikan. */
    static final String CHANNEL = "";
    static final String SERVER = "https://auracabangpro-license.d1t-it44.workers.dev";
    /** Kunci publik untuk memeriksa tanda tangan server (pasangannya ada di secret SIGN_PRIVATE_KEY_CABANG). */
    static final String PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqDJvpujSkwLAT+AyAy79tKZVRcF2gfVe1fwtdI4u4RwSAhL4GxADi7YqTRJzTMEF/thzEMgqZfhwPkR80fOMPDfFMP2W3y1x6Lox8yWpXF7xTxhX9yqK3lYrCZHS+R7StQr/98neewZPp1HcZYmOXTr4JR52W1NuSYBs46I+YO+HWrJ2JyWuW9XUT3jWmnJUdabUx9xO/l17mUVpcvC2umz2ApDmbT+DjkQ+RINDUjB6cd+N7PWTIs1rHtQTJricRduPhtxsAIklX1zA7hH9FI3gRzirYe+3RdBSZ8hz9kid6Wl9xYaJVe9EsadKvvAuVpThRvAygabgdVnLC5zbWwIDAQAB";
    static final String APP = "cabang";
    /** Nomor WhatsApp admin (format internasional, tanpa +). */
    static final String WA = "6283163990883";
    /** Berapa hari aplikasi boleh jalan tanpa bisa menghubungi server. */
    static final long GRACE_MS = 3L * 86400L * 1000L;
    private Cfg() {}
}
