package com.aurastore.cabangpro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.widget.TextView;

/** Tulisan putih dengan garis tepi hitam tipis supaya jelas di atas gambar latar. */
class OutlineText extends TextView {
    private boolean drawing;
    boolean outline = true;

    OutlineText(Context c) { super(c); }

    @Override public void invalidate() { if (!drawing) super.invalidate(); }

    @Override protected void onDraw(Canvas canvas) {
        if (!outline) { super.onDraw(canvas); return; }
        int tc = getCurrentTextColor();
        Paint p = getPaint();
        drawing = true;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setStrokeWidth(Math.max(2f, getTextSize() * 0.11f));
        setTextColor(0xFF000000);
        super.onDraw(canvas);
        p.setStyle(Paint.Style.FILL);
        setTextColor(tc);
        super.onDraw(canvas);
        drawing = false;
    }
}
