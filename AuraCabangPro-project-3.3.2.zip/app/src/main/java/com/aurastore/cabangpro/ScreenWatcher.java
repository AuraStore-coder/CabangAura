package com.aurastore.cabangpro;

import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.nio.ByteBuffer;

/**
 * Melihat layar (seperti mata) untuk membaca bar loading oranye MLBB.
 * Hanya membaca piksel layar, tidak menyentuh / mengubah game.
 * fill = persentase bar loading (0..100), -1 jika bar tidak terlihat.
 */
public class ScreenWatcher {
    // posisi lintasan bar (relatif lebar layar landscape), diukur dari screenshot
    private static final float TRACK_START = 0.138f, TRACK_END = 0.855f;
    private static final float ROW_FROM = 0.84f, ROW_TO = 0.94f;

    private MediaProjection mp;
    private VirtualDisplay vd;
    private ImageReader ir;
    private HandlerThread ht;
    private volatile int fill = -1;
    private volatile boolean dialog;
    private volatile long lastFrameAt;
    private volatile boolean stopped;
    private long lastAnalyze;
    private int[] row;

    public int fill() { return fill; }
    /** kotak biru "System Notice / Loading resources failed" terlihat */
    public boolean dialog() { return dialog; }
    public long lastFrameAt() { return lastFrameAt; }
    public boolean isStopped() { return stopped; }

    public boolean start(Context ctx, int code, Intent data) {
        try {
            MediaProjectionManager mpm = ctx.getSystemService(MediaProjectionManager.class);
            mp = mpm.getMediaProjection(code, data);
            if (mp == null) return false;
            ht = new HandlerThread("aura-screen");
            ht.start();
            Handler h = new Handler(ht.getLooper());
            mp.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { stopped = true; fill = -1; }
            }, h);
            DisplayMetrics dm = new DisplayMetrics();
            ctx.getSystemService(WindowManager.class).getDefaultDisplay().getRealMetrics(dm);
            int big = Math.max(dm.widthPixels, dm.heightPixels), small = Math.min(dm.widthPixels, dm.heightPixels);
            // game selalu landscape: buat layar virtual landscape kecil (tinggi 400 px)
            int H = 400, W = Math.round(big * (400f / small));
            W -= W % 2;
            ir = ImageReader.newInstance(W, H, PixelFormat.RGBA_8888, 2);
            ir.setOnImageAvailableListener(this::onImage, h);
            vd = mp.createVirtualDisplay("aura-loading", W, H, dm.densityDpi / 3,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, ir.getSurface(), null, h);
            return vd != null;
        } catch (Throwable t) {
            AuraState.event("Gagal mulai lihat layar: " + t.getMessage());
            stop();
            return false;
        }
    }

    private void onImage(ImageReader r) {
        Image im = null;
        try {
            im = r.acquireLatestImage();
            if (im == null) return;
            long now = System.currentTimeMillis();
            if (now - lastAnalyze < 200) return;
            lastAnalyze = now;
            int f = analyze(im);
            fill = f;
            dialog = f < 0 && dimBar(im) && detectDialog(im);
            lastFrameAt = now;
        } catch (Throwable ignored) {
        } finally {
            if (im != null) im.close();
        }
    }

    static boolean orange(int r, int g, int b) {
        return r >= 200 && g >= 115 && g <= 228 && b <= 135 && r - b >= 105 && r - g >= 22;
    }

    private int analyze(Image im) {
        Image.Plane p = im.getPlanes()[0];
        ByteBuffer buf = p.getBuffer();
        int ps = p.getPixelStride(), rs = p.getRowStride();
        int W = im.getWidth(), H = im.getHeight();
        int x0 = Math.round(W * 0.10f), x1 = Math.round(W * 0.90f);
        int startMin = Math.round(W * (TRACK_START - 0.035f)), startMax = Math.round(W * (TRACK_START + 0.035f));
        int maxGap = Math.max(3, Math.round(W * 0.015f));
        float trackW = W * (TRACK_END - TRACK_START);
        int best = -1;
        for (int y = Math.round(H * ROW_FROM); y <= Math.round(H * ROW_TO) && y < H; y++) {
            int base = y * rs;
            int left = -1, right = -1, gap = 0;
            for (int x = x0; x < x1; x++) {
                int o = base + x * ps;
                int R = buf.get(o) & 0xff, G = buf.get(o + 1) & 0xff, B = buf.get(o + 2) & 0xff;
                if (orange(R, G, B)) {
                    if (left < 0) left = x;
                    right = x; gap = 0;
                } else if (left >= 0) {
                    if (++gap > maxGap) break;
                }
            }
            if (left < startMin || left > startMax) continue;
            if (right - left < W * 0.01f) continue;
            int f = Math.round((right - W * TRACK_START) * 100f / trackW);
            f = Math.max(0, Math.min(100, f));
            if (f > best) best = f;
        }
        return best;
    }

    /** Bar loading oranye yang tampak GELAP (layar diredupkan oleh kotak dialog). Hanya ada di layar loading. */
    private boolean dimBar(Image im) {
        Image.Plane p = im.getPlanes()[0];
        ByteBuffer buf = p.getBuffer();
        int ps = p.getPixelStride(), rs = p.getRowStride();
        int W = im.getWidth(), H = im.getHeight();
        int x0 = Math.round(W * 0.10f), x1 = Math.round(W * 0.90f);
        int startMin = Math.round(W * (TRACK_START - 0.04f)), startMax = Math.round(W * (TRACK_START + 0.04f));
        int maxGap = Math.max(3, Math.round(W * 0.015f));
        for (int y = Math.round(H * ROW_FROM); y <= Math.round(H * ROW_TO) && y < H; y++) {
            int base = y * rs;
            int left = -1, right = -1, gap = 0;
            for (int x = x0; x < x1; x++) {
                int o = base + x * ps;
                int R = buf.get(o) & 0xff, G = buf.get(o + 1) & 0xff, B = buf.get(o + 2) & 0xff;
                boolean dim = R >= 50 && R <= 215 && R > G && G > B && R - B >= 35 && G * 100 >= R * 45 && G * 100 <= R * 85;
                if (dim) { if (left < 0) left = x; right = x; gap = 0; }
                else if (left >= 0 && ++gap > maxGap) break;
            }
            if (left >= startMin && left <= startMax && right - left >= W * 0.01f) return true;
        }
        return false;
    }

    /** Kotak dialog: area tengah layar sebagian besar biru rata (bukan gambar latar yang beragam). */
    private boolean detectDialog(Image im) {
        Image.Plane p = im.getPlanes()[0];
        ByteBuffer buf = p.getBuffer();
        int ps = p.getPixelStride(), rs = p.getRowStride();
        int W = im.getWidth(), H = im.getHeight();
        int n = 0, blue = 0;
        int[] rr = new int[192], gg = new int[192], bb = new int[192];
        for (int gy = 0; gy < 12; gy++) {
            for (int gx = 0; gx < 16; gx++) {
                int x = Math.round(W * (0.34f + 0.32f * gx / 15f)), y = Math.round(H * (0.30f + 0.40f * gy / 11f));
                int o = y * rs + x * ps;
                int R = buf.get(o) & 0xff, G = buf.get(o + 1) & 0xff, B = buf.get(o + 2) & 0xff;
                rr[n] = R; gg[n] = G; bb[n] = B; n++;
                if (B >= 110 && B - R >= 45 && B >= G) blue++;
            }
        }
        if (blue < n * 0.5f) return false;
        int[] mr = new int[blue], mg = new int[blue], mb = new int[blue];
        int k = 0;
        for (int i = 0; i < n; i++) if (bb[i] >= 110 && bb[i] - rr[i] >= 45 && bb[i] >= gg[i]) { mr[k] = rr[i]; mg[k] = gg[i]; mb[k] = bb[i]; k++; }
        java.util.Arrays.sort(mr); java.util.Arrays.sort(mg); java.util.Arrays.sort(mb);
        int r0 = mr[k / 2], g0 = mg[k / 2], b0 = mb[k / 2];
        int near = 0;
        for (int i = 0; i < n; i++)
            if (Math.abs(rr[i] - r0) + Math.abs(gg[i] - g0) + Math.abs(bb[i] - b0) <= 45) near++;
        return near >= n * 0.4f;
    }

    public void stop() {
        try { if (vd != null) vd.release(); } catch (Throwable ignored) {}
        try { if (ir != null) ir.close(); } catch (Throwable ignored) {}
        try { if (mp != null) mp.stop(); } catch (Throwable ignored) {}
        try { if (ht != null) ht.quitSafely(); } catch (Throwable ignored) {}
        vd = null; ir = null; mp = null; ht = null;
        stopped = true;
    }
}
