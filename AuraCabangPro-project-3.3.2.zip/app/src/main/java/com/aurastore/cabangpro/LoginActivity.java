package com.aurastore.cabangpro;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Layar masuk: kode aktivasi (customer) atau password owner (ketuk logo 5x). */
public class LoginActivity extends Activity {
    private EditText codeEd, passEd;
    private TextView msg, ownerMsg;
    private LinearLayout codeCard, ownerCard;
    private Button activateBtn, ownerBtn;
    private int taps;
    private long lastTap;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF070B1E);
        getWindow().setNavigationBarColor(0xFF070B1E);
        if (Lic.localValid(this)) { goMain(); return; }
        setContentView(buildUi());
    }

    private void goMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    private View buildUi() {
        final Context c = this;
        FrameLayout bg = Theme.background(c, true);
        ScrollView sv = new ScrollView(c);
        sv.setFillViewport(true);
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(Theme.dp(c, 20), Theme.dp(c, 36), Theme.dp(c, 20), Theme.dp(c, 28));
        sv.addView(col, new FrameLayout.LayoutParams(-1, -2));
        bg.addView(sv, new FrameLayout.LayoutParams(-1, -1));

        View logo = Theme.logo(c, 130);
        LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(Theme.dp(c, 130), Theme.dp(c, 130));
        ll.gravity = Gravity.CENTER_HORIZONTAL;
        col.addView(logo, ll);
        logo.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                long n = System.currentTimeMillis();
                if (n - lastTap > 1500) taps = 0;
                lastTap = n;
                if (++taps >= 5) { taps = 0; showOwner(true); }
            }
        });

        TextView title = Theme.text(c, "AuraCabangPro", 28, Theme.TEXT, true);
        title.setGravity(Gravity.CENTER);
        col.addView(title, Theme.lp(c, 6));
        TextView sub = Theme.text(c, "Cabang Otomatis by Aura Store", 14, Theme.CYAN, true);
        sub.setGravity(Gravity.CENTER);
        col.addView(sub, Theme.lp(c, 2));
        TextView ver = Theme.text(c, "Versi " + BuildInfo.VERSION + " · Aura Store", 11, Theme.MUTED, false);
        ver.setGravity(Gravity.CENTER);
        col.addView(ver, Theme.lp(c, 2));

        // kartu kode aktivasi
        codeCard = Theme.card(c);
        TextView h = Theme.plain(c, "Masukkan Kode Aktivasi", 15, Theme.TEXT, true);
        h.setGravity(Gravity.CENTER);
        codeCard.addView(h);
        codeEd = Theme.input(c, "", "AURA-XXXX-XXXX-XXXX", false);
        codeEd.setGravity(Gravity.CENTER);
        codeEd.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        codeCard.addView(codeEd, Theme.lp(c, 10));
        activateBtn = Theme.primary(c, "Aktifkan", new View.OnClickListener() {
            @Override public void onClick(View v) { doActivate(); }
        });
        codeCard.addView(activateBtn, Theme.lp(c, 10));
        msg = Theme.plain(c, "", 12, Theme.AMBER, false);
        msg.setGravity(Gravity.CENTER);
        codeCard.addView(msg, Theme.lp(c, 8));
        col.addView(codeCard, Theme.lp(c, 18));

        // kartu login owner (muncul setelah logo diketuk 5x)
        ownerCard = Theme.card(c);
        TextView crown = Theme.plain(c, "👑", 28, Theme.AMBER, true);
        crown.setGravity(Gravity.CENTER);
        ownerCard.addView(crown);
        TextView oh = Theme.plain(c, "Login Owner", 16, Theme.TEXT, true);
        oh.setGravity(Gravity.CENTER);
        ownerCard.addView(oh, Theme.lp(c, 2));
        passEd = Theme.input(c, "", "Password owner", false);
        passEd.setGravity(Gravity.CENTER);
        passEd.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        ownerCard.addView(passEd, Theme.lp(c, 10));
        ownerBtn = Theme.primary(c, "Masuk Owner", new View.OnClickListener() {
            @Override public void onClick(View v) { doOwner(); }
        });
        ownerCard.addView(ownerBtn, Theme.lp(c, 10));
        ownerMsg = Theme.plain(c, "Hanya muncul jika logo diketuk 5x. Customer tidak tahu tombol ini.", 11, Theme.MUTED, false);
        ownerMsg.setGravity(Gravity.CENTER);
        ownerCard.addView(ownerMsg, Theme.lp(c, 8));
        ownerCard.addView(Theme.ghost(c, "Kembali", new View.OnClickListener() {
            @Override public void onClick(View v) { showOwner(false); }
        }), Theme.lp(c, 8));
        ownerCard.setVisibility(View.GONE);
        col.addView(ownerCard, Theme.lp(c, 18));

        // peringatan
        LinearLayout warn = new LinearLayout(c);
        warn.setOrientation(LinearLayout.VERTICAL);
        warn.setBackground(Theme.outlined(c, 0x66300A12, Theme.RED, 16));
        warn.setPadding(Theme.dp(c, 14), Theme.dp(c, 10), Theme.dp(c, 14), Theme.dp(c, 12));
        TextView w1 = Theme.plain(c, "⚠ PERINGATAN PENTING", 12, Theme.RED, true);
        w1.setGravity(Gravity.CENTER);
        warn.addView(w1);
        TextView w2 = Theme.plain(c, "KODE BERLAKU UNTUK 1 PERANGKAT.\nDILARANG MENJUAL / MEMBAGIKAN KODE.\nKODE DI PERANGKAT LAIN AKAN DITOLAK.\n\"AURA STORE\"", 10.5f, Theme.TEXT, true);
        w2.setGravity(Gravity.CENTER);
        warn.addView(w2, Theme.lp(c, 4));
        col.addView(warn, Theme.lp(c, 14));

        Button wa = Theme.ghost(c, "SEWA APLIKASI VIA WHATSAPP", new View.OnClickListener() {
            @Override public void onClick(View v) { openWhatsApp(); }
        });
        col.addView(wa, Theme.lp(c, 12));

        TextView id = Theme.text(c, "📱 ID HP: " + Lic.deviceShort(c) + "   (ketuk untuk salin)", 11, Theme.MUTED, false);
        id.setGravity(Gravity.CENTER);
        id.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("id", Lic.deviceShort(LoginActivity.this)));
                Toast.makeText(LoginActivity.this, "ID HP disalin", Toast.LENGTH_SHORT).show();
            }
        });
        col.addView(id, Theme.lp(c, 12));
        return bg;
    }

    private void showOwner(boolean on) {
        ownerCard.setVisibility(on ? View.VISIBLE : View.GONE);
        codeCard.setVisibility(on ? View.GONE : View.VISIBLE);
    }

    private void doActivate() {
        activateBtn.setEnabled(false);
        activateBtn.setText("Memeriksa…");
        msg.setTextColor(Theme.MUTED);
        msg.setText("Menghubungi server…");
        Lic.activate(this, codeEd.getText().toString(), new Lic.Done() {
            @Override public void on(boolean ok, String message) {
                activateBtn.setEnabled(true);
                activateBtn.setText("Aktifkan");
                if (ok) { Toast.makeText(LoginActivity.this, "Aktivasi berhasil", Toast.LENGTH_SHORT).show(); goMain(); return; }
                msg.setTextColor(Theme.AMBER);
                msg.setText(message);
            }
        });
    }

    private void doOwner() {
        ownerBtn.setEnabled(false);
        ownerBtn.setText("Memeriksa…");
        Lic.ownerLogin(this, passEd.getText().toString(), new Lic.Done() {
            @Override public void on(boolean ok, String message) {
                ownerBtn.setEnabled(true);
                ownerBtn.setText("Masuk Owner");
                if (ok) { goMain(); return; }
                ownerMsg.setTextColor(Theme.AMBER);
                ownerMsg.setText(message);
            }
        });
    }

    private void openWhatsApp() {
        String t = "Halo admin Aura Store, saya mau sewa aplikasi Aura Cabang Pro. ID HP saya: " + Lic.deviceShort(this);
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + Cfg.WA + "?text=" + Uri.encode(t))));
        } catch (Exception e) {
            Toast.makeText(this, "WhatsApp tidak bisa dibuka", Toast.LENGTH_SHORT).show();
        }
    }
}
