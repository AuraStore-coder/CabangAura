package com.aurastore.cabangpro;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.provider.Settings;

import org.json.JSONObject;

import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;

/** Lisensi kode sewa: terikat ke 1 HP, diperiksa lewat tanda tangan server. Owner masuk lewat password. */
final class Lic {
    private Lic() {}

    interface Done { void on(boolean ok, String message); }

    private static SharedPreferences sp(Context c) { return c.getSharedPreferences("lic", Context.MODE_PRIVATE); }

    // ---------- identitas HP ----------

    static String deviceId(Context c) {
        String a = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ANDROID_ID);
        if (a == null) a = "none";
        return hex(sha(a + "|aura-cabang-pro")).substring(0, 16).toUpperCase();
    }

    /** Bentuk pendek yang ditampilkan ke customer, mis. 3F9A-21C7. */
    static String deviceShort(Context c) {
        String d = deviceId(c);
        return d.substring(0, 4) + "-" + d.substring(4, 8);
    }

    static String deviceName() {
        String m = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER;
        String d = Build.MODEL == null ? "" : Build.MODEL;
        return (m + " " + d).trim();
    }

    // ---------- status lokal ----------

    static boolean isOwner(Context c) { return sp(c).getBoolean("owner", false); }

    static String adminKey(Context c) { return sp(c).getString("adminKey", ""); }

    static String code(Context c) { return sp(c).getString("code", ""); }

    static long expiresAt(Context c) { return sp(c).getLong("exp", 0L); }

    /** Waktu "sekarang" menurut server (HP diputar mundur tidak membantu). */
    static long nowEff(Context c) {
        SharedPreferences p = sp(c);
        long adj = System.currentTimeMillis() + p.getLong("off", 0L);
        long seen = p.getLong("seen", 0L);
        if (adj > seen + 30000L) p.edit().putLong("seen", adj).apply();
        return Math.max(adj, seen);
    }

    /** Boleh dipakai sekarang? Tanpa internet, tetap boleh sampai batas toleransi. */
    static boolean localValid(Context c) {
        if (isOwner(c)) return true;
        SharedPreferences p = sp(c);
        if (p.getString("code", "").length() == 0) return false;
        long exp = p.getLong("exp", 0L);
        if (exp <= 0L) return false;
        long now = nowEff(c);
        if (now >= exp) return false;
        long lastOk = p.getLong("lastOk", 0L);
        return now - lastOk <= Cfg.GRACE_MS;
    }

    /** Teks sisa waktu untuk layar. */
    static String remainingText(Context c) {
        if (isOwner(c)) return "Owner";
        long ms = expiresAt(c) - nowEff(c);
        if (ms <= 0) return "Habis";
        long days = ms / 86400000L;
        if (days > 7300) return "Permanen (Beli Putus)";
        if (days >= 1) return "sisa " + days + " hari";
        long h = ms / 3600000L;
        if (h >= 1) return "sisa " + h + " jam";
        return "sisa " + Math.max(1, ms / 60000L) + " menit";
    }

    static String expiryDateText(Context c) {
        long exp = expiresAt(c);
        if (exp <= 0) return "-";
        if ((exp - nowEff(c)) / 86400000L > 7300) return "Permanen";
        return new java.text.SimpleDateFormat("dd MMM yyyy", new java.util.Locale("id", "ID")).format(new java.util.Date(exp));
    }

    static String maskedCode(Context c) {
        String s = code(c);
        if (s.length() < 9) return s;
        return s.substring(0, 9) + "-••••";
    }

    static void clear(Context c) {
        sp(c).edit().remove("code").remove("exp").remove("lastOk").remove("off").remove("seen").apply();
    }

    static void ownerLogout(Context c) {
        sp(c).edit().remove("owner").remove("adminKey").apply();
    }

    // ---------- aktivasi & pemeriksaan ----------

    static void activate(final Context c, String rawCode, final Done done) {
        final String code = rawCode == null ? "" : rawCode.trim().toUpperCase();
        if (code.length() < 6) { done.on(false, "Masukkan kode aktivasi dulu."); return; }
        callLicense(c, "/activate", code, done);
    }

    /** Periksa ulang ke server. Gagal karena internet = tetap dianggap sah (toleransi); ditolak server = lisensi dihapus. */
    static void recheck(final Context c, final Done done) {
        if (isOwner(c)) { done.on(true, ""); return; }
        String code = code(c);
        if (code.length() == 0) { done.on(false, ""); return; }
        callLicense(c, "/check", code, done);
    }

    private static void callLicense(final Context c, final String path, final String code, final Done done) {
        final String nonce = randomHex(16);
        final String dev = deviceId(c);
        JSONObject b = new JSONObject();
        try {
            b.put("code", code); b.put("deviceId", dev); b.put("deviceName", deviceName());
            b.put("nonce", nonce); b.put("app", Cfg.APP);
        } catch (Exception ignored) {}
        Api.post(path, b, null, new Api.Cb() {
            @Override public void on(Api.Result r) {
                if (r.status == 0) {
                    // tidak ada internet: biarkan lisensi lokal menentukan
                    done.on(localValid(c), Api.nice(r));
                    return;
                }
                if (!r.ok()) {
                    if (r.status == 403 || r.status == 404 || r.status == 410) clear(c);
                    done.on(false, Api.nice(r));
                    return;
                }
                try {
                    String payload = r.json.getString("payload");
                    String sig = r.json.getString("sig");
                    if (!verify(payload, sig)) { done.on(false, "Balasan server tidak sah."); return; }
                    JSONObject p = new JSONObject(payload);
                    if (!"lic".equals(p.optString("t")) || !nonce.equals(p.optString("nonce"))
                            || !dev.equals(p.optString("dev")) || !code.equals(p.optString("code"))) {
                        done.on(false, "Balasan server tidak cocok."); return;
                    }
                    long exp = p.getLong("exp");
                    long now = p.getLong("now");
                    sp(c).edit().putString("code", code).putLong("exp", exp)
                            .putLong("off", now - System.currentTimeMillis())
                            .putLong("seen", now).putLong("lastOk", now).apply();
                    done.on(true, "");
                } catch (Exception e) {
                    done.on(false, "Balasan server rusak.");
                }
            }
        });
    }

    // ---------- owner ----------

    static void ownerLogin(final Context c, final String password, final Done done) {
        if (password == null || password.trim().length() == 0) { done.on(false, "Masukkan password owner."); return; }
        final String nonce = randomHex(16);
        final String dev = deviceId(c);
        final String key = password.trim();
        JSONObject b = new JSONObject();
        try { b.put("deviceId", dev); b.put("nonce", nonce); b.put("app", Cfg.APP); } catch (Exception ignored) {}
        Api.post("/admin/ping", b, key, new Api.Cb() {
            @Override public void on(Api.Result r) {
                if (r.status == 401) { done.on(false, "Password owner salah."); return; }
                if (!r.ok()) { done.on(false, Api.nice(r)); return; }
                try {
                    String payload = r.json.getString("payload");
                    if (!verify(payload, r.json.getString("sig"))) { done.on(false, "Balasan server tidak sah."); return; }
                    JSONObject p = new JSONObject(payload);
                    if (!"owner".equals(p.optString("t")) || !nonce.equals(p.optString("nonce")) || !dev.equals(p.optString("dev"))) {
                        done.on(false, "Balasan server tidak cocok."); return;
                    }
                    sp(c).edit().putBoolean("owner", true).putString("adminKey", key).apply();
                    done.on(true, "");
                } catch (Exception e) {
                    done.on(false, "Balasan server rusak.");
                }
            }
        });
    }

    // ---------- kripto ----------

    private static boolean verify(String payload, String sigB64) {
        try {
            byte[] der = java.util.Base64.getDecoder().decode(Cfg.PUBLIC_KEY);
            PublicKey pk = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(der));
            Signature s = Signature.getInstance("SHA256withRSA");
            s.initVerify(pk);
            s.update(payload.getBytes("UTF-8"));
            return s.verify(java.util.Base64.getDecoder().decode(sigB64));
        } catch (Exception e) {
            return false;
        }
    }

    private static byte[] sha(String s) {
        try { return MessageDigest.getInstance("SHA-256").digest(s.getBytes("UTF-8")); }
        catch (Exception e) { return new byte[32]; }
    }

    private static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x & 0xff));
        return sb.toString();
    }

    private static String randomHex(int n) {
        byte[] b = new byte[n];
        new SecureRandom().nextBytes(b);
        return hex(b).substring(0, n);
    }
}
