package com.aurastore.cabangpro;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/** Status bersama antara layar, layanan, dan pembaca log. Semua akses lewat LOCK. */
public final class AuraState {
    public static final Object LOCK = new Object();

    public static final class AppEntry {
        public final String pkg;
        public final String label;
        public String server = "";
        public boolean launched1, launched2;
        public boolean initialStartSeen;
        public int restarts;   // proses dimulai ulang = relog
        public int kills;      // proses dimatikan sistem
        public String lastKillReason = "";
        public int rerolls;            // berapa kali diacak ulang
        public String history = "";    // ZoneID sebelumnya, mis. "57097→"
        public boolean closedDone;     // sudah selesai Step 2 lalu ditutup untuk melegakan RAM
        public long step2At;
        public long step1At;           // waktu dibuka di Step 1           // waktu dibuka di Step 2
        public boolean dropped;        // dibuang karena ZoneID kembar dengan cangkang sebelumnya
        public String droppedFor = "";

        AppEntry(String pkg, String label) { this.pkg = pkg; this.label = label; }
    }

    public static final ArrayList<AppEntry> apps = new ArrayList<>();
    public static final HashMap<String, AppEntry> byPkg = new HashMap<>();
    public static boolean running;
    public static int step;          // 0 = belum, 1, 2
    public static int pos;           // posisi dalam step (1..n)
    public static String currentPkg = "";
    public static boolean logReaderActive;
    public static boolean waitingLogConsent;
    /** Server dengan nomor di bawah ini dianggap server lama. */
    public static int minServer = 57092;
    /** Paket yang sedang ditutup untuk diacak ulang (kematiannya bukan relog). */
    public static String rerollingPkg = "";
    /** Mode pantau: launcher tidak membuka aplikasi, hanya membaca ZoneID & relog saat Anda membuka manual. */
    public static boolean monitor;
    public static String logReaderError = "";
    public static final ArrayList<String> events = new ArrayList<>();
    public static int version;       // naik setiap ada perubahan, untuk refresh UI

    private AuraState() {}

    public static void reset(List<String[]> pkgLabels) {
        synchronized (LOCK) {
            apps.clear(); byPkg.clear(); events.clear();
            for (String[] pl : pkgLabels) {
                AppEntry e = new AppEntry(pl[0], pl[1]);
                apps.add(e); byPkg.put(pl[0], e);
            }
            step = 0; pos = 0; currentPkg = ""; logReaderError = "";
            version++;
        }
    }

    public static void event(String msg) {
        String t = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        synchronized (LOCK) {
            events.add(0, t + "  " + msg);
            while (events.size() > 150) events.remove(events.size() - 1);
            version++;
        }
    }

    /** Simpan hasil ke file supaya tetap ada walau launcher sempat dihentikan sistem. */
    public static void save(android.content.Context c) {
        try {
            org.json.JSONObject o = new org.json.JSONObject();
            org.json.JSONArray a = new org.json.JSONArray();
            org.json.JSONArray ev = new org.json.JSONArray();
            synchronized (LOCK) {
                for (AppEntry e : apps) {
                    org.json.JSONObject j = new org.json.JSONObject();
                    j.put("pkg", e.pkg); j.put("label", e.label); j.put("server", e.server);
                    j.put("l1", e.launched1); j.put("l2", e.launched2); j.put("rs", e.restarts);
                    j.put("k", e.kills); j.put("kr", e.lastKillReason); j.put("dr", e.dropped);
                    a.put(j);
                }
                for (String s : events) ev.put(s);
                o.put("step", step); o.put("pos", pos);
            }
            o.put("apps", a); o.put("events", ev);
            java.io.FileOutputStream f = c.openFileOutput("last_result.json", android.content.Context.MODE_PRIVATE);
            f.write(o.toString().getBytes("UTF-8"));
            f.close();
        } catch (Exception ignored) {}
    }

    /** Muat hasil terakhir jika layanan sudah tidak berjalan dan status di memori kosong. */
    public static void loadIfEmpty(android.content.Context c) {
        synchronized (LOCK) { if (running || !apps.isEmpty()) return; }
        try {
            java.io.FileInputStream f = c.openFileInput("last_result.json");
            java.io.ByteArrayOutputStream b = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192]; int n;
            while ((n = f.read(buf)) > 0) b.write(buf, 0, n);
            f.close();
            org.json.JSONObject o = new org.json.JSONObject(b.toString("UTF-8"));
            org.json.JSONArray a = o.getJSONArray("apps");
            org.json.JSONArray ev = o.getJSONArray("events");
            synchronized (LOCK) {
                apps.clear(); byPkg.clear(); events.clear();
                for (int i = 0; i < a.length(); i++) {
                    org.json.JSONObject j = a.getJSONObject(i);
                    AppEntry e = new AppEntry(j.getString("pkg"), j.optString("label"));
                    e.server = j.optString("server"); e.launched1 = j.optBoolean("l1"); e.launched2 = j.optBoolean("l2");
                    e.restarts = j.optInt("rs"); e.kills = j.optInt("k"); e.lastKillReason = j.optString("kr"); e.dropped = j.optBoolean("dr");
                    apps.add(e); byPkg.put(e.pkg, e);
                }
                for (int i = 0; i < ev.length(); i++) events.add(ev.getString(i));
                step = o.optInt("step"); pos = o.optInt("pos");
                version++;
            }
        } catch (Exception ignored) {}
    }

    /** Panggil di dalam LOCK. */
    public static boolean isOld(AppEntry e) {
        if (e.server.isEmpty() || minServer <= 0) return false;
        try { return Integer.parseInt(e.server) < minServer; } catch (Exception x) { return false; }
    }

    /** Jumlah aplikasi lain yang punya ID server sama. Panggil di dalam LOCK. */
    /** Hapus semua hasil & catatan (di memori dan file). */
    public static void clearAll(android.content.Context c) {
        synchronized (LOCK) {
            for (AppEntry e : apps) {
                e.server = ""; e.launched1 = false; e.launched2 = false; e.initialStartSeen = false;
                e.restarts = 0; e.kills = 0; e.lastKillReason = ""; e.rerolls = 0; e.history = "";
                e.dropped = false; e.droppedFor = "";
            }
            apps.clear(); byPkg.clear(); events.clear();
            step = 0; pos = 0; currentPkg = "";
            version++;
        }
        try { c.deleteFile("last_result.json"); } catch (Exception ignored) {}
    }

    public static int duplicatesOf(AppEntry e) {
        if (e.server.isEmpty()) return 0;
        int n = 0;
        for (AppEntry o : apps) if (o != e && e.server.equals(o.server)) n++;
        return n;
    }
}
