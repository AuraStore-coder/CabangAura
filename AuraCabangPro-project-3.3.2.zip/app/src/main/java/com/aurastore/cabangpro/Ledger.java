package com.aurastore.cabangpro;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;

/** Buku catatan harian owner: server terbuat, server terjual, dan hasil uang per hari. Tersimpan di HP ini saja, tidak ikut reset stok. */
final class Ledger {
    private Ledger() {}

    static final class Day {
        String key;      // yyyyMMdd
        long made, sold, money;
    }

    private static SharedPreferences sp(Context c) { return c.getSharedPreferences("ledger", Context.MODE_PRIVATE); }

    static String todayKey() { return new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date()); }

    private static JSONObject load(Context c) {
        try { return new JSONObject(sp(c).getString("d", "{}")); } catch (Exception e) { return new JSONObject(); }
    }

    private static void save(Context c, JSONObject o) { sp(c).edit().putString("d", o.toString()).apply(); }

    static Day get(Context c, String key) {
        Day d = new Day();
        d.key = key;
        JSONObject o = load(c).optJSONObject(key);
        if (o != null) { d.made = o.optLong("m", 0); d.sold = o.optLong("s", 0); d.money = o.optLong("r", 0); }
        return d;
    }

    static synchronized void put(Context c, Day d) {
        try {
            JSONObject all = load(c);
            if (d.made == 0 && d.sold == 0 && d.money == 0) { all.remove(d.key); }
            else {
                JSONObject o = new JSONObject();
                o.put("m", d.made); o.put("s", d.sold); o.put("r", d.money);
                all.put(d.key, o);
            }
            save(c, all);
        } catch (Exception ignored) {}
    }

    static void delete(Context c, String key) {
        try { JSONObject all = load(c); all.remove(key); save(c, all); } catch (Exception ignored) {}
    }

    /** Otomatis: dipanggil tiap putaran selesai, menambah jumlah server terbuat hari ini. */
    static synchronized void addMade(Context c, int n) {
        if (n <= 0) return;
        Day d = get(c, todayKey());
        d.made += n;
        put(c, d);
    }

    /** Tambah penjualan ke hari tertentu. */
    static synchronized void addSale(Context c, String key, long sold, long money) {
        Day d = get(c, key);
        d.sold += sold; d.money += money;
        put(c, d);
    }

    /** Gabungkan hari "from" ke hari "to": semua angka dijumlah, hari "from" dihapus. */
    static synchronized void merge(Context c, String from, String to) {
        if (from.equals(to)) return;
        Day a = get(c, from), b = get(c, to);
        b.made += a.made; b.sold += a.sold; b.money += a.money;
        put(c, b);
        delete(c, from);
    }

    /** Semua hari yang punya catatan, terbaru dulu. */
    static ArrayList<Day> list(Context c) {
        ArrayList<Day> out = new ArrayList<>();
        JSONObject all = load(c);
        Iterator<String> it = all.keys();
        while (it.hasNext()) out.add(get(c, it.next()));
        Collections.sort(out, (x, y) -> y.key.compareTo(x.key));
        return out;
    }

    /** Jumlah untuk bulan (yyyyMM). Hasil: {terbuat, terjual, uang}. */
    static long[] month(Context c, String ym) {
        long[] t = new long[3];
        for (Day d : list(c)) if (d.key.startsWith(ym)) { t[0] += d.made; t[1] += d.sold; t[2] += d.money; }
        return t;
    }

    static String pretty(String key) {
        try {
            Date d = new SimpleDateFormat("yyyyMMdd", Locale.US).parse(key);
            return new SimpleDateFormat("d MMM yyyy", new Locale("id", "ID")).format(d);
        } catch (Exception e) { return key; }
    }

    static String rp(long v) {
        String s = String.valueOf(Math.abs(v));
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            if (i > 0 && (s.length() - i) % 3 == 0) b.append('.');
            b.append(s.charAt(i));
        }
        return "Rp " + (v < 0 ? "-" : "") + b;
    }
}
