package com.aurastore.cabangpro;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;

/** Stok server hari ini: jumlah cangkang (akun) per nomor server, dijumlah dari setiap putaran yang selesai. Reset otomatis tiap ganti hari. */
final class Stock {
    private Stock() {}

    private static SharedPreferences sp(Context c) { return c.getSharedPreferences("stock", Context.MODE_PRIVATE); }

    private static String today() { return new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date()); }

    private static JSONObject load(Context c) {
        try {
            JSONObject o = new JSONObject(sp(c).getString("data", "{}"));
            if (!today().equals(o.optString("day"))) return fresh();
            if (o.optJSONObject("m") == null) o.put("m", new JSONObject());
            return o;
        } catch (Exception e) {
            return fresh();
        }
    }

    private static JSONObject fresh() {
        JSONObject o = new JSONObject();
        try { o.put("day", today()); o.put("m", new JSONObject()); } catch (Exception ignored) {}
        return o;
    }

    /** Dipanggil saat satu putaran selesai: tambahkan semua cangkang yang tidak dibuang dan ID servernya terbaca. */
    static void addRun(Context c) {
        try {
            JSONObject o = load(c);
            JSONObject m = o.getJSONObject("m");
            int added = 0;
            synchronized (AuraState.LOCK) {
                for (AuraState.AppEntry e : AuraState.apps) {
                    if (e.dropped || e.server.isEmpty()) continue;
                    m.put(e.server, m.optInt(e.server, 0) + 1);
                    added++;
                }
            }
            Ledger.addMade(c, added);
            sp(c).edit().putString("data", o.toString()).apply();
        } catch (Exception ignored) {}
    }

    static void reset(Context c) { sp(c).edit().putString("data", fresh().toString()).apply(); }

    /** Pasangan {nomor server, jumlah} berurutan naik. */
    static ArrayList<int[]> list(Context c) {
        ArrayList<int[]> out = new ArrayList<>();
        try {
            JSONObject m = load(c).getJSONObject("m");
            Iterator<String> it = m.keys();
            while (it.hasNext()) {
                String k = it.next();
                try { out.add(new int[]{Integer.parseInt(k), m.optInt(k, 0)}); } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
        Collections.sort(out, (x, y) -> Integer.compare(x[0], y[0]));
        return out;
    }

    static int total(Context c) {
        int t = 0;
        for (int[] p : list(c)) t += p[1];
        return t;
    }
}
