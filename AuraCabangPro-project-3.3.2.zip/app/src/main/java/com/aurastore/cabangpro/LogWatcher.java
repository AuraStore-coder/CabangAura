package com.aurastore.cabangpro;

import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Membaca log sistem (logcat) secara real time. Hanya MEMBACA, tidak mengubah aplikasi lain.
 * Butuh izin READ_LOGS yang diberikan sekali lewat: pm grant <paket> android.permission.READ_LOGS
 *
 * Yang dideteksi:
 *  - ID server dari baris log aplikasi target (pola bisa diatur)
 *  - proses aplikasi target dimulai ulang (= relog) dan dimatikan sistem
 */
public final class LogWatcher extends Thread {
    /** Baris dari MLBB: "[MiniPatch] ... ZoneID = 57103" (ditemukan dari rekaman log HP Vivo). */
    public static final String DEFAULT_PATTERN = "ZoneID\\s*=\\s*(\\d{4,6})";
    public static final String OLD_DEFAULT_PATTERN = "(?i)(?:zone|server|svr)[ _]?(?:id)?\\D{0,12}(5\\d{4})";

    private static final Pattern THREADTIME_UID = Pattern.compile(
            "^\\d\\d-\\d\\d \\d\\d:\\d\\d:\\d\\d\\.\\d+\\s+(\\S+)\\s+(\\d+)\\s+\\d+\\s+[VDIWEFAS]\\s+(.*)$");
    private static final Pattern THREADTIME = Pattern.compile(
            "^\\d\\d-\\d\\d \\d\\d:\\d\\d:\\d\\d\\.\\d+\\s+(\\d+)\\s+\\d+\\s+[VDIWEFAS]\\s+(.*)$");
    private static final Pattern AM_PROC_START = Pattern.compile(
            "am_proc_start\\s*:\\s*\\[\\d+,(\\d+),(\\d+),([^,\\]]+),");
    private static final Pattern START_PROC = Pattern.compile("Start proc (\\d+):([^/\\s]+)/");
    private static final Pattern AM_KILL = Pattern.compile(
            "am_kill\\s*:\\s*\\[\\d+,(\\d+),([^,\\]]+),(-?\\d+),([^\\]]*)\\]");
    private static final Pattern KILLING = Pattern.compile("Killing (\\d+):([^/\\s]+)/\\S+ \\(adj (-?\\d+)\\): (.*)");
    private static final Pattern LMKD = Pattern.compile("Kill '([^']+)' \\((\\d+)\\)");
    private static final Pattern DIED = Pattern.compile("Process ([^\\s]+) \\(pid (\\d+)\\) has died");
    private static final Pattern KILLINFO = Pattern.compile("killinfo\\s*:\\s*\\[(\\d+),(\\d+),(-?\\d+)");
    private static final Pattern AM_PROC_DIED = Pattern.compile("am_proc_died\\s*:\\s*\\[\\d+,(\\d+),([^,\\]]+),(-?\\d+)");
    private static final String GAME_PROC = ":UnityKillsMe";
    private static final Pattern UID_NAME = Pattern.compile("^u(\\d+)_([ai])(\\d+)$");
    private static final Pattern FIVE_DIGIT = Pattern.compile("\\b\\d{5}\\b");

    private final Context ctx;
    private final PackageManager pm;
    private final Pattern serverPattern;
    private final boolean record;
    private java.io.Writer out;
    private int recCount;
    private long lastFlush;
    private String recName = "";
    private static final int REC_MAX = 250000;
    private final HashMap<Integer, String> uidPkg = new HashMap<>();
    private final HashMap<Integer, String> pidPkg = new HashMap<>();
    private final HashSet<Integer> startedPids = new HashSet<>();
    private final HashSet<Integer> killedPids = new HashSet<>();
    private final HashMap<Integer, String> pidName = new HashMap<>();
    private volatile boolean stopped;
    /** true jika sudah menerima log dari aplikasi/sistem lain = akses log disetujui. */
    public volatile boolean seenForeign;
    private final int myUid = android.os.Process.myUid();
    private final int myPid = android.os.Process.myPid();
    private Process proc;
    private volatile ShizukuBridge.RemoteProcess shizukuProc;
    private final boolean viaShizuku;
    private final boolean filtered;
    private final HashMap<String, Long> lastRestart = new HashMap<>();

    public LogWatcher(Context ctx, String pattern, boolean record, boolean viaShizuku) {
        super("aura-logwatcher");
        this.ctx = ctx.getApplicationContext();
        this.pm = this.ctx.getPackageManager();
        Pattern p;
        try {
            p = Pattern.compile(pattern == null || pattern.trim().isEmpty() ? DEFAULT_PATTERN : pattern.trim());
        } catch (Exception e) {
            p = Pattern.compile(DEFAULT_PATTERN);
            AuraState.event("Pola ID server tidak valid, memakai pola bawaan");
        }
        this.serverPattern = p;
        this.record = record;
        this.viaShizuku = viaShizuku;
        this.filtered = p.pattern().equals(DEFAULT_PATTERN);
        setDaemon(true);
    }

    public static boolean hasPermission(Context c) {
        return c.checkSelfPermission("android.permission.READ_LOGS") == PackageManager.PERMISSION_GRANTED;
    }

    public void shutdown() {
        stopped = true;
        try { if (proc != null) proc.destroy(); } catch (Exception ignored) {}
        try { ShizukuBridge.RemoteProcess sp = shizukuProc; if (sp != null) sp.destroy(); } catch (Exception ignored) {}
        interrupt();
    }

    @Override public void run() {
        if (record) openRecording();
        // Hanya baris penting yang diambil (ZoneID dari Unity + kejadian proses), supaya HP tidak terbebani.
        String[] filter = filtered ? new String[]{"Unity:I", "am_proc_start:I", "am_proc_died:I", "am_kill:I", "killinfo:I", "*:S"}
                : new String[0];
        String[][] commands = {
                concat(new String[]{"logcat", "-v", "threadtime", "-v", "uid", "-b", "main", "-b", "system", "-b", "events", "-T", "1"}, filter),
                concat(new String[]{"logcat", "-v", "threadtime", "-b", "main", "-b", "system", "-b", "events", "-T", "1"}, filter),
        };
        String[] good = null;
        for (String[] cmd : commands) {
            if (stopped) break;
            long t0 = System.currentTimeMillis();
            int lines = readFrom(cmd);
            if (stopped) break;
            if (lines > 5 || System.currentTimeMillis() - t0 > 5000) { good = cmd; break; } // berjalan normal lalu berhenti
        }
        // Pembaca log terputus di tengah jalan (mis. proses logcat dihentikan sistem): sambung ulang terus,
        // mulai dari waktu baris terakhir supaya ZoneID yang lewat tidak hilang.
        int retries = 0;
        while (good != null && !stopped && retries < 200) {
            retries++;
            synchronized (AuraState.LOCK) { AuraState.logReaderActive = false; AuraState.version++; }
            AuraState.event("Pembaca ZoneID terputus → menyambung ulang…");
            try { Thread.sleep(1000); } catch (InterruptedException e) { break; }
            if (stopped) break;
            String[] cmd = good.clone();
            String since = lastStamp;
            if (since != null) {
                for (int i = 0; i < cmd.length - 1; i++) if (cmd[i].equals("-T")) { cmd[i + 1] = since; break; }
            }
            readFrom(cmd);
        }
        synchronized (AuraState.LOCK) { AuraState.logReaderActive = false; AuraState.version++; }
        if (record) closeRecording();
    }

    private static String[] concat(String[] a, String[] b) {
        String[] r = new String[a.length + b.length];
        System.arraycopy(a, 0, r, 0, a.length);
        System.arraycopy(b, 0, r, a.length, b.length);
        return r;
    }

    private int readFrom(String[] cmd) {
        int count = 0;
        try {
            java.io.InputStream in;
            if (viaShizuku) {
                shizukuProc = ShizukuBridge.newProcess(cmd);
                in = shizukuProc.getInputStream();
                seenForeign = true; // shell selalu boleh membaca semua log
            } else {
                proc = new ProcessBuilder(cmd).redirectErrorStream(true).start();
                in = proc.getInputStream();
            }
            synchronized (AuraState.LOCK) { AuraState.logReaderActive = true; AuraState.version++; }
            BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            String line;
            while (!stopped && (line = r.readLine()) != null) {
                count++;
                try { handle(line); } catch (Exception ignored) {}
            }
        } catch (Exception e) {
            synchronized (AuraState.LOCK) { AuraState.logReaderError = String.valueOf(e.getMessage()); }
        } finally {
            try { if (proc != null) proc.destroy(); } catch (Exception ignored) {}
            try { ShizukuBridge.RemoteProcess sp = shizukuProc; if (sp != null) sp.destroy(); } catch (Exception ignored) {}
        }
        return count;
    }

    private volatile String lastStamp;
    private static final java.util.regex.Pattern STAMP = java.util.regex.Pattern.compile("^(\\d\\d-\\d\\d \\d\\d:\\d\\d:\\d\\d\\.\\d{3})");

    private void handle(String line) {
        java.util.regex.Matcher stm = STAMP.matcher(line);
        if (stm.find()) lastStamp = stm.group(1);
        String uidTok = null; int pid = -1; String msg = line;
        Matcher m = THREADTIME_UID.matcher(line);
        if (m.matches()) {
            uidTok = m.group(1); pid = parseInt(m.group(2)); msg = m.group(3);
        } else {
            Matcher m2 = THREADTIME.matcher(line);
            if (m2.matches()) { pid = parseInt(m2.group(1)); msg = m2.group(2); }
        }

        int uid = parseUid(uidTok);
        if (!seenForeign && ((uid >= 0 && uidTok != null && uid != myUid) || (uidTok == null && pid > 0 && pid != myPid))) {
            seenForeign = true;
        }
        if (handleSystem(msg, uid)) return;

        String pkg = null;
        if (uid >= 10000) pkg = pkgForUid(uid);
        if (pkg == null && pid > 0) pkg = pidPkg.get(pid);
        if (pkg == null && uid < 0) {
            synchronized (AuraState.LOCK) { pkg = AuraState.currentPkg; }
        }
        AuraState.AppEntry e = null;
        if (pkg != null) { synchronized (AuraState.LOCK) { e = AuraState.byPkg.get(pkg); } }
        if (e == null) {
            // baris dari aplikasi/sistem lain yang menyebut salah satu aplikasi target
            if (record && mentionsTarget(msg)) rec("[lain] " + line);
            return;
        }

        Matcher sm = serverPattern.matcher(msg);
        if (sm.find()) {
            String id = sm.groupCount() >= 1 && sm.group(1) != null ? sm.group(1) : sm.group();
            boolean changed; String note = "";
            synchronized (AuraState.LOCK) {
                changed = !id.equals(e.server);
                if (changed) {
                    e.server = id; AuraState.version++;
                    if (AuraState.duplicatesOf(e) > 0) note = " · KEMBAR";
                    if (AuraState.isOld(e)) note += " · server lama";
                }
            }
            if (changed) AuraState.event("ID server " + shortName(pkg) + " = " + id + note);
        }
        if (record) rec("[" + pkg + "] " + line);
    }

    /** Baris dari sistem tentang proses dimulai / dimatikan. Return true jika sudah ditangani. */
    private boolean handleSystem(String msg, int lineUid) {
        Matcher m;
        if ((m = KILLINFO.matcher(msg)).find()) {
            int pid = parseInt(m.group(1));
            String name = pidName.get(pid);
            if (name == null) { String pk = pkgForUid(parseInt(m.group(2))); name = pk == null ? null : pk + GAME_PROC; }
            if (name != null) onKill(pid, name, "RAM penuh (lmkd)");
            rec(msg); return true;
        }
        if ((m = AM_PROC_DIED.matcher(msg)).find()) { onKill(parseInt(m.group(1)), m.group(2), "proses mati"); rec(msg); return true; }
        if ((m = AM_PROC_START.matcher(msg)).find()) { onStart(parseInt(m.group(1)), m.group(3)); rec(msg); return true; }
        if ((m = START_PROC.matcher(msg)).find()) { onStart(parseInt(m.group(1)), m.group(2)); rec(msg); return true; }
        if ((m = AM_KILL.matcher(msg)).find()) { onKill(parseInt(m.group(1)), m.group(2), m.group(4)); rec(msg); return true; }
        if ((m = KILLING.matcher(msg)).find()) { onKill(parseInt(m.group(1)), m.group(2), m.group(4)); rec(msg); return true; }
        if ((m = LMKD.matcher(msg)).find()) { onKill(parseInt(m.group(2)), m.group(1), "memori penuh (lmkd)"); rec(msg); return true; }
        if ((m = DIED.matcher(msg)).find()) { onKill(parseInt(m.group(2)), m.group(1), "proses berhenti"); rec(msg); return true; }
        return false;
    }

    private void rec(String msg) {
        if (!record || out == null || recCount >= REC_MAX) return;
        try {
            out.write(msg.startsWith("[") ? msg : "[sistem] " + msg);
            out.write('\n');
            recCount++;
            long now = System.currentTimeMillis();
            if (now - lastFlush > 3000) { out.flush(); lastFlush = now; }
        } catch (Exception ignored) {}
    }

    private boolean mentionsTarget(String msg) {
        synchronized (AuraState.LOCK) {
            for (String p : AuraState.byPkg.keySet()) if (msg.contains(p)) return true;
        }
        return false;
    }

    /** File rekaman dibuat di awal dan ditulis terus, jadi tidak hilang walau launcher dihentikan sistem. */
    private void openRecording() {
        recName = "aura_cabang_log_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".txt";
        try {
            OutputStream os;
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, recName);
                v.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain");
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new IllegalStateException("tidak bisa membuat file di Download");
                os = ctx.getContentResolver().openOutputStream(uri);
                recName = "Download/" + recName;
            } else {
                File f = new File(ctx.getExternalFilesDir(null), recName);
                os = new FileOutputStream(f);
                recName = f.getAbsolutePath();
            }
            out = new java.io.BufferedWriter(new java.io.OutputStreamWriter(os, StandardCharsets.UTF_8), 64 * 1024);
            out.write("Aura Cabang Pro " + BuildInfo.VERSION + " - rekaman log\n");
            out.write("HP: " + Build.MANUFACTURER + " " + Build.MODEL + " · Android " + Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")\n\n");
            out.flush();
            AuraState.event("Merekam log ke " + recName);
        } catch (Exception e) {
            out = null;
            AuraState.event("Gagal membuat file rekaman: " + e.getMessage());
        }
    }

    private void closeRecording() {
        if (out == null) return;
        try {
            StringBuilder sb = new StringBuilder("\n===== RINGKASAN =====\n");
            synchronized (AuraState.LOCK) {
                for (AuraState.AppEntry e : AuraState.apps)
                    sb.append(e.pkg).append(" server=").append(e.server).append(" relog=").append(e.restarts)
                            .append(" dimatikan=").append(e.kills).append(' ').append(e.lastKillReason).append('\n');
                sb.append("\nCatatan proses:\n");
                for (int i = AuraState.events.size() - 1; i >= 0; i--) sb.append(AuraState.events.get(i)).append('\n');
            }
            out.write(sb.toString());
            out.flush();
            out.close();
            AuraState.event("Rekaman log disimpan: " + recName + " (" + recCount + " baris)");
        } catch (Exception e) {
            AuraState.event("Gagal menutup rekaman: " + e.getMessage());
        }
        out = null;
    }

    /** Proses yang dihitung: proses utama paket, atau proses game Unity (":UnityKillsMe"). */
    private static boolean isGameProc(String procName) {
        return !procName.contains(":") || procName.endsWith(GAME_PROC);
    }

    private void onStart(int pid, String procName) {
        String pkg = procName.contains(":") ? procName.substring(0, procName.indexOf(':')) : procName;
        pidPkg.put(pid, pkg);
        pidName.put(pid, procName);
        if (!isGameProc(procName) || !startedPids.add(pid)) return;
        String msg = null;
        synchronized (AuraState.LOCK) {
            AuraState.AppEntry e = AuraState.byPkg.get(pkg);
            if (e == null || e.dropped || e.closedDone) return;
            boolean normalFirstStart = AuraState.step == 1 && pkg.equals(AuraState.currentPkg);
            if (normalFirstStart || !e.launched1) {
                e.initialStartSeen = true;
                if (AuraState.monitor) { e.launched1 = true; AuraState.currentPkg = pkg; }
            } else {
                long now = System.currentTimeMillis();
                Long last = lastRestart.get(pkg);
                if (last == null || now - last > 5000) { // proses utama + game mulai bersamaan = satu relog
                    lastRestart.put(pkg, now);
                    e.restarts++;
                    msg = "RELOG: " + shortName(pkg) + " dimulai ulang dari awal (Step " + AuraState.step + ")";
                }
            }
            AuraState.version++;
        }
        if (msg != null) AuraState.event(msg);
    }

    private void onKill(int pid, String procName, String reason) {
        if (!isGameProc(procName)) return;
        if (pid > 0 && !killedPids.add(pid)) return;
        String pkg = procName.contains(":") ? procName.substring(0, procName.indexOf(':')) : procName;
        String msg;
        synchronized (AuraState.LOCK) {
            if (!AuraState.running) return; // abaikan setelah proses selesai (mis. Anda menutup semua aplikasi)
            if (pkg.equals(AuraState.rerollingPkg)) return; // sengaja ditutup untuk acak ulang
            AuraState.AppEntry e = AuraState.byPkg.get(pkg);
            if (e == null || e.dropped || e.closedDone) return;
            e.kills++;
            e.lastKillReason = reason == null ? "" : reason.trim();
            AuraState.version++;
            msg = "DIMATIKAN SISTEM: " + shortName(pkg) + (e.lastKillReason.isEmpty() ? "" : " (" + e.lastKillReason + ")");
        }
        AuraState.event(msg);
    }

    private String pkgForUid(int uid) {
        if (uidPkg.containsKey(uid)) return uidPkg.get(uid);
        String found = null;
        try {
            String[] pk = pm.getPackagesForUid(uid);
            if (pk != null) {
                synchronized (AuraState.LOCK) {
                    for (String p : pk) if (AuraState.byPkg.containsKey(p)) { found = p; break; }
                }
                if (found == null && pk.length > 0) found = "";
            }
        } catch (Exception ignored) {}
        uidPkg.put(uid, found);
        return found == null || found.isEmpty() ? null : found;
    }

    private static int parseUid(String tok) {
        if (tok == null) return -1;
        tok = tok.trim();
        Matcher m = UID_NAME.matcher(tok);
        if (m.matches()) {
            int user = parseInt(m.group(1));
            int id = parseInt(m.group(3));
            return user * 100000 + ("a".equals(m.group(2)) ? 10000 + id : 99000 + id);
        }
        if (tok.matches("\\d+")) return parseInt(tok);
        return 0; // root/system/dll
    }

    private static int parseInt(String s) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return -1; }
    }

    static String shortName(String pkg) { return pkg; }

}
