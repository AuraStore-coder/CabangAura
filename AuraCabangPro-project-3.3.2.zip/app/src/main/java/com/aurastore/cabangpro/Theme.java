package com.aurastore.cabangpro;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.InputStream;

/** Tema Aura Store: latar ungu-biru, kartu kaca, tombol biru-tosca. */
final class Theme {
    static final int TEXT = 0xFFFFFFFF, MUTED = 0xFFC4D0EA, CYAN = 0xFF5CE1E6, BLUE = 0xFF4C7BF4,
            GREEN = 0xFF4ADE80, AMBER = 0xFFFFC24D, RED = 0xFFFF6B6B, NAVY = 0xFF04122E,
            GLASS = 0xB30B1A3F, GLASS_SOFT = 0x990B1A3F, STROKE = 0x555CE1E6, FIELD = 0x66000000;

    private static Typeface bold, medium;

    private Theme() {}

    static int dp(Context c, float v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }

    static Typeface font(Context c, boolean b) {
        try {
            if (b) { if (bold == null) bold = Typeface.createFromAsset(c.getAssets(), "fonts/Poppins-Bold.ttf"); return bold; }
            if (medium == null) medium = Typeface.createFromAsset(c.getAssets(), "fonts/Poppins-Medium.ttf");
            return medium;
        } catch (Exception e) {
            return b ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT;
        }
    }

    static GradientDrawable round(int color, float radiusPx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusPx);
        return g;
    }

    static GradientDrawable glass(Context c, int radiusDp) {
        GradientDrawable g = round(GLASS, dp(c, radiusDp));
        g.setStroke(Math.max(1, dp(c, 1)), STROKE);
        return g;
    }

    static GradientDrawable outlined(Context c, int fill, int stroke, int radiusDp) {
        GradientDrawable g = round(fill, dp(c, radiusDp));
        g.setStroke(Math.max(1, dp(c, 1.5f)), stroke);
        return g;
    }

    static GradientDrawable gradient(Context c, int radiusDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{CYAN, BLUE});
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static TextView text(Context c, String s, float sp, int color, boolean b) {
        OutlineText t = new OutlineText(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTypeface(font(c, b));
        t.setIncludeFontPadding(false);
        return t;
    }

    /** Teks di dalam kartu gelap: tanpa garis tepi supaya tetap halus. */
    static TextView plain(Context c, String s, float sp, int color, boolean b) {
        OutlineText t = (OutlineText) text(c, s, sp, color, b);
        t.outline = false;
        return t;
    }

    static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(glass(c, 18));
        l.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 14));
        return l;
    }

    static Button primary(Context c, String s, View.OnClickListener l) {
        Button b = new Button(c);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTypeface(font(c, true));
        b.setTextColor(NAVY);
        b.setBackground(gradient(c, 16));
        b.setMinHeight(dp(c, 48)); b.setMinimumHeight(dp(c, 48));
        b.setStateListAnimator(null);
        b.setOnClickListener(l);
        return b;
    }

    static Button ghost(Context c, String s, View.OnClickListener l) {
        Button b = new Button(c);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setTypeface(font(c, true));
        b.setTextColor(TEXT);
        b.setBackground(outlined(c, 0x66101E45, STROKE, 14));
        b.setMinHeight(dp(c, 44)); b.setMinimumHeight(dp(c, 44));
        b.setStateListAnimator(null);
        b.setOnClickListener(l);
        return b;
    }

    static EditText input(Context c, String value, String hint, boolean number) {
        EditText e = new EditText(c);
        e.setText(value);
        e.setHint(hint);
        e.setTextColor(TEXT);
        e.setHintTextColor(0xFF8FA0C4);
        e.setTextSize(15);
        e.setTypeface(font(c, false));
        e.setSingleLine(true);
        e.setBackground(outlined(c, FIELD, STROKE, 12));
        e.setPadding(dp(c, 12), dp(c, 11), dp(c, 12), dp(c, 11));
        if (number) e.setInputType(InputType.TYPE_CLASS_NUMBER);
        return e;
    }

    static LinearLayout.LayoutParams lp(Context c, int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(c, topDp);
        return p;
    }

    /** Latar penuh: gambar + penggelap + salju. */
    static FrameLayout background(Context c, boolean snow) {
        FrameLayout f = new FrameLayout(c);
        f.setBackgroundColor(0xFF070B1E);
        try {
            InputStream in = c.getAssets().open("bg_new.jpg");
            Bitmap bm = BitmapFactory.decodeStream(in);
            in.close();
            ImageView iv = new ImageView(c);
            iv.setImageBitmap(bm);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        } catch (Exception ignored) {}
        View dim = new View(c);
        dim.setBackgroundColor(0x66050A1E);
        f.addView(dim, new FrameLayout.LayoutParams(-1, -1));
        SnowView sv = new SnowView(c);
        sv.setVisibility(snow ? View.VISIBLE : View.GONE);
        sv.setTag("snow");
        f.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        return f;
    }

    /** Logo Aura Store. Kalau file logo belum dipasang, dipakai tulisan AURA STORE. */
    static View logo(Context c, int sizeDp) {
        int id = c.getResources().getIdentifier("logo_aura", "drawable", c.getPackageName());
        if (id != 0) {
            ImageView iv = new ImageView(c);
            iv.setImageResource(id);
            iv.setAdjustViewBounds(true);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            return iv;
        }
        TextView t = text(c, "AURA\nSTORE", sizeDp / 4f, CYAN, true);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    /** Kepala halaman: logo + judul + kata sambutan. Dipakai di semua menu. */
    static View pageHead(Context c, String title, String sub) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(logo(c, 46), new LinearLayout.LayoutParams(dp(c, 46), dp(c, 46)));
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(c, 10), 0, 0, 0);
        col.addView(text(c, title, 20, TEXT, true));
        col.addView(text(c, sub, 11, CYAN, true));
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        return row;
    }

    /** Kotak dialog dengan isi buatan sendiri (tema gelap Aura). */
    static AlertDialog dialog(Activity a, View content) {
        AlertDialog d = new AlertDialog.Builder(a).setView(content).create();
        if (d.getWindow() != null) d.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        d.show();
        return d;
    }

    /** Wadah isi dialog: kartu navy gelap dengan judul. */
    static LinearLayout dialogBox(Context c, String title) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(outlined(c, 0xFF0B1A3F, STROKE, 20));
        l.setPadding(dp(c, 18), dp(c, 16), dp(c, 18), dp(c, 16));
        TextView t = plain(c, title, 17, TEXT, true);
        l.addView(t);
        return l;
    }

    static int alpha(int color, int a) { return Color.argb(a, Color.red(color), Color.green(color), Color.blue(color)); }
}
