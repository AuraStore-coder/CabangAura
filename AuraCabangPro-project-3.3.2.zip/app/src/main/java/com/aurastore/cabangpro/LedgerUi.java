package com.aurastore.cabangpro;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

/** Tampilan catatan penjualan untuk owner (tab Server). */
final class LedgerUi {
    private final Activity a;
    private LinearLayout hist;
    private TextView todayMade, todayMoney, mMade, mSold, mMoney, mSisa;

    LedgerUi(Activity a) { this.a = a; }

    private int dp(int v) { return Theme.dp(a, v); }
    private TextView t(String s, int sp, int color, boolean b) { return Theme.plain(a, s, sp, color, b); }

    private LinearLayout card(LinearLayout parent, String title) {
        LinearLayout c = Theme.card(a);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(12);
        parent.addView(c, lp);
        TextView h = t(title, 14, Theme.TEXT, true);
        h.setPadding(0, 0, 0, dp(6));
        c.addView(h);
        return c;
    }

    private LinearLayout kv(LinearLayout parent, String k, TextView v) {
        LinearLayout r = new LinearLayout(a);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setPadding(0, dp(4), 0, dp(4));
        r.addView(t(k, 13, Theme.MUTED, false), new LinearLayout.LayoutParams(0, -2, 1f));
        r.addView(v);
        parent.addView(r);
        return r;
    }

    void attach(LinearLayout parent) {
        // ---- catatan hari ini ----
        LinearLayout c = card(parent, "CATATAN PENJUALAN");
        todayMade = t("0 server", 13, Theme.GREEN, true);
        todayMoney = t("Rp 0", 13, Theme.AMBER, true);
        kv(c, "Terjual hari ini", todayMade);
        kv(c, "Hasil uang hari ini", todayMoney);
        c.addView(Theme.primary(a, "Catat penjualan", v -> saleDialog(Ledger.todayKey())), Theme.lp(a, 8));
        c.addView(Theme.ghost(a, "Tambah catatan tanggal lain", v -> pickDate(Ledger.todayKey(), k -> saleDialog(k))), Theme.lp(a, 6));

        // ---- ringkasan bulan ----
        LinearLayout m = card(parent, "BULAN INI");
        mMade = t("0 server", 13, Theme.TEXT, true);
        mSold = t("0 server", 13, Theme.GREEN, true);
        mMoney = t("Rp 0", 13, Theme.AMBER, true);
        mSisa = t("0 server", 13, Theme.TEXT, true);
        kv(m, "Terbuat", mMade);
        kv(m, "Terjual", mSold);
        kv(m, "Pendapatan", mMoney);
        kv(m, "Sisa belum terjual", mSisa);

        // ---- riwayat ----
        LinearLayout h = card(parent, "RIWAYAT HARIAN");
        hist = new LinearLayout(a);
        hist.setOrientation(LinearLayout.VERTICAL);
        h.addView(hist);
        h.addView(t("Ketuk satu hari untuk mengubah, menggabungkan, atau menghapus.", 11, Theme.MUTED, false), Theme.lp(a, 8));
        refresh();
    }

    void refresh() {
        if (hist == null) return;
        Ledger.Day td = Ledger.get(a, Ledger.todayKey());
        todayMade.setText(td.sold + " server");
        todayMoney.setText(Ledger.rp(td.money));
        long[] mo = Ledger.month(a, Ledger.todayKey().substring(0, 6));
        mMade.setText(mo[0] + " server");
        mSold.setText(mo[1] + " server");
        mMoney.setText(Ledger.rp(mo[2]));
        mSisa.setText(Math.max(0, mo[0] - mo[1]) + " server");
        hist.removeAllViews();
        ArrayList<Ledger.Day> l = Ledger.list(a);
        if (l.isEmpty()) { hist.addView(t("Belum ada catatan.", 12, Theme.MUTED, false)); return; }
        long tm = 0, ts = 0, tr = 0;
        for (final Ledger.Day d : l) {
            tm += d.made; ts += d.sold; tr += d.money;
            LinearLayout r = new LinearLayout(a);
            r.setOrientation(LinearLayout.VERTICAL);
            r.setPadding(dp(10), dp(8), dp(10), dp(8));
            r.setBackground(Theme.outlined(a, 0x33101E45, Theme.STROKE, 12));
            LinearLayout top = new LinearLayout(a);
            top.addView(t(Ledger.pretty(d.key), 13, Theme.TEXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
            top.addView(t(Ledger.rp(d.money), 13, Theme.AMBER, true));
            r.addView(top);
            r.addView(t("Terbuat " + d.made + " · Terjual " + d.sold, 11, Theme.MUTED, false));
            r.setOnClickListener(v -> dayDialog(d.key));
            hist.addView(r, Theme.lp(a, 6));
        }
        TextView tot = t("Total semua: terbuat " + tm + " · terjual " + ts + " · " + Ledger.rp(tr), 12, Theme.GREEN, true);
        hist.addView(tot, Theme.lp(a, 10));
    }

    private interface DateCb { void got(String key); }

    private void pickDate(String start, DateCb cb) {
        Calendar cal = Calendar.getInstance();
        try {
            cal.set(Integer.parseInt(start.substring(0, 4)), Integer.parseInt(start.substring(4, 6)) - 1, Integer.parseInt(start.substring(6, 8)));
        } catch (Exception ignored) {}
        new DatePickerDialog(a, (view, y, mo, d) -> cb.got(String.format(Locale.US, "%04d%02d%02d", y, mo + 1, d)),
                cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
    }

    private static long num(EditText e) {
        try { return Long.parseLong(e.getText().toString().replaceAll("[^0-9]", "")); } catch (Exception x) { return 0; }
    }

    /** Tambah penjualan: angka yang diisi DITAMBAHKAN ke catatan hari itu. */
    private void saleDialog(final String key) {
        LinearLayout b = Theme.dialogBox(a, "Catat penjualan · " + Ledger.pretty(key));
        Ledger.Day cur = Ledger.get(a, key);
        b.addView(t("Sudah tercatat: terjual " + cur.sold + " · " + Ledger.rp(cur.money), 12, Theme.MUTED, false));
        b.addView(t("Server terjual (ditambahkan)", 12, Theme.MUTED, false), Theme.lp(a, 8));
        final EditText sold = Theme.input(a, "", "mis. 17", true);
        b.addView(sold);
        b.addView(t("Hasil uang (Rp, ditambahkan)", 12, Theme.MUTED, false), Theme.lp(a, 8));
        final EditText money = Theme.input(a, "", "mis. 850000", true);
        b.addView(money);
        final AlertDialog[] dlg = new AlertDialog[1];
        b.addView(Theme.primary(a, "Simpan", v -> {
            long s = num(sold), m = num(money);
            if (s == 0 && m == 0) { dlg[0].dismiss(); return; }
            Ledger.addSale(a, key, s, m);
            dlg[0].dismiss();
            refresh();
            Toast.makeText(a, "Tersimpan", Toast.LENGTH_SHORT).show();
        }), Theme.lp(a, 12));
        b.addView(Theme.ghost(a, "Batal", v -> dlg[0].dismiss()), Theme.lp(a, 6));
        dlg[0] = Theme.dialog(a, b);
    }

    /** Ketuk satu hari: ubah angka, gabungkan ke hari lain, atau hapus. */
    private void dayDialog(final String key) {
        final Ledger.Day d = Ledger.get(a, key);
        LinearLayout b = Theme.dialogBox(a, Ledger.pretty(key));
        b.addView(t("Terbuat (server)", 12, Theme.MUTED, false));
        final EditText made = Theme.input(a, String.valueOf(d.made), "0", true);
        b.addView(made);
        b.addView(t("Terjual (server)", 12, Theme.MUTED, false), Theme.lp(a, 8));
        final EditText sold = Theme.input(a, String.valueOf(d.sold), "0", true);
        b.addView(sold);
        b.addView(t("Hasil uang (Rp)", 12, Theme.MUTED, false), Theme.lp(a, 8));
        final EditText money = Theme.input(a, String.valueOf(d.money), "0", true);
        b.addView(money);
        final AlertDialog[] dlg = new AlertDialog[1];
        b.addView(Theme.primary(a, "Simpan perubahan", v -> {
            d.made = num(made); d.sold = num(sold); d.money = num(money);
            Ledger.put(a, d);
            dlg[0].dismiss();
            refresh();
        }), Theme.lp(a, 12));
        b.addView(Theme.ghost(a, "Gabungkan ke tanggal lain", v -> {
            dlg[0].dismiss();
            pickDate(key, to -> {
                if (to.equals(key)) { Toast.makeText(a, "Pilih tanggal yang berbeda", Toast.LENGTH_SHORT).show(); return; }
                Ledger.merge(a, key, to);
                refresh();
                Toast.makeText(a, "Digabung ke " + Ledger.pretty(to), Toast.LENGTH_LONG).show();
            });
        }), Theme.lp(a, 6));
        b.addView(Theme.ghost(a, "Hapus hari ini", v -> {
            new AlertDialog.Builder(a).setMessage("Hapus catatan " + Ledger.pretty(key) + "?")
                    .setPositiveButton("Hapus", (x, y) -> { Ledger.delete(a, key); dlg[0].dismiss(); refresh(); })
                    .setNegativeButton("Batal", null).show();
        }), Theme.lp(a, 6));
        b.addView(Theme.ghost(a, "Tutup", v -> dlg[0].dismiss()), Theme.lp(a, 6));
        dlg[0] = Theme.dialog(a, b);
    }
}
