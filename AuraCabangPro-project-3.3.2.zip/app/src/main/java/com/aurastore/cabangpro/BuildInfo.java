package com.aurastore.cabangpro;

public final class BuildInfo {
    public static final String VERSION = "3.3.2";
    private BuildInfo() {}
}
