package com.aurastore.cabangpro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Efek salju halus di atas latar. Dimatikan lewat Setelan (setVisibility(GONE)). */
class SnowView extends View {
    private static final int N = 40;
    private final float[] x = new float[N], y = new float[N], r = new float[N], v = new float[N];
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private long last;
    private boolean ready;

    SnowView(Context c) {
        super(c);
        paint.setColor(0xFFFFFFFF);
    }

    @Override protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        float d = getResources().getDisplayMetrics().density;
        if (!ready) {
            for (int i = 0; i < N; i++) reset(i, w, h, d, true);
            ready = true;
            last = System.nanoTime();
        }
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        for (int i = 0; i < N; i++) {
            y[i] += v[i] * dt;
            x[i] += (float) Math.sin(y[i] / (40f * d) + i) * 8f * d * dt;
            if (y[i] > h + 8 * d) reset(i, w, h, d, false);
            paint.setAlpha(150);
            canvas.drawCircle(x[i], y[i], r[i], paint);
        }
        postInvalidateOnAnimation();
    }

    private void reset(int i, int w, int h, float d, boolean anywhere) {
        x[i] = (float) (Math.random() * w);
        y[i] = anywhere ? (float) (Math.random() * h) : -8f * d;
        r[i] = (float) (1.0 + Math.random() * 2.2) * d;
        v[i] = (float) (18 + Math.random() * 40) * d;
    }
}
