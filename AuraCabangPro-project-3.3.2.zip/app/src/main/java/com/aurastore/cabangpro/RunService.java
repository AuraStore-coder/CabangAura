package com.aurastore.cabangpro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Layanan ringan yang membuka aplikasi satu per satu.
 * Step 1: 1 -> N. Step 2: N -> 1 (terbalik) atau 1 -> N (maju). Jeda per aplikasi bisa diatur.
 * Selama berjalan: wake lock + layar tetap menyala (lewat panel melayang) agar aplikasi tidak dibekukan.
 */
public class RunService extends Service {
    public static final String ACTION_START = "com.aurastore.cabangpro.START";
    public static final String ACTION_STOP = "com.aurastore.cabangpro.STOP";
    private static final String CHANNEL = "aura_run";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private ArrayList<String> pkgs = new ArrayList<>();
    private ArrayList<Integer> order = new ArrayList<>();
    private int idx;
    private long delay1 = 8000, delay2 = 8000;
    private boolean reverse2 = true, backToLauncher = true, showPanel = true;
    /** 0 = terbalik, 1 = maju, 2 = urut server terkecil -> terbesar */
    private int order2 = 0;
    private boolean reroll, rerollOld, rerollBroken;
    private boolean homeStyle = true, noOverlay, viaHome = true, dropDup = true;
    /** Mode ketuk LANJUT: tidak ada hitungan detik, pindah aplikasi hanya saat tombol LANJUT diketuk. */
    private boolean manualNext;
    /** Batas cangkang hidup (= server) per putaran; 0 = tanpa batas. */
    private int maxAlive = 24;
    /** Tutup cangkang yang sudah selesai Step 2 (≥ 20 dtk) supaya RAM cukup untuk yang belum. */
    private boolean closeDone = true;
    /** Buang server lama (< minServer); boleh simpan maks oldAllowed server lama. -1 = simpan semua. */
    private int oldAllowed = -1;
    /** Buang cangkang yang ZoneID-nya tidak terbaca (supaya urutan tetap rapi). */
    private boolean dropUnknown = true;
    private boolean autoCancel, screenTiming;
    private int dlgHits; private long lastCancelTap;
    private volatile int cancelCount;
    private long endWaitStart;
    private TextView nextBtn;
    private long lastNextTap;
    private int rerollMax = 2;
    private PowerManager.WakeLock wakeLock;
    private WindowManager wm;
    private View overlay;
    private TextView overlayText;
    private LogWatcher watcher;
    private ScreenWatcher screen;
    private int target1 = 20, target2 = 97;
    private Icon smallIcon;

    private final Runnable tick = this::step;
    /** Cek kotak biru setiap 0,4 dtk; jika terlihat ≥ 1,2 dtk di layar loading → ketuk Cancel. */
    private final Runnable cancelLoop = new Runnable() {
        @Override public void run() {
            if (!isRunning() || finishing) return;
            ScreenWatcher sw = screen;
            if (sw != null && !sw.isStopped()) {
                dlgHits = sw.dialog() ? dlgHits + 1 : 0;
                long now = android.os.SystemClock.uptimeMillis();
                if (dlgHits >= 3 && now - lastCancelTap > 4000) {
                    lastCancelTap = now; dlgHits = 0;
                    String cur; synchronized (AuraState.LOCK) { cur = AuraState.currentPkg; }
                    tapCancel(cur);
                    cancelCount++;
                    // beri waktu tambahan supaya cangkang ini sempat lanjut loading
                    if (!manualNext && !screenTiming) { handler.removeCallbacks(tick); handler.postDelayed(tick, 9000); }
                }
            }
            handler.postDelayed(this, 400);
        }
    };
    private final Runnable refresh = new Runnable() {
        @Override public void run() {
            updateOverlay();
            handler.postDelayed(this, 1000);
        }
    };

    public static boolean isRunning() { synchronized (AuraState.LOCK) { return AuraState.running; } }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Proses buka aplikasi", NotificationManager.IMPORTANCE_LOW));
        // tipe 0 dulu; tipe mediaProjection hanya setelah izin rekam layar diberikan
        try { startForeground(1, buildNotification(), 0); } catch (Throwable t) { startForeground(1, buildNotification()); }

        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            AuraState.event("Dihentikan oleh Anda");
            boolean mon; synchronized (AuraState.LOCK) { mon = AuraState.monitor; }
            if (mon) summary();
            finishRun(false);
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(action) || isRunning()) {
            if (!isRunning()) stopSelf();
            return START_NOT_STICKY;
        }
        if (!Lic.localValid(this)) {
            // lisensi habis / belum aktif: jangan jalankan
            AuraState.event("Lisensi tidak aktif. Aktifkan kode di launcher.");
            stopSelf();
            return START_NOT_STICKY;
        }

        ArrayList<String> list = intent.getStringArrayListExtra("pkgs");
        if (list == null || list.isEmpty()) { stopSelf(); return START_NOT_STICKY; }
        pkgs = list;
        finishing = false;
        delay1 = Math.max(2000, intent.getLongExtra("delay1", 8000));
        delay2 = Math.max(2000, intent.getLongExtra("delay2", 8000));
        order2 = intent.getIntExtra("order2", 0);
        reroll = intent.getBooleanExtra("reroll", false);
        rerollOld = intent.getBooleanExtra("rerollOld", false);
        rerollBroken = false;
        homeStyle = intent.getBooleanExtra("homeStyle", true);
        noOverlay = intent.getBooleanExtra("noOverlay", false);
        viaHome = intent.getBooleanExtra("viaHome", true);
        dropDup = intent.getBooleanExtra("dropDup", true);
        manualNext = intent.getBooleanExtra("manual", false);
        maxAlive = intent.getIntExtra("maxAlive", 24);
        closeDone = intent.getBooleanExtra("closeDone", true);
        oldAllowed = intent.getIntExtra("oldAllowed", -1);
        dropUnknown = intent.getBooleanExtra("dropUnknown", false);
        autoCancel = intent.getBooleanExtra("autoCancel", false);
        screenTiming = intent.getBooleanExtra("screenTiming", false);
        endWaitStart = 0;
        rerollMax = Math.max(1, Math.min(5, intent.getIntExtra("rerollMax", 2)));
        reverse2 = order2 == 0;
        synchronized (AuraState.LOCK) { AuraState.minServer = intent.getIntExtra("minServer", 57092); }
        backToLauncher = intent.getBooleanExtra("back", true);
        showPanel = intent.getBooleanExtra("panel", true);
        boolean record = intent.getBooleanExtra("record", false);
        boolean useLogs = intent.getBooleanExtra("logs", false);
        boolean monitorMode = intent.getBooleanExtra("monitor", false);
        synchronized (AuraState.LOCK) { AuraState.monitor = monitorMode; }
        String pattern = intent.getStringExtra("pattern");
        target1 = Math.max(1, Math.min(100, intent.getIntExtra("target1", 20)));
        target2 = Math.max(1, Math.min(100, intent.getIntExtra("target2", 97)));
        Intent projData = intent.getParcelableExtra("projData");
        if (projData != null) {
            try {
                startForeground(1, buildNotification(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            } catch (Throwable t) { AuraState.event("FGS layar: " + t.getMessage()); }
            screen = new ScreenWatcher();
            if (!screen.start(this, intent.getIntExtra("projCode", 0), projData)) {
                screen = null;
                AuraState.event("Lihat layar GAGAL dimulai → pakai jeda detik biasa");
            }
        } else screen = null;

        synchronized (AuraState.LOCK) {
            AuraState.running = true; AuraState.step = 1; AuraState.pos = 0; AuraState.version++;
        }
        AuraState.event("Mulai: " + pkgs.size() + " aplikasi · jeda Step 1 " + delay1 / 1000 + " dtk · Step 2 "
                + delay2 / 1000 + " dtk (" + orderName() + ")");

        acquireWakeLock();
        if (screen != null && autoCancel) { dlgHits = 0; lastCancelTap = 0; handler.postDelayed(cancelLoop, 1000);
            AuraState.event("Ketuk Cancel otomatis aktif (kotak biru Loading resources failed)"); }
        if (screen != null && screenTiming) AuraState.event("LIHAT LAYAR aktif: Step 1 pindah saat loading " + target1 + "%, Step 2 saat loading " + target2 + "% (atau selesai)");
        if (noOverlay) AuraState.event("Tanpa panel melayang (mirip manual)");
        else addOverlay();
        if (manualNext) { addNextButton(); AuraState.event("MODE KETUK LANJUT: ketuk tombol LANJUT (pojok kiri atas) untuk pindah ke aplikasi berikutnya"); }
        order = buildOrder(1);
        idx = 0;
        handler.post(refresh);
        if (monitorMode) {
            if (!ShizukuBridge.isGranted()) {
                AuraState.event("Mode pantau butuh Shizuku aktif & diizinkan");
                finishRun(false);
                return START_NOT_STICKY;
            }
            watcher = new LogWatcher(this, pattern, record, true);
            watcher.start();
            AuraState.event("MODE PANTAU: buka cangkang dengan tangan seperti biasa. Launcher hanya membaca ZoneID & relog. Tekan Hentikan di notifikasi jika selesai.");
            updateNotification();
            return START_NOT_STICKY;
        }
        if (!useLogs) {
            AuraState.event("Pembaca log mati (mode ringan)");
            beginStep1();
        } else if (ShizukuBridge.isGranted()) {
            watcher = new LogWatcher(this, pattern, record, true);
            watcher.start();
            AuraState.event("Pembaca ID server aktif lewat Shizuku");
            beginStep1();
        } else if (LogWatcher.hasPermission(this)) {
            watcher = new LogWatcher(this, pattern, record, false);
            watcher.start();
            synchronized (AuraState.LOCK) { AuraState.waitingLogConsent = true; AuraState.version++; }
            AuraState.event("Menunggu persetujuan akses log… ketuk IZINKAN di jendela yang muncul");
            final long t0 = System.currentTimeMillis();
            handler.post(new Runnable() {
                @Override public void run() {
                    LogWatcher w = watcher;
                    boolean ok = w != null && w.seenForeign;
                    if (!ok && System.currentTimeMillis() - t0 < 25000) { handler.postDelayed(this, 300); return; }
                    synchronized (AuraState.LOCK) { AuraState.waitingLogConsent = false; AuraState.version++; }
                    AuraState.event(ok ? "Akses log disetujui: ID server & relog dipantau"
                            : "Akses log TIDAK disetujui: ID server & relog tidak terbaca (proses tetap jalan)");
                    beginStep1();
                }
            });
        } else {
            AuraState.event("Shizuku belum aktif/diizinkan: ID server & relog tidak terbaca");
            beginStep1();
        }
        return START_NOT_STICKY;
    }

    private void beginStep1() {
        AuraState.event("— Step 1 dimulai —");
        handler.post(tick);
    }

    private String orderName() {
        return order2 == 2 ? "urut server" : order2 == 1 ? "maju" : "terbalik";
    }

    private ArrayList<Integer> buildOrder(int step) {
        ArrayList<Integer> o = new ArrayList<>();
        int n = pkgs.size();
        if (step == 2 && order2 == 0) for (int i = n - 1; i >= 0; i--) o.add(i);
        else for (int i = 0; i < n; i++) o.add(i);
        if (step == 2) {
            ArrayList<Integer> keep = new ArrayList<>();
            synchronized (AuraState.LOCK) {
                for (Integer i : o) {
                    AuraState.AppEntry e = AuraState.byPkg.get(pkgs.get(i));
                    if (e == null || !e.dropped) keep.add(i);
                }
            }
            if (keep.size() != o.size()) AuraState.event("Step 2: " + (o.size() - keep.size()) + " cangkang kembar dilewati");
            o = keep;
        }
        if (step == 2 && order2 == 2) {
            // urutkan berdasarkan ID server (kecil -> besar); yang belum terbaca di akhir, urutan asli
            final java.util.HashMap<Integer, Long> key = new java.util.HashMap<>();
            synchronized (AuraState.LOCK) {
                for (int i = 0; i < n; i++) {
                    AuraState.AppEntry e = AuraState.byPkg.get(pkgs.get(i));
                    long k = Long.MAX_VALUE / 2 + i;
                    if (e != null && !e.server.isEmpty()) {
                        try { k = Long.parseLong(e.server) * 100 + i; } catch (Exception ignored) {}
                    }
                    key.put(i, k);
                }
            }
            java.util.Collections.sort(o, (a, b) -> Long.compare(key.get(a), key.get(b)));
            StringBuilder sb = new StringBuilder("Urutan Step 2: ");
            synchronized (AuraState.LOCK) {
                for (int j = 0; j < o.size() && j < 30; j++) {
                    AuraState.AppEntry e = AuraState.byPkg.get(pkgs.get(o.get(j)));
                    sb.append(j == 0 ? "" : ", ").append(e == null || e.server.isEmpty() ? "?" : e.server);
                }
            }
            AuraState.event(sb.toString());
        }
        return o;
    }

    private void step() {
        if (!Lic.localValid(this)) {
            AuraState.event("Lisensi habis, proses dihentikan");
            finishRun(false);
            return;
        }
        int curStep;
        synchronized (AuraState.LOCK) { curStep = AuraState.step; }
        if (curStep == 1 && idx > 0 && idx < order.size() && maxAlive > 0 && dropDup && watcher != null) {
            // buang yang kembar dulu (termasuk yang sedang tampil), lalu cek batas RAM.
            // finalPass=false: cangkang yang sedang tampil & ZoneID-nya belum muncul JANGAN dibuang dulu.
            dropDuplicates(true, false);
            int alive = 0;
            synchronized (AuraState.LOCK) {
                for (AuraState.AppEntry e : AuraState.apps) if (e.launched1 && !e.dropped) alive++;
            }
            if (alive >= maxAlive) {
                AuraState.event("Batas " + maxAlive + " server tercapai → Step 1 berhenti, " + (order.size() - idx)
                        + " cangkang sisanya tidak dipakai (agar RAM cukup & tidak relog)");
                idx = order.size();
            }
        }
        if (idx >= order.size()) {
            if (curStep == 1 && watcher != null && idx > 0) {
                // tunggu ZoneID cangkang terakhir sebentar (maks 6 dtk) sebelum Step 2
                boolean waiting;
                synchronized (AuraState.LOCK) {
                    AuraState.AppEntry last = AuraState.byPkg.get(AuraState.currentPkg);
                    waiting = last != null && !last.dropped && last.server.isEmpty();
                }
                long now = System.currentTimeMillis();
                if (waiting) {
                    if (endWaitStart == 0) endWaitStart = now;
                    if (now - endWaitStart < 6000) { handler.postDelayed(tick, 500); return; }
                }
            }
            if (curStep == 1) {
                if (watcher != null) {
                    int got = 0, dupN = 0, old = 0;
                    synchronized (AuraState.LOCK) {
                        for (AuraState.AppEntry e : AuraState.apps) {
                            if (e.server.isEmpty()) continue;
                            got++;
                            if (AuraState.duplicatesOf(e) > 0) dupN++;
                            if (AuraState.isOld(e)) old++;
                        }
                    }
                    AuraState.event("Hasil Step 1: ID terbaca " + got + "/" + pkgs.size() + " · kembar " + dupN + " · server lama " + old);
                }
                dropDuplicates(true);
                synchronized (AuraState.LOCK) { AuraState.step = 2; AuraState.pos = 0; AuraState.version++; }
                order = buildOrder(2);
                idx = 0;
                AuraState.event("— Step 2 dimulai (" + orderName() + ") —");
                curStep = 2;
            } else {
                // cangkang terakhir: layar tetap menyala 15 dtk lagi supaya loading-nya benar-benar selesai
                AuraState.event("Menunggu cangkang terakhir selesai loading (15 dtk)…");
                handler.postDelayed(() -> {
                    if (finishing) return;
                    summary();
                    handler.postDelayed(() -> finishRun(backToLauncher), 3000);
                }, 15000);
                return;
            }
        }
        if (curStep == 2) {
            // lewati cangkang yang sudah dibuang (kembar)
            while (idx < order.size() && isDropped(pkgs.get(order.get(idx)))) idx++;
            if (idx >= order.size()) { handler.post(tick); return; }
        }
        String pkg = pkgs.get(order.get(idx));
        idx++;
        synchronized (AuraState.LOCK) {
            AuraState.pos = idx;
            AuraState.currentPkg = pkg;
            AuraState.AppEntry e = AuraState.byPkg.get(pkg);
            if (e != null) { if (curStep == 1) { e.launched1 = true; e.step1At = System.currentTimeMillis(); } else { e.launched2 = true; e.step2At = System.currentTimeMillis(); } }
            AuraState.version++;
        }
        if (viaHome) {
            // seperti manual: tekan Home dulu, lalu buka cangkang dari layar utama
            goHome();
            final int cs = curStep; final String pk = pkg;
            handler.postDelayed(() -> { if (isRunning() && !finishing) afterLaunch(cs, pk, launch(pk)); }, 700);
            return;
        }
        afterLaunch(curStep, pkg, launch(pkg));
    }

    private int realW, realH;

    /** Ketuk tombol Cancel pada kotak biru lewat Shizuku (input tap), posisi relatif layar landscape. */
    private void tapCancel(final String pkg) {
        if (!ShizukuBridge.isGranted()) {
            AuraState.event("   ↳ " + pkg + ": kotak biru terlihat, tapi Shizuku belum aktif → tidak bisa ketuk Cancel");
            return;
        }
        if (realW == 0) {
            android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
            getSystemService(WindowManager.class).getDefaultDisplay().getRealMetrics(dm);
            realW = Math.max(dm.widthPixels, dm.heightPixels); realH = Math.min(dm.widthPixels, dm.heightPixels);
        }
        final int x = Math.round(realW * 0.40f), y = Math.round(realH * 0.67f);
        AuraState.event("   ↳ " + pkg + ": kotak biru → ketuk Cancel");
        new Thread(() -> ShizukuBridge.run("input", "tap", String.valueOf(x), String.valueOf(y)), "aura-tap").start();
    }

    /** Step 2: cangkang yang sudah selesai loading (dibuka ≥ 20 dtk lalu) ditutup supaya RAM lega. */
    private void closeFinished(String current) {
        if (!closeDone || !ShizukuBridge.isGranted()) return;
        final ArrayList<String> stop = new ArrayList<>();
        long now = System.currentTimeMillis();
        synchronized (AuraState.LOCK) {
            for (AuraState.AppEntry e : AuraState.apps) {
                if (!e.launched2 || e.closedDone || e.dropped || e.pkg.equals(current)) continue;
                if (now - e.step2At < 20000) continue;
                e.closedDone = true;
                stop.add(e.pkg);
            }
        }
        if (stop.isEmpty()) return;
        AuraState.event("   ↳ tutup yang sudah selesai: " + android.text.TextUtils.join(", ", stop));
        new Thread(() -> { for (String p : stop) ShizukuBridge.run("am", "force-stop", p); }, "aura-done").start();
    }

    private boolean isDropped(String pkg) {
        synchronized (AuraState.LOCK) {
            AuraState.AppEntry e = AuraState.byPkg.get(pkg);
            return e != null && e.dropped;
        }
    }

    /**
     * Seperti cara manual: jika ZoneID cangkang sama dengan cangkang sebelumnya, cangkang itu dibuang
     * (ditutup, tidak dilanjutkan di Step 2). Yang dipertahankan: yang lebih dulu dibuka.
     */
    private void dropDuplicates() { dropDuplicates(false, false); }

    private void dropDuplicates(boolean endOfStep1) { dropDuplicates(endOfStep1, endOfStep1); }

    /**
     * @param endOfStep1 true = cangkang yang sedang tampil boleh dibuang jika KEMBAR.
     * @param finalPass  true = Step 1 benar-benar selesai: yang ZoneID-nya tidak terbaca juga boleh dibuang.
     */
    private void dropDuplicates(boolean endOfStep1, boolean finalPass) {
        if (!dropDup || watcher == null || !ShizukuBridge.isGranted()) return;
        final ArrayList<String> stop = new ArrayList<>();
        ArrayList<String> msgs = new ArrayList<>();
        synchronized (AuraState.LOCK) {
            java.util.HashMap<String, String> holder = new java.util.HashMap<>();
            int oldKept = 0;
            for (Integer i : buildOrder1Snapshot()) {
                AuraState.AppEntry e = AuraState.byPkg.get(pkgs.get(i));
                if (e == null || !e.launched1 || e.dropped) continue;
                if (e.server.isEmpty()) {
                    // ZoneID tidak terbaca: buang jika sudah lama (atau Step 1 selesai), supaya urutan tetap rapi
                    boolean late = System.currentTimeMillis() - e.step1At > 16000;
                    if (dropUnknown && (late || finalPass)) {
                        e.dropped = true; e.droppedFor = "?";
                        stop.add(e.pkg);
                        msgs.add("BUANG " + e.pkg + " (ZoneID tidak terbaca)");
                    }
                    continue;
                }
                String h = holder.get(e.server);
                boolean old = AuraState.isOld(e);
                if (h == null && old && oldAllowed >= 0 && oldKept >= oldAllowed) h = "LAMA";
                if (h == null) { holder.put(e.server, e.pkg); if (old) oldKept++; continue; }
                if (!endOfStep1 && e.pkg.equals(AuraState.currentPkg) && AuraState.step == 1) continue; // jangan tutup yang sedang tampil
                e.dropped = true; e.droppedFor = h;
                stop.add(e.pkg);
                msgs.add(h.equals("LAMA") ? "BUANG " + e.pkg + " (" + e.server + " server lama)"
                        : "BUANG " + e.pkg + " (" + e.server + " sudah dipakai " + h + ")");
            }
            if (!stop.isEmpty()) AuraState.version++;
        }
        for (String m : msgs) AuraState.event(m);
        if (stop.isEmpty()) return;
        new Thread(() -> { for (String p : stop) ShizukuBridge.run("am", "force-stop", p); }, "aura-drop").start();
    }

    private ArrayList<Integer> buildOrder1Snapshot() {
        ArrayList<Integer> o = new ArrayList<>();
        for (int i = 0; i < pkgs.size(); i++) o.add(i);
        return o;
    }

    private void goHome() {
        try {
            startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception ignored) {}
    }

    private void afterLaunch(int curStep, String pkg, boolean ok) {
        if (curStep == 1) dropDuplicates();
        if (curStep == 2) closeFinished(pkg);
        AuraState.save(this);
        AuraState.event("Step " + curStep + " · " + idx + "/" + order.size() + " · " + (ok ? "Buka " : "GAGAL buka ") + pkg);
        updateNotification();
        if (ok && curStep == 1 && reroll && watcher != null && !manualNext) {
            final String p = pkg;
            zoneWaitStart = System.currentTimeMillis();
            handler.postDelayed(() -> checkReroll(p), 500);
        } else if (ok && manualNext) {
            updateNextButton();   // tunggu ketukan LANJUT, tidak ada hitungan detik
        } else if (ok && screen != null && screenTiming) {
            waitLoading(curStep, pkg);
        } else {
            handler.postDelayed(tick, ok ? (curStep == 1 ? delay1 : delay2) : 700);
        }
    }

    /** Tunggu bar loading di layar mencapai target (seperti mata), lalu pindah ke aplikasi berikutnya. */
    private void waitLoading(final int st, final String pkg) {
        final long t0 = android.os.SystemClock.uptimeMillis();
        final int target = st == 1 ? target1 : target2;
        final long fallback = st == 1 ? delay1 : delay2;
        final long maxWait = st == 1 ? Math.max(delay1 + 4000, 20000) : Math.max(delay2 + 4000, 35000);
        handler.postDelayed(new Runnable() {
            int hits, seenMax = -1, dlg, seenCancels = cancelCount; long lastSeen, lastTap = -10000, extra;
            @Override public void run() {
                if (!isRunning() || finishing) return;
                long el = android.os.SystemClock.uptimeMillis() - t0;
                ScreenWatcher sw = screen;
                int f = sw == null || sw.isStopped() ? -1 : sw.fill();
                // kotak biru "Loading resources failed": ketuk Cancel (seperti jari Anda)
                if (cancelCount != seenCancels) { extra += 12000L * (cancelCount - seenCancels); seenCancels = cancelCount; hits = 0; }
                dlg = !autoCancel && sw != null && !sw.isStopped() && sw.dialog() ? dlg + 1 : 0;
                if (dlg >= 3 && el - lastTap > 3500) {
                    lastTap = el; extra += 12000; dlg = 0;
                    tapCancel(pkg);
                    handler.postDelayed(this, 250);
                    return;
                }
                if (el >= 1500) {
                    if (f >= 0) { if (f > seenMax) seenMax = f; lastSeen = el; }
                    hits = f >= target ? hits + 1 : 0;
                    String why = null;
                    if (hits >= 2) why = "loading " + f + "%";
                    else if (st == 2 && seenMax >= 60 && f < 0 && el - lastSeen >= 1200) why = "loading selesai (bar hilang)";
                    else if (seenMax < 0 && el >= fallback + 4000 + extra) why = "bar tidak terlihat → jeda biasa";
                    else if (el >= maxWait + extra) why = "batas tunggu (bar " + Math.max(seenMax, 0) + "%)";
                    if (why != null) {
                        AuraState.event("   ↳ " + pkg + " pindah: " + why + " · " + String.format(java.util.Locale.US, "%.1f", el / 1000f) + " dtk");
                        handler.postDelayed(tick, 300);
                        return;
                    }
                }
                handler.postDelayed(this, 250);
            }
        }, 250);
    }

    /** Mulai menunggu ZoneID cangkang yang baru dibuka / dibuka ulang. */
    private long zoneWaitStart;

    /**
     * Dipanggil di Step 1 setelah jeda: jika ZoneID cangkang ini kembar dengan cangkang sebelumnya
     * (atau server lama, jika dipilih), cangkang ditutup lalu dibuka lagi supaya game mengacak server baru.
     * Hanya menutup & membuka aplikasi, tidak mengubah isi game.
     */
    private void checkReroll(String pkg) {
        if (!isRunning() || finishing) return;
        // Cek tiap 0,5 dtk selama jeda Step 1 (tidak pernah lebih lama dari jeda Step 1):
        //  - ZoneID muncul & KEMBAR -> langsung acak ulang (tidak perlu menunggu sisa jeda)
        //  - selain itu tunggu sampai jeda Step 1 habis, baru putuskan & pindah ke cangkang berikutnya
        boolean decideNow;
        synchronized (AuraState.LOCK) {
            AuraState.AppEntry e0 = AuraState.byPkg.get(pkg);
            decideNow = e0 == null || (!e0.server.isEmpty() && e0.rerolls < rerollMax && !rerollBroken
                    && (AuraState.duplicatesOf(e0) > 0 || (rerollOld && AuraState.isOld(e0))));
        }
        if (!decideNow && System.currentTimeMillis() - zoneWaitStart < delay1) {
            final String p0 = pkg;
            handler.postDelayed(() -> checkReroll(p0), 500);
            return;
        }
        boolean again = false; String why = ""; String cur = ""; String restored = null;
        synchronized (AuraState.LOCK) {
            AuraState.AppEntry e = AuraState.byPkg.get(pkg);
            if (e != null && e.server.isEmpty() && e.rerolls > 0 && e.history.endsWith("→")) {
                // dibuka ulang tapi ZoneID baru tidak muncul: kembalikan nilai lama, hentikan acak ulang
                String h = e.history.substring(0, e.history.length() - 1);
                int i = h.lastIndexOf('→');
                restored = i >= 0 ? h.substring(i + 1) : h;
                e.server = restored;
                AuraState.version++;
            }
            if (restored == null && !rerollBroken && e != null && !e.server.isEmpty() && e.rerolls < rerollMax) {
                cur = e.server;
                if (AuraState.duplicatesOf(e) > 0) { again = true; why = "kembar"; }
                else if (rerollOld && AuraState.isOld(e)) { again = true; why = "server lama"; }
                if (again) {
                    e.rerolls++;
                    e.history += e.server + "→";
                    e.server = "";
                    AuraState.rerollingPkg = pkg;
                    AuraState.version++;
                }
            }
        }
        if (restored != null) {
            rerollBroken = true;
            AuraState.event("ZoneID baru TIDAK muncul setelah " + pkg + " dibuka ulang → acak ulang dihentikan untuk putaran ini");
        }
        if (!again) {
            synchronized (AuraState.LOCK) { AuraState.rerollingPkg = ""; }
            handler.post(tick);
            return;
        }
        AuraState.event("Acak ulang " + pkg + " (" + cur + " " + why + ")…");
        final String p = pkg;
        new Thread(() -> {
            int code = ShizukuBridge.run("am", "force-stop", p);
            handler.postDelayed(() -> {
                if (!isRunning() || finishing) return;
                if (code != 0) AuraState.event("Gagal menutup " + p + " (kode " + code + ")");
                boolean ok = launch(p);
                zoneWaitStart = System.currentTimeMillis();
                // rerollingPkg dikosongkan saat keputusan akhir (di checkReroll), bukan di sini
                handler.postDelayed(() -> checkReroll(p), ok ? 500 : 700);
            }, 600);
        }, "aura-reroll").start();
    }

    private boolean launch(String pkg) {
        try {
            Intent li = getPackageManager().getLaunchIntentForPackage(pkg);
            if (li == null) return false;
            if (homeStyle && li.getComponent() != null) {
                // Sama persis dengan ketukan ikon di layar utama: MAIN + LAUNCHER, tanpa nama paket,
                // NEW_TASK | RESET_TASK_IF_NEEDED.
                Intent h = new Intent(Intent.ACTION_MAIN);
                h.addCategory(Intent.CATEGORY_LAUNCHER);
                h.setComponent(li.getComponent());
                h.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                startActivity(h);
            } else {
                li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(li);
            }
            return true;
        } catch (Exception e) {
            AuraState.event("Error " + pkg + ": " + e.getMessage());
            return false;
        }
    }

    private void summary() {
        int withId = 0, unique, dup = 0, relog = 0, killed = 0;
        java.util.HashSet<String> ids = new java.util.HashSet<>();
        java.util.HashSet<String> fresh = new java.util.HashSet<>();
        synchronized (AuraState.LOCK) {
            for (AuraState.AppEntry e : AuraState.apps) {
                if (!e.server.isEmpty()) {
                    withId++;
                    if (AuraState.duplicatesOf(e) > 0) dup++;
                    if (!e.dropped) {
                        ids.add(e.server);
                        if (!AuraState.isOld(e) && e.restarts == 0) fresh.add(e.server);
                    }
                }
                if (e.restarts > 0) relog++;
                if (e.kills > 0) killed++;
            }
        }
        unique = ids.size();
        AuraState.event("Selesai. ID terbaca " + withId + " · server dibuat " + unique + " · kembar " + dup
                + " · relog " + relog + " · dimatikan sistem " + killed
                + " · server BARU tanpa relog: " + fresh.size()
                + (reroll ? " · total acak ulang: " + totalRerolls() : ""));
    }

    private int totalRerolls() {
        int n = 0;
        synchronized (AuraState.LOCK) { for (AuraState.AppEntry e : AuraState.apps) n += e.rerolls; }
        return n;
    }

    private boolean finishing;

    private void finishRun(boolean openLauncher) {
        if (finishing) return;
        finishing = true;
        handler.removeCallbacksAndMessages(null);
        synchronized (AuraState.LOCK) { AuraState.running = false; AuraState.currentPkg = ""; AuraState.version++; }
        removeOverlay();
        final LogWatcher w = watcher;
        watcher = null;
        if (w != null) w.shutdown();
        final ScreenWatcher sc = screen;
        screen = null;
        if (sc != null) sc.stop();
        final long t0 = System.currentTimeMillis();
        // tetap sebagai layanan foreground sampai file log selesai ditulis (maks 8 detik)
        handler.post(new Runnable() {
            @Override public void run() {
                if (w != null && w.isAlive() && System.currentTimeMillis() - t0 < 8000) {
                    handler.postDelayed(this, 250);
                    return;
                }
                AuraState.save(RunService.this);
                Stock.addRun(RunService.this);
                releaseWakeLock();
                if (openLauncher) {
                    try {
                        startActivity(new Intent(RunService.this, MainActivity.class)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
                    } catch (Exception ignored) {}
                }
                stopForeground(true);
                stopSelf();
            }
        });
    }

    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (watcher != null) { watcher.shutdown(); watcher = null; }
        synchronized (AuraState.LOCK) { AuraState.running = false; AuraState.version++; }
        AuraState.save(this);
        removeOverlay();
        releaseWakeLock();
        super.onDestroy();
    }

    // ---------- wake lock & panel melayang ----------

    private void acquireWakeLock() {
        try {
            PowerManager pm = getSystemService(PowerManager.class);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "aura:run");
            wakeLock.acquire(6 * 60 * 60 * 1000L);
        } catch (Exception ignored) {}
    }

    private void releaseWakeLock() {
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Exception ignored) {}
        wakeLock = null;
    }

    private void addOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            AuraState.event("Izin tampil di atas aplikasi lain belum aktif: layar bisa mati sendiri");
            return;
        }
        wm = getSystemService(WindowManager.class);
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        WindowManager.LayoutParams lp;
        if (showPanel) {
            TextView tv = new TextView(this);
            tv.setTextColor(Color.WHITE);
            tv.setTextSize(15);
            tv.setPadding(dp(14), dp(8), dp(14), dp(8));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xCC1B1220);
            bg.setCornerRadius(dp(14));
            tv.setBackground(bg);
            overlayText = tv;
            overlay = tv;
            lp = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            lp.y = dp(40);   // sedikit lebih ke bawah
        } else {
            overlay = new View(this);
            lp = new WindowManager.LayoutParams(1, 1,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
        }
        lp.alpha = 0.75f; // di bawah 0.8 agar sentuhan tetap tembus ke game (Android 12+)
        try {
            wm.addView(overlay, lp);
            updateOverlay();
        } catch (Exception e) {
            overlay = null; overlayText = null;
            AuraState.event("Panel melayang gagal tampil: " + e.getMessage());
        }
    }

    private void removeOverlay() {
        try { if (overlay != null && wm != null) wm.removeView(overlay); } catch (Exception ignored) {}
        overlay = null; overlayText = null;
        try { if (nextBtn != null && wm != null) wm.removeView(nextBtn); } catch (Exception ignored) {}
        nextBtn = null;
    }

    /** Tombol LANJUT kecil di pojok kiri atas (bisa diketuk). */
    private void addNextButton() {
        if (!Settings.canDrawOverlays(this)) return;
        if (wm == null) wm = getSystemService(WindowManager.class);
        TextView b = new TextView(this);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15);
        b.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(18), dp(10), dp(18), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xEEE2468F);
        bg.setCornerRadius(dp(14));
        b.setBackground(bg);
        b.setOnClickListener(v -> onNextTap());
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.END | Gravity.CENTER_VERTICAL;   // kanan, tepat di tengah
        lp.x = dp(12); lp.y = 0;
        try { wm.addView(b, lp); nextBtn = b; updateNextButton(); }
        catch (Exception e) { AuraState.event("Tombol LANJUT gagal tampil: " + e.getMessage()); }
    }

    private void updateNextButton() {
        if (nextBtn == null) return;
        int st, pos, n;
        synchronized (AuraState.LOCK) { st = AuraState.step; pos = AuraState.pos; n = AuraState.apps.size(); }
        nextBtn.setText("LANJUT ▶");
    }

    private void onNextTap() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastNextTap < 800) return;   // cegah ketuk dobel
        lastNextTap = now;
        if (!isRunning() || finishing) return;
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    private void updateOverlay() {
        if (overlayText == null) return;
        String text;
        synchronized (AuraState.LOCK) {
            AuraState.AppEntry e = AuraState.byPkg.get(AuraState.currentPkg);
            int relog = 0;
            for (AuraState.AppEntry a : AuraState.apps) if (a.restarts > 0) relog++;
            int got = 0, dupN = 0;
            for (AuraState.AppEntry a : AuraState.apps) {
                if (a.server.isEmpty()) continue;
                got++;
                if (AuraState.duplicatesOf(a) > 0) dupN++;
            }
            text = AuraState.monitor
                    ? "PANTAU · ID " + got + "/" + AuraState.apps.size() + " · kembar " + dupN
                    + (e == null ? "" : " · " + e.pkg)
                    : (e == null ? "Step " + AuraState.step : e.pkg + "  " + (e.server.isEmpty() ? "…" : e.server))
                    + "\nStep " + AuraState.step + " · " + AuraState.pos + "/" + AuraState.apps.size()
                    + (e == null || e.server.isEmpty() ? "" : ""
                        + (AuraState.duplicatesOf(e) > 0 ? " KEMBAR" : "") + (AuraState.isOld(e) ? " LAMA" : ""))
                    + (e != null && e.rerolls > 0 ? " · acak ulang " + e.rerolls + "x" : "")
                    + (AuraState.logReaderActive ? " · relog: " + relog : "");
        }
        overlayText.setText(text);
    }

    // ---------- notifikasi ----------

    private Notification buildNotification() {
        String text;
        synchronized (AuraState.LOCK) {
            text = AuraState.running ? "Step " + AuraState.step + " · membuka " + AuraState.pos + "/" + AuraState.apps.size()
                    + (AuraState.currentPkg.isEmpty() ? "" : " · " + AuraState.currentPkg) : "Menyiapkan…";
        }
        PendingIntent open = PendingIntent.getActivity(this, 2, new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 1, new Intent(this, RunService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Aura Cabang Pro")
                .setContentText(text)
                .setSmallIcon(icon())
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder((Icon) null, "Hentikan", stop).build());
        synchronized (AuraState.LOCK) {
            if (AuraState.running && !AuraState.apps.isEmpty()) b.setProgress(AuraState.apps.size() * 2,
                    (AuraState.step - 1) * AuraState.apps.size() + AuraState.pos, false);
        }
        return b.build();
    }

    private void updateNotification() {
        try { getSystemService(NotificationManager.class).notify(1, buildNotification()); } catch (Exception ignored) {}
    }

    private Icon icon() {
        if (smallIcon == null) {
            int s = 48;
            Bitmap bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bmp);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(Color.WHITE);
            c.drawCircle(s / 2f, s / 2f, s / 2f - 2, p);
            p.setColor(Color.TRANSPARENT);
            p.setXfermode(new android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.CLEAR));
            c.drawCircle(s / 2f, s / 2f, s / 5f, p);
            smallIcon = Icon.createWithBitmap(bmp);
        }
        return smallIcon;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    static void start(Context c, Intent i) { c.startForegroundService(i); }
}
