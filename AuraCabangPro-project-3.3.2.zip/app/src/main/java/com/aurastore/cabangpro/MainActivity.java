package com.aurastore.cabangpro;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    static final int BG = 0xFF070B1E, CARD = Theme.GLASS, ACCENT = Theme.CYAN, TEXT = Theme.TEXT,
            MUTED = Theme.MUTED, GREEN = Theme.GREEN, AMBER = Theme.AMBER, RED = Theme.RED, LINE = 0x335CE1E6;

    /** Pemeriksaan ulang lisensi ke server paling cepat tiap 30 menit. */
    private static long lastLicCheck;

    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<String[]> allApps = new ArrayList<>(); // {pkg, label}
    private final Set<String> selected = new HashSet<>();
    private boolean gated;

    private LinearLayout permBox, appList, resultBox, eventBox;
    private TextView selCount, summaryText, runState;
    private EditText filter, delay1, delay2, pattern;
    private EditText minServer;
    private LinearLayout chipRow, permCard, appPanel, delayRow, statRow;
    private TextView selRange, modeNote;
    private Button appToggle;
    private android.widget.Switch swDrop, swPanel;
    private int modeVal, order2Val = 2;
    private LinearLayout targetRow;
    private EditText tgt1, tgt2;
    private EditText maxAliveEd;
    private android.widget.Switch swCloseDone, swNewOnly, swDropUnknown, swCancel;
    private EditText oldAllowedEd;
    private android.widget.Switch swReroll;
    private EditText rerollMaxEd;
    private Intent pendingRun;
    private boolean lastShizukuState;
    private CheckBox cbClose;
    private Button startBtn;
    private int shownVersion = -1;
    private boolean visible;
    private boolean closeWhenStarted;
    private long startClickedAt;

    // tampilan bertab
    private static final int T_HOME = 0, T_SHOP = 1, T_SERVER = 2, T_LOG = 3, T_SET = 4, T_OWNER = 5;
    private final LinearLayout[] pages = new LinearLayout[6];
    private final LinearLayout[] navItems = new LinearLayout[6];
    private ScrollView pageScroll;
    private FrameLayout rootFrame;
    private LinearLayout shopBox, ownerBox, settingsCard, serverGrid;
    private TextView goalNum, goalSub, licLine, totalNum, totalSub, snowBtn, goalBtn;
    private LinearLayout goalFill, goalRest;
    private int tab;
    private boolean owner;
    private LedgerUi ledgerUi;

    private final Runnable poll = new Runnable() {
        @Override public void run() {
            if (!visible) return;
            int v; synchronized (AuraState.LOCK) { v = AuraState.version; }
            if (v != shownVersion) { shownVersion = v; renderResults(); }
            renderRunButton();
            boolean g = ShizukuBridge.isConnected() && ShizukuBridge.isGranted();
            if (g != lastShizukuState) renderPermissions();
            if (closeWhenStarted) {
                boolean started;
                synchronized (AuraState.LOCK) { started = AuraState.pos >= 1
                        || (!AuraState.running && System.currentTimeMillis() - startClickedAt > 4000); }
                if (started) { closeWhenStarted = false; finish(); return; }
            }
            handler.postDelayed(this, 1000);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("cfg", MODE_PRIVATE);
        if (!Lic.localValid(this)) { goLogin(); return; }
        owner = Lic.isOwner(this);
        selected.addAll(prefs.getStringSet("selected", new HashSet<>()));
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        setContentView(buildUi());
        loadApps();
        showTab(T_HOME);
        ShopUi.refresh(this, new Runnable() {
            @Override public void run() { if (!isFinishing() && tab == T_SHOP) renderShop(); }
        });
    }

    private void goLogin() {
        gated = true;
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    @Override protected void onResume() {
        super.onResume();
        if (gated) return;
        visible = true;
        AuraState.loadIfEmpty(this);
        renderPermissions();
        renderLicense();
        renderGoal();
        shownVersion = -1;
        handler.post(poll);
        long now = System.currentTimeMillis();
        if (!owner && now - lastLicCheck > 30L * 60000L) {
            lastLicCheck = now;
            Lic.recheck(this, new Lic.Done() {
                @Override public void on(boolean ok, String message) {
                    if (isFinishing()) return;
                    if (!Lic.localValid(MainActivity.this)) {
                        Toast.makeText(MainActivity.this, "Lisensi tidak berlaku. Masukkan kode lagi.", Toast.LENGTH_LONG).show();
                        goLogin();
                    } else renderLicense();
                }
            });
        }
    }

    @Override protected void onPause() {
        visible = false;
        saveSettings();
        super.onPause();
    }

    // ---------------- UI ----------------

    private View buildUi() {
        rootFrame = Theme.background(this, prefs.getBoolean("snow", true));
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        rootFrame.addView(shell, new FrameLayout.LayoutParams(-1, -1));

        pageScroll = new ScrollView(this);
        pageScroll.setFillViewport(true);
        pageScroll.setVerticalScrollBarEnabled(false);
        FrameLayout host = new FrameLayout(this);
        pageScroll.addView(host, new ViewGroup.LayoutParams(-1, -2));
        shell.addView(pageScroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        for (int i = 0; i < pages.length; i++) {
            LinearLayout p = new LinearLayout(this);
            p.setOrientation(LinearLayout.VERTICAL);
            p.setPadding(dp(16), dp(22), dp(16), dp(16));
            p.setVisibility(View.GONE);
            host.addView(p, new FrameLayout.LayoutParams(-1, -2));
            pages[i] = p;
        }
        final LinearLayout homeBox = pages[T_HOME];
        final LinearLayout setBox = pages[T_SET];

        // ===== BERANDA =====
        LinearLayout head = hrow();
        head.setGravity(Gravity.CENTER_VERTICAL);
        View logo = Theme.logo(this, 60);
        head.addView(logo, new LinearLayout.LayoutParams(dp(60), dp(60)));
        LinearLayout ht = new LinearLayout(this);
        ht.setOrientation(LinearLayout.VERTICAL);
        ht.setPadding(dp(12), 0, 0, 0);
        ht.addView(Theme.text(this, "Aura Cabang Pro", 21, TEXT, true));
        ht.addView(Theme.text(this, "Versi " + BuildInfo.VERSION + " · Aura Store", 11, Theme.CYAN, true));
        head.addView(ht, weight());
        homeBox.addView(head);
        homeBox.addView(Theme.text(this, "Halo, selamat datang di Aura Store", 16, TEXT, true), Theme.lp(this, 12));
        licLine = Theme.text(this, "", 12, MUTED, false);
        homeBox.addView(licLine, Theme.lp(this, 2));
        chipRow = hrow();
        chipRow.setPadding(0, dp(8), 0, dp(2));
        homeBox.addView(chipRow);

        // Izin: hanya tampil jika ada yang belum lengkap
        permCard = card(homeBox, "IZIN BELUM LENGKAP");
        permBox = new LinearLayout(this);
        permBox.setOrientation(LinearLayout.VERTICAL);
        permCard.addView(permBox);

        // Target hari ini
        LinearLayout gc = card(homeBox, "TARGET HARI INI");
        goalNum = text("0 / 1000", 28, TEXT, true);
        gc.addView(goalNum);
        LinearLayout bar = hrow();
        bar.setBackground(round(0x33FFFFFF, 4));
        goalFill = new LinearLayout(this);
        goalFill.setBackground(Theme.gradient(this, 4));
        goalRest = new LinearLayout(this);
        bar.addView(goalFill, new LinearLayout.LayoutParams(0, dp(8), 0.01f));
        bar.addView(goalRest, new LinearLayout.LayoutParams(0, dp(8), 0.99f));
        gc.addView(bar, Theme.lp(this, 8));
        goalSub = text("", 11, MUTED, false);
        gc.addView(goalSub, Theme.lp(this, 6));

        // Putaran terakhir
        LinearLayout c4 = card(homeBox, "PUTARAN TERAKHIR");
        statRow = hrow();
        c4.addView(statRow);

        // Aplikasi (ringkas + buka/tutup)
        LinearLayout c2 = card(homeBox, "APLIKASI");
        LinearLayout ar = hrow();
        ar.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout acol = new LinearLayout(this);
        acol.setOrientation(LinearLayout.VERTICAL);
        selCount = text("", 18, TEXT, true);
        selRange = text("", 12, MUTED, false);
        acol.addView(selCount); acol.addView(selRange);
        ar.addView(acol, weight());
        appToggle = smallButton("Ubah", v -> setAppsOpen(appPanel.getVisibility() != View.VISIBLE));
        ar.addView(appToggle);
        c2.addView(ar);
        appPanel = new LinearLayout(this);
        appPanel.setOrientation(LinearLayout.VERTICAL);
        appPanel.setPadding(0, dp(10), 0, 0);
        filter = edit(prefs.getString("filter", "com.am"), "Saring, mis. com.am", false);
        filter.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b2, int c) {}
            public void onTextChanged(CharSequence s, int a, int b2, int c) {}
            public void afterTextChanged(Editable s) { renderAppList(); }
        });
        appPanel.addView(filter);
        LinearLayout row = hrow();
        row.setPadding(0, dp(8), 0, dp(4));
        row.addView(button("Pilih semua", v -> { for (String[] a : filtered()) selected.add(a[0]); renderAppList(); }), weight());
        row.addView(space(8));
        row.addView(button("Kosongkan", v -> { selected.clear(); renderAppList(); }), weight());
        appPanel.addView(row);
        appList = new LinearLayout(this);
        appList.setOrientation(LinearLayout.VERTICAL);
        appPanel.addView(appList);
        appPanel.addView(button("Selesai ▲", v -> setAppsOpen(false)));
        c2.addView(appPanel);
        LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(-1, -2);
        nl.topMargin = dp(10);
        c2.addView(button("Hilangkan pop-up izin notifikasi di semua cangkang", v -> grantNotifAll()), nl);
        setAppsOpen(false);


        // Mulai
        startBtn = new Button(this);
        startBtn.setAllCaps(false);
        startBtn.setTextSize(18);
        startBtn.setTypeface(Theme.font(this, true));
        startBtn.setTextColor(Theme.NAVY);
        startBtn.setStateListAnimator(null);
        startBtn.setOnClickListener(v -> onStartStop());
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58));
        sp.topMargin = dp(14);
        homeBox.addView(startBtn, sp);
        runState = text("", 13, MUTED, false);
        runState.setGravity(Gravity.CENTER);
        runState.setPadding(0, dp(6), 0, 0);
        homeBox.addView(runState);

        // ===== TOKO =====
        shopBox = pages[T_SHOP];

        // ===== SERVER =====
        LinearLayout srv = pages[T_SERVER];
        srv.addView(Theme.pageHead(this, owner ? "Stok Server" : "Hasil Cabang", "Halo, selamat datang di Aura Store"));
        LinearLayout tc = card(srv, "TOTAL DIBUAT HARI INI");
        totalNum = text("0", 30, TEXT, true);
        tc.addView(totalNum);
        totalSub = text("", 12, MUTED, false);
        tc.addView(totalSub, Theme.lp(this, 2));
        if (!owner) tc.setVisibility(View.GONE);
        LinearLayout sc = card(srv, owner ? "PER NOMOR SERVER" : "HASIL CABANG HARI INI");
        serverGrid = new LinearLayout(this);
        serverGrid.setOrientation(LinearLayout.VERTICAL);
        sc.addView(serverGrid);
        if (owner) sc.setVisibility(View.GONE);
        if (owner) { ledgerUi = new LedgerUi(this); ledgerUi.attach(srv); }
        LinearLayout dc = card(srv, owner ? "PUTARAN TERAKHIR · PER APLIKASI" : "PUTARAN TERAKHIR");
        summaryText = text("", 13, TEXT, true);
        dc.addView(summaryText);
        resultBox = new LinearLayout(this);
        resultBox.setOrientation(LinearLayout.VERTICAL);
        resultBox.setPadding(0, dp(8), 0, 0);
        dc.addView(resultBox);

        // ===== LOG =====
        LinearLayout lg = pages[T_LOG];
        lg.addView(Theme.pageHead(this, "Log", "Halo, selamat datang di Aura Store"));
        LinearLayout lc = card(lg, "CATATAN PROSES");
        eventBox = new LinearLayout(this);
        eventBox.setOrientation(LinearLayout.VERTICAL);
        lc.addView(eventBox);
        lc.addView(ghost("Hapus log & hasil", v -> clearResults()), Theme.lp(this, 10));

        // ===== SETELAN =====
        setBox.addView(Theme.pageHead(this, "Setelan", "Halo, selamat datang di Aura Store"));
        if (owner) {
            TextView ob = text("👑  Mode Owner", 14, Theme.AMBER, true);
            setBox.addView(ob, Theme.lp(this, 6));
        }
        setBox.addView(menu("📘  Tutorial cara pakai", v -> tutorial()), Theme.lp(this, 10));
        setBox.addView(menu("🔐  Panduan izin Shizuku", v -> shizukuGuide()), Theme.lp(this, 8));
        setBox.addView(menu("⚙  Pengaturan putaran", v -> settingsCard.setVisibility(settingsCard.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE)), Theme.lp(this, 8));

        // Pengaturan
        LinearLayout c3 = card(setBox, "CARA PINDAH APLIKASI");
        modeVal = prefs.getInt("modeNext", 0);
        if (modeVal > 2) modeVal = 0;
        c3.addView(segmented(new String[]{"Otomatis", "Ketuk LANJUT", "Lihat layar"}, modeVal, i -> { modeVal = i; renderMode(); }));
        modeNote = text("", 12, MUTED, false);
        modeNote.setPadding(0, dp(6), 0, 0);
        c3.addView(modeNote);
        delayRow = hrow();
        delayRow.setPadding(0, dp(8), 0, 0);
        LinearLayout d1 = labeled("Jeda Step 1 (detik)");
        delay1 = edit(String.valueOf(prefs.getInt("delay1", 8)), "8", true);
        d1.addView(delay1);
        LinearLayout d2 = labeled("Jeda Step 2 (detik)");
        delay2 = edit(String.valueOf(prefs.getInt("delay2", 8)), "8", true);
        d2.addView(delay2);
        delayRow.addView(d1, weight()); delayRow.addView(space(8)); delayRow.addView(d2, weight());
        c3.addView(delayRow);
        targetRow = hrow();
        targetRow.setPadding(0, dp(8), 0, 0);
        LinearLayout t1 = labeled("Step 1 pindah saat loading (%)");
        tgt1 = edit(String.valueOf(prefs.getInt("tgt1", 20)), "20", true);
        t1.addView(tgt1);
        LinearLayout t2 = labeled("Step 2 pindah saat loading (%)");
        tgt2 = edit(String.valueOf(prefs.getInt("tgt2", 97)), "97", true);
        t2.addView(tgt2);
        targetRow.addView(t1, weight()); targetRow.addView(space(8)); targetRow.addView(t2, weight());
        c3.addView(targetRow);

        TextView ol = text("URUTAN STEP 2", 12, MUTED, true);
        ol.setPadding(0, dp(14), 0, dp(6));
        c3.addView(ol);
        order2Val = prefs.getInt("order2", 2);
        c3.addView(segmented(new String[]{"Urut server", "Maju", "Terbalik"},
                order2Val == 2 ? 0 : order2Val == 1 ? 1 : 2, i -> order2Val = i == 0 ? 2 : i == 1 ? 1 : 0));
        LinearLayout sp1 = new LinearLayout(this); sp1.setPadding(0, dp(8), 0, 0); c3.addView(sp1);
        swDrop = toggle(c3, "Buang cangkang kembar", prefs.getBoolean("dropDup", true));
        swReroll = toggle(c3, "Acak ulang cangkang kembar (tutup & buka lagi supaya dapat server lain)", prefs.getBoolean("reroll", true));
        LinearLayout rm = labeled("Maks. acak ulang per cangkang (1-5)");
        rerollMaxEd = edit(String.valueOf(prefs.getInt("rerollMax", 3)), "3", true);
        rm.addView(rerollMaxEd);
        c3.addView(rm);
        swPanel = toggle(c3, "Panel info di layar", prefs.getBoolean("panel", true));
        swNewOnly = toggle(c3, "Hanya server BARU (57092 ke atas) · server lama dibuang", prefs.getBoolean("newOnly", true));
        LinearLayout oa = labeled("Server lama yang tetap disimpan per putaran");
        oldAllowedEd = edit(String.valueOf(prefs.getInt("oldAllowed", 1)), "1", true);
        oa.addView(oldAllowedEd);
        c3.addView(oa);
        swCancel = toggle(c3, "Ketuk Cancel otomatis pada kotak biru \"Loading resources failed\" (minta izin rekam layar)", prefs.getBoolean("autoCancel", false));
        swDropUnknown = toggle(c3, "Buang cangkang yang ZoneID-nya tidak terbaca (mati = ditaruh paling akhir)", prefs.getBoolean("dropUnknown", false));
        swCloseDone = toggle(c3, "Tutup cangkang yang sudah selesai Step 2 (RAM lega)", prefs.getBoolean("closeDone", true));
        LinearLayout mx = labeled("Maks. server per putaran (sesuai RAM HP, 0 = tanpa batas)");
        mx.setPadding(0, dp(8), 0, 0);
        maxAliveEd = edit(String.valueOf(prefs.getInt("maxAlive4", 24)), "24", true);
        mx.addView(maxAliveEd);
        c3.addView(mx);
        renderMode();

        // pilihan lama: disembunyikan, nilai tetap
        cbClose = check("", true);
        minServer = edit(String.valueOf(prefs.getInt("minServer2", 57092)), "57092", true);
        pattern = edit(LogWatcher.DEFAULT_PATTERN, LogWatcher.DEFAULT_PATTERN, false);

        settingsCard = c3;
        settingsCard.setVisibility(View.GONE);

        if (!owner) {
            LinearLayout info = Theme.card(this);
            info.addView(Theme.plain(this, "🔑  Kode: " + Lic.maskedCode(this), 12, TEXT, true));
            info.addView(Theme.plain(this, "⏳  Aktif s/d " + Lic.expiryDateText(this) + " (" + Lic.remainingText(this) + ")", 12, TEXT, true), Theme.lp(this, 6));
            info.addView(Theme.plain(this, "📱  ID HP: " + Lic.deviceShort(this), 12, TEXT, true), Theme.lp(this, 6));
            setBox.addView(info, Theme.lp(this, 8));
        }
        snowBtn = menu("", v -> {
            boolean on = !prefs.getBoolean("snow", true);
            prefs.edit().putBoolean("snow", on).apply();
            applySnow();
        });
        if (owner) setBox.addView(snowBtn, Theme.lp(this, 8));
        applySnow();
        goalBtn = menu("", v -> goalDialog());
        setBox.addView(goalBtn, Theme.lp(this, 8));
        setBox.addView(menu("🧹  Hapus log & hasil", v -> clearResults()), Theme.lp(this, 8));
        if (owner) setBox.addView(menu("🛍  Atur produk toko", v -> ShopUi.editor(this, this::renderShop)), Theme.lp(this, 8));
        setBox.addView(menu("ℹ  Versi & info HP", v -> infoDialog()), Theme.lp(this, 8));
        if (owner) {
            setBox.addView(menu("Keluar Owner", v -> {
                Lic.ownerLogout(this);
                goLogin();
            }), Theme.lp(this, 14));
        }

        // ===== OWNER =====
        ownerBox = pages[T_OWNER];

        // ===== NAVIGASI BAWAH =====
        LinearLayout nav = hrow();
        nav.setBackground(Theme.glass(this, 24));
        nav.setPadding(dp(6), dp(6), dp(6), dp(6));
        String[] ic = {"🏠", "🛍", "📊", "📜", "⚙️", "👑"};
        String[] nm = {"Beranda", "Toko", owner ? "Server" : "Hasil", "Log", "Setelan", "Owner"};
        for (int i = 0; i < 6; i++) {
            if (i == T_OWNER && !owner) continue;
            final int k = i;
            LinearLayout it = new LinearLayout(this);
            it.setOrientation(LinearLayout.VERTICAL);
            it.setGravity(Gravity.CENTER);
            it.setPadding(0, 0, 0, 0);
            TextView ico = Theme.plain(this, ic[i], 18, TEXT, true);
            ico.setGravity(Gravity.CENTER);
            ico.setIncludeFontPadding(false);
            it.addView(ico, new LinearLayout.LayoutParams(-1, dp(24)));
            TextView lb = Theme.plain(this, nm[i], 10, TEXT, true);
            lb.setGravity(Gravity.CENTER);
            lb.setIncludeFontPadding(false);
            it.addView(lb, new LinearLayout.LayoutParams(-1, dp(14)));
            it.setOnClickListener(v -> showTab(k));
            nav.addView(it, new LinearLayout.LayoutParams(0, dp(52), 1f));
            navItems[i] = it;
        }
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-1, -2);
        nlp.setMargins(dp(12), dp(4), dp(12), dp(10));
        shell.addView(nav, nlp);
        return rootFrame;
    }

    private void showTab(int t) {
        if (t == T_OWNER && !owner) t = T_HOME;
        tab = t;
        for (int i = 0; i < pages.length; i++) pages[i].setVisibility(i == t ? View.VISIBLE : View.GONE);
        for (int i = 0; i < navItems.length; i++) {
            if (navItems[i] == null) continue;
            navItems[i].setBackground(i == t ? Theme.outlined(this, 0x33101E45, Theme.CYAN, 16) : null);
        }
        if (t == T_SHOP) renderShop();
        if (t == T_OWNER) OwnerUi.reload(this, ownerBox);
        if (t == T_SET) renderSettingsLabels();
        shownVersion = -1;
        pageScroll.scrollTo(0, 0);
    }

    private void renderShop() { ShopUi.render(this, shopBox, owner, this::renderShop); }

    private void renderLicense() {
        if (licLine == null) return;
        licLine.setText(owner ? "Mode Owner" : "Kode aktif · " + Lic.remainingText(this));
    }

    private void applySnow() {
        boolean on = prefs.getBoolean("snow", true);
        View s = rootFrame.findViewWithTag("snow");
        if (s != null) s.setVisibility(on ? View.VISIBLE : View.GONE);
        renderSettingsLabels();
    }

    private void renderSettingsLabels() {
        if (snowBtn != null) snowBtn.setText("❄  Efek salju: " + (prefs.getBoolean("snow", true) ? "AKTIF" : "MATI"));
        if (goalBtn != null) goalBtn.setText("🎯  Target harian: " + goal());
    }

    private int goal() { return Math.max(1, prefs.getInt("goal", 1000)); }

    private void renderGoal() {
        if (goalNum == null) return;
        int tot = Stock.total(this), g = goal();
        goalNum.setText(tot + " / " + g);
        float p = Math.max(0.01f, Math.min(1f, tot / (float) g));
        ((LinearLayout.LayoutParams) goalFill.getLayoutParams()).weight = p;
        ((LinearLayout.LayoutParams) goalRest.getLayoutParams()).weight = 1f - p;
        goalFill.requestLayout();
        goalSub.setText(tot >= g ? "Target hari ini tercapai 🎉" : "Sisa " + (g - tot) + " lagi · stok dihitung dari semua putaran hari ini");
    }

    private void goalDialog() {
        LinearLayout b = Theme.dialogBox(this, "Target harian");
        final EditText ed = Theme.input(this, String.valueOf(goal()), "mis. 1000", true);
        b.addView(ed, Theme.lp(this, 10));
        final AlertDialog[] dlg = new AlertDialog[1];
        b.addView(Theme.primary(this, "Simpan", v -> {
            int n = parse(ed, goal());
            prefs.edit().putInt("goal", Math.max(1, n)).apply();
            dlg[0].dismiss();
            renderGoal();
            renderSettingsLabels();
        }), Theme.lp(this, 12));
        b.addView(Theme.ghost(this, "Batal", v -> dlg[0].dismiss()), Theme.lp(this, 6));
        dlg[0] = Theme.dialog(this, b);
    }

    private void clearResults() {
        if (RunService.isRunning()) { toast("Hentikan proses dulu"); return; }
        AuraState.clearAll(this);
        shownVersion = -1;
        toast("Log & hasil dihapus");
    }

    private void tutorial() {
        LinearLayout b = Theme.dialogBox(this, "📘 Tutorial cara pakai");
        String[][] st = {
                {"Aktifkan Shizuku", "Buka Shizuku → Mulai lewat Debugging nirkabel"},
                {"Pilih aplikasi", "Beranda → Ubah → Pilih semua cangkang"},
                {"Atur putaran", "Setelan → Pengaturan putaran"},
                {"Tekan MULAI", "Pilih \"Seluruh layar\" lalu Mulai"},
                {"Cek hasil", "Lihat tab Log & Server"}};
        for (int i = 0; i < st.length; i++) {
            LinearLayout r = hrow();
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setBackground(Theme.outlined(this, 0x33101E45, Theme.STROKE, 14));
            r.setPadding(dp(10), dp(8), dp(10), dp(8));
            TextView n = Theme.plain(this, String.valueOf(i + 1), 15, Theme.NAVY, true);
            n.setGravity(Gravity.CENTER);
            n.setBackground(Theme.gradient(this, 16));
            r.addView(n, new LinearLayout.LayoutParams(dp(32), dp(32)));
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(10), 0, 0, 0);
            col.addView(Theme.plain(this, st[i][0], 13, TEXT, true));
            col.addView(Theme.plain(this, st[i][1], 11, MUTED, false));
            r.addView(col, weight());
            b.addView(r, Theme.lp(this, 8));
        }
        final AlertDialog[] dlg = new AlertDialog[1];
        b.addView(Theme.ghost(this, "Tutup", v -> dlg[0].dismiss()), Theme.lp(this, 12));
        dlg[0] = Theme.dialog(this, b);
    }

    private void shizukuGuide() {
        LinearLayout b = Theme.dialogBox(this, "🔐 Panduan izin Shizuku");
        TextView t = Theme.plain(this,
                "1. Buka aplikasi Shizuku, pastikan tertulis \"Shizuku is running\" (mulai lewat Debugging nirkabel).\n\n"
                + "2. Kembali ke launcher ini. Di kartu IZIN, tekan Izinkan pada baris Shizuku, lalu pilih Izinkan di jendela Shizuku.\n\n"
                + "3. Aktifkan juga: Tampil di atas aplikasi lain, Notifikasi, dan Abaikan optimasi baterai.\n\n"
                + "4. Kalau Shizuku mati lagi setelah HP restart, mulai ulang Shizuku lalu buka launcher ini.", 12, TEXT, false);
        t.setLineSpacing(0, 1.15f);
        b.addView(t, Theme.lp(this, 10));
        final AlertDialog[] dlg = new AlertDialog[1];
        b.addView(Theme.ghost(this, "Buka Shizuku", v -> {
            Intent li = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
            if (li != null) open(li); else toast("Aplikasi Shizuku tidak ditemukan");
        }), Theme.lp(this, 12));
        b.addView(Theme.ghost(this, "Tutup", v -> dlg[0].dismiss()), Theme.lp(this, 6));
        dlg[0] = Theme.dialog(this, b);
    }

    private void infoDialog() {
        LinearLayout b = Theme.dialogBox(this, "ℹ Versi & info HP");
        StringBuilder sb = new StringBuilder();
        sb.append("Aura Cabang Pro ").append(BuildInfo.VERSION).append("\n");
        sb.append("ID HP: ").append(Lic.deviceShort(this)).append("\n");
        if (owner) sb.append("Mode: Owner\n");
        else {
            sb.append("Kode: ").append(Lic.maskedCode(this)).append("\n");
            sb.append("Aktif s/d: ").append(Lic.expiryDateText(this)).append(" (").append(Lic.remainingText(this)).append(")\n");
        }
        TextView t = Theme.plain(this, sb.toString(), 13, TEXT, false);
        t.setLineSpacing(0, 1.2f);
        b.addView(t, Theme.lp(this, 10));
        final AlertDialog[] dlg = new AlertDialog[1];
        b.addView(Theme.ghost(this, "Salin ID HP", v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("id", Lic.deviceShort(this)));
            toast("ID HP disalin");
        }), Theme.lp(this, 12));
        b.addView(Theme.ghost(this, "Tutup", v -> dlg[0].dismiss()), Theme.lp(this, 6));
        dlg[0] = Theme.dialog(this, b);
    }

    private Button menu(String label, View.OnClickListener l) {
        Button b = Theme.ghost(this, label, l);
        b.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        b.setTextSize(14);
        b.setPadding(dp(16), 0, dp(16), 0);
        b.setMinHeight(dp(50)); b.setMinimumHeight(dp(50));
        return b;
    }

    private Button ghost(String label, View.OnClickListener l) { return Theme.ghost(this, label, l); }

    /** Pop-up "Izinkan notifikasi" muncul di cangkang baru dan mengganggu loading: izinkan sekaligus lewat Shizuku. */
    private void grantNotifAll() {
        if (!ShizukuBridge.isGranted()) { toast("Shizuku belum aktif"); return; }
        final ArrayList<String> pk = new ArrayList<>();
        for (String[] a : selectedOrdered()) pk.add(a[0]);
        if (pk.isEmpty()) { toast("Pilih aplikasi dulu"); return; }
        toast("Memproses " + pk.size() + " cangkang…");
        new Thread(() -> {
            int ok = 0;
            for (String p : pk) {
                int c = ShizukuBridge.run("pm", "grant", p, "android.permission.POST_NOTIFICATIONS");
                if (c == 0) ok++;
            }
            final int fok = ok;
            handler.post(() -> toast("Selesai: " + fok + "/" + pk.size() + " cangkang tidak akan menampilkan pop-up notifikasi lagi"));
            AuraState.event("Izin notifikasi diberikan ke " + fok + "/" + pk.size() + " cangkang (pop-up tidak muncul lagi)");
        }, "aura-notif").start();
    }

    private void setAppsOpen(boolean open) {
        appPanel.setVisibility(open ? View.VISIBLE : View.GONE);
        appToggle.setText(open ? "Tutup" : "Ubah");
    }

    private void renderMode() {
        if (modeNote == null) return;
        boolean manual = modeVal == 1, look = modeVal == 2;
        delayRow.setVisibility(manual || look ? View.GONE : View.VISIBLE);
        targetRow.setVisibility(look ? View.VISIBLE : View.GONE);
        modeNote.setText(manual
                ? "Tombol LANJUT muncul di kanan tengah. Ketuk untuk pindah ke aplikasi berikutnya. Tidak ada hitungan detik. Cocok setelah update game."
                : look ? "Launcher melihat bar loading oranye: Step 1 pindah saat loading mencapai angka kiri, Step 2 saat mencapai angka kanan (atau selesai). Tidak perlu menebak detik. Minta izin rekam layar."
                : "Pindah otomatis setiap beberapa detik.");
    }

    interface IntCb { void on(int i); }

    private LinearLayout segmented(String[] items, int sel, IntCb cb) {
        LinearLayout g = hrow();
        g.setBackground(round(0x66000000, 12));
        g.setPadding(dp(3), dp(3), dp(3), dp(3));
        final TextView[] tv = new TextView[items.length];
        for (int i = 0; i < items.length; i++) {
            final int k = i;
            TextView t = text(items[i], 13, MUTED, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(9), 0, dp(9));
            t.setOnClickListener(v -> {
                for (int j = 0; j < tv.length; j++) styleSeg(tv[j], j == k);
                cb.on(k);
            });
            tv[i] = t;
            styleSeg(t, i == sel);
            g.addView(t, weight());
        }
        return g;
    }

    private void styleSeg(TextView t, boolean on) {
        t.setBackground(on ? Theme.gradient(this, 10) : null);
        t.setTextColor(on ? Theme.NAVY : MUTED);
    }

    private android.widget.Switch toggle(LinearLayout parent, String label, boolean on) {
        android.widget.Switch s = new android.widget.Switch(this);
        s.setText(label);
        s.setTextColor(TEXT);
        s.setTextSize(15);
        s.setChecked(on);
        s.setPadding(0, dp(8), 0, dp(8));
        s.setThumbTintList(android.content.res.ColorStateList.valueOf(Color.WHITE));
        s.setTrackTintList(new android.content.res.ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}}, new int[]{ACCENT, 0xFF4A3A42}));
        parent.addView(s, new LinearLayout.LayoutParams(-1, -2));
        return s;
    }

    private Button smallButton(String s, View.OnClickListener l) {
        Button b = button(s, l);
        b.setTextColor(Theme.CYAN);
        return b;
    }

    private View chip(String s, boolean ok) {
        TextView t = text((ok ? "✓ " : "✗ ") + s, 11, ok ? GREEN : AMBER, true);
        t.setPadding(dp(10), dp(4), dp(10), dp(4));
        t.setBackground(round(ok ? 0xFF1F3A2C : 0xFF3A2E14, 20));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dp(6);
        t.setLayoutParams(lp);
        return t;
    }

    private View stat(String num, String label, int color) {
        LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.VERTICAL);
        b.setGravity(Gravity.CENTER);
        b.setPadding(0, dp(8), 0, dp(8));
        b.setBackground(round(0x66000000, 12));
        TextView n = text(num, 20, color, true); n.setGravity(Gravity.CENTER);
        TextView l = text(label, 11, MUTED, false); l.setGravity(Gravity.CENTER);
        b.addView(n); b.addView(l);
        return b;
    }

    private void renderPermissions() {
        if (permBox == null) return;
        permBox.removeAllViews();
        permMissing = 0;
        boolean overlay = Settings.canDrawOverlays(this);
        permRow("Tampil di atas aplikasi lain", "Wajib: untuk membuka aplikasi dari latar & menjaga layar tetap menyala",
                overlay, "Aktifkan", v -> open(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))));
        boolean notif = Build.VERSION.SDK_INT < 33 || checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED;
        permRow("Notifikasi", "Untuk tombol Hentikan & progres", notif, "Aktifkan", v -> {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        });
        PowerManager pm = getSystemService(PowerManager.class);
        boolean batt = pm.isIgnoringBatteryOptimizations(getPackageName());
        permRow("Abaikan optimasi baterai", "Agar launcher tidak dihentikan di tengah proses", batt, "Aktifkan",
                v -> open(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName()))));
        boolean connected = ShizukuBridge.isConnected();
        boolean granted = connected && ShizukuBridge.isGranted();
        lastShizukuState = granted;
        if (granted) {
            permRow("Shizuku (baca ID server & relog)", "Aktif", true, "", null);
        } else if (connected) {
            permRow("Shizuku (baca ID server & relog)", "Shizuku berjalan. Tekan Izinkan, lalu pilih Izinkan di jendela Shizuku.",
                    false, "Izinkan", v -> {
                        if (!ShizukuBridge.requestPermission()) toast("Gagal meminta izin. Buka Shizuku, pastikan berjalan.");
                    });
        } else {
            permRow("Shizuku (baca ID server & relog)",
                    "Belum terhubung. Buka Shizuku, pastikan \"Shizuku is running\", lalu tutup & buka lagi launcher ini.",
                    false, "Buka Shizuku", v -> {
                        Intent li = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                        if (li != null) open(li); else toast("Aplikasi Shizuku tidak ditemukan");
                    });
        }
        permCard.setVisibility(permMissing > 0 ? View.VISIBLE : View.GONE);
        chipRow.removeAllViews();
        chipRow.addView(chip(permMissing == 0 || (permMissing == 1 && !granted) ? "Izin lengkap" : "Izin kurang", permMissing == 0 || (permMissing == 1 && !granted)));
        chipRow.addView(chip(granted ? "Shizuku aktif" : "Shizuku mati", granted));
    }
    private int permMissing;

    private void permRow(String name, String desc, boolean ok, String action, View.OnClickListener l) {
        LinearLayout r = hrow();
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(6), 0, dp(6));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text((ok ? "✓  " : "✗  ") + name, 14, ok ? GREEN : AMBER, true));
        col.addView(text(desc, 12, MUTED, false));
        r.addView(col, weight());
        if (!ok) { r.addView(space(8)); r.addView(button(action, l)); permMissing++; }
        if (!ok) permBox.addView(r);
    }

    private void loadApps() {
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> ris = pm.queryIntentActivities(i, 0);
            ArrayList<String[]> list = new ArrayList<>();
            HashSet<String> seen = new HashSet<>();
            for (ResolveInfo ri : ris) {
                String p = ri.activityInfo.packageName;
                if (p.equals(getPackageName()) || !seen.add(p)) continue;
                String label;
                try { label = String.valueOf(ri.loadLabel(pm)); } catch (Exception e) { label = p; }
                list.add(new String[]{p, label});
            }
            Collections.sort(list, (a, b2) -> a[0].compareTo(b2[0]));
            handler.post(() -> { allApps.clear(); allApps.addAll(list); renderAppList(); });
        }).start();
    }

    private List<String[]> filtered() {
        String f = filter.getText().toString().trim().toLowerCase();
        ArrayList<String[]> out = new ArrayList<>();
        for (String[] a : allApps)
            if (f.isEmpty() || a[0].toLowerCase().contains(f) || a[1].toLowerCase().contains(f)) out.add(a);
        return out;
    }

    private ArrayList<String[]> selectedOrdered() {
        ArrayList<String[]> out = new ArrayList<>();
        for (String[] a : allApps) if (selected.contains(a[0])) out.add(a);
        return out;
    }

    private void renderAppList() {
        appList.removeAllViews();
        List<String[]> f = filtered();
        ArrayList<String[]> sel = selectedOrdered();
        for (String[] a : f) {
            CheckBox cb = new CheckBox(this);
            int n = indexOf(sel, a[0]);
            cb.setText((n >= 0 ? (n + 1) + ".  " : "") + a[1] + "\n" + a[0]);
            cb.setTextColor(TEXT);
            cb.setTextSize(13);
            cb.setChecked(selected.contains(a[0]));
            cb.setButtonTintList(android.content.res.ColorStateList.valueOf(ACCENT));
            cb.setOnCheckedChangeListener((v, on) -> {
                if (on) selected.add(a[0]); else selected.remove(a[0]);
                handler.post(this::renderAppList);
            });
            appList.addView(cb);
        }
        if (allApps.isEmpty()) appList.addView(text("Memuat daftar aplikasi…", 13, MUTED, false));
        else if (f.isEmpty()) appList.addView(text("Tidak ada aplikasi yang cocok dengan saringan.", 13, MUTED, false));
        selCount.setText(sel.size() + " aplikasi dipilih");
        selRange.setText(sel.isEmpty() ? "Ketuk Ubah untuk memilih" : sel.get(0)[0] + "  →  " + sel.get(sel.size() - 1)[0]);
    }

    private static int indexOf(List<String[]> l, String p) {
        for (int i = 0; i < l.size(); i++) if (l.get(i)[0].equals(p)) return i;
        return -1;
    }

    private void onStartStop() {
        if (RunService.isRunning()) {
            startService(new Intent(this, RunService.class).setAction(RunService.ACTION_STOP));
            return;
        }
        ArrayList<String[]> sel = selectedOrdered();
        if (sel.isEmpty()) { toast("Pilih minimal satu aplikasi dulu"); return; }
        if (!Settings.canDrawOverlays(this)) { toast("Aktifkan izin 'Tampil di atas aplikasi lain' dulu"); return; }
        if (!ShizukuBridge.isGranted()) { toast("Shizuku belum aktif: ZoneID tidak bisa dibaca. Nyalakan Shizuku dulu."); return; }
        int d1 = parse(delay1, 8), d2 = parse(delay2, 8);
        if (d1 < 2 || d2 < 2) { toast("Jeda minimal 2 detik"); return; }
        saveSettings();

        AuraState.reset(sel);
        ArrayList<String> pkgs = new ArrayList<>();
        for (String[] a : sel) pkgs.add(a[0]);
        Intent i = new Intent(this, RunService.class).setAction(RunService.ACTION_START)
                .putStringArrayListExtra("pkgs", pkgs)
                .putExtra("delay1", d1 * 1000L)
                .putExtra("delay2", d2 * 1000L)
                .putExtra("order2", order2Val)
                .putExtra("minServer", parse(minServer, 57092))
                .putExtra("reroll", swReroll.isChecked())
                .putExtra("rerollOld", swReroll.isChecked() && swNewOnly.isChecked())
                .putExtra("rerollMax", parse(rerollMaxEd, 3))
                .putExtra("monitor", false)
                .putExtra("homeStyle", true)
                .putExtra("viaHome", false)
                .putExtra("dropDup", swDrop.isChecked())
                .putExtra("manual", modeVal == 1)
                .putExtra("maxAlive", parse(maxAliveEd, 24))
                .putExtra("closeDone", swCloseDone.isChecked())
                .putExtra("dropUnknown", swDropUnknown.isChecked())
                .putExtra("autoCancel", swCancel.isChecked())
                .putExtra("screenTiming", modeVal == 2)
                .putExtra("target1", parse(tgt1, 20))
                .putExtra("target2", parse(tgt2, 97))
                .putExtra("oldAllowed", swNewOnly.isChecked() ? Math.max(0, parse(oldAllowedEd, 1)) : -1)
                .putExtra("noOverlay", false)
                .putExtra("back", false)
                .putExtra("panel", swPanel.isChecked())
                .putExtra("record", false)
                .putExtra("logs", true)
                .putExtra("pattern", pattern.getText().toString());
        if (swCancel.isChecked() || modeVal == 2) {
            pendingRun = i;
            try {
                android.media.projection.MediaProjectionManager mpm = getSystemService(android.media.projection.MediaProjectionManager.class);
                toast("Pilih \"Seluruh layar\" lalu Mulai / Izinkan");
                startActivityForResult(mpm.createScreenCaptureIntent(), 77);
            } catch (Exception e) {
                pendingRun = null;
                toast("Rekam layar tidak tersedia: ketuk Cancel otomatis dimatikan");
                launchRun(i);
            }
            return;
        }
        launchRun(i);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != 77 || pendingRun == null) return;
        Intent i = pendingRun;
        pendingRun = null;
        if (res != RESULT_OK || data == null) {
            toast("Izin lihat layar ditolak. Tekan MULAI lagi dan pilih Izinkan / Seluruh layar.");
            return;
        }
        i.putExtra("projCode", res).putExtra("projData", data);
        launchRun(i);
    }

    private void launchRun(Intent i) {
        RunService.start(this, i);
        // Jangan tutup dulu: jendela persetujuan akses log hanya muncul saat launcher terbuka di layar.
        closeWhenStarted = cbClose.isChecked();
        startClickedAt = System.currentTimeMillis();
    }

    private void renderRunButton() {
        boolean run = RunService.isRunning();
        startBtn.setText(run ? "HENTIKAN" : "MULAI");
        startBtn.setBackground(run ? round(RED, 16) : Theme.gradient(this, 16));
        startBtn.setTextColor(run ? Color.WHITE : Theme.NAVY);
        String s;
        synchronized (AuraState.LOCK) {
 s = run && AuraState.waitingLogConsent ? "Menunggu persetujuan akses log… ketuk IZINKAN di jendela yang muncul"
                    : run ? "Berjalan · Step " + AuraState.step + " · " + AuraState.pos + "/" + AuraState.apps.size()
                    + (AuraState.logReaderActive ? " · pembaca log aktif" : "") : "";
        }
        runState.setText(s);
    }

    private void renderResults() {
        resultBox.removeAllViews();
        eventBox.removeAllViews();
        int withId = 0, dup = 0, relog = 0, killed = 0, old = 0;
        HashSet<String> ids = new HashSet<>();
        ArrayList<String> ev;
        synchronized (AuraState.LOCK) {
            int n = 0;
            for (AuraState.AppEntry e : AuraState.apps) {
                n++;
                int d = AuraState.duplicatesOf(e);
                if (!e.server.isEmpty()) { withId++; if (!e.dropped) ids.add(e.server); }
                if (d > 0) dup++;
                boolean isOld = AuraState.isOld(e);
                if (isOld) old++;
                if (e.restarts > 0) relog++;
                if (e.kills > 0) killed++;
                LinearLayout r = hrow();
                r.setPadding(0, dp(5), 0, dp(5));
                r.addView(text(n + ".", 13, MUTED, false), new LinearLayout.LayoutParams(dp(28), -2));
                r.addView(text(e.pkg, 12, TEXT, false), weight());
                r.addView(text(e.server.isEmpty() ? "–" : e.server, 13, d > 0 ? RED : isOld ? AMBER : TEXT, true),
                        new LinearLayout.LayoutParams(dp(62), -2));
                if (!e.history.isEmpty()) r.setContentDescription(e.history);
                String st; int col;
                if (e.dropped) { st = "DIBUANG"; col = MUTED; }
                else if (e.restarts > 0) { st = "RELOG ×" + e.restarts; col = RED; }
                else if (e.kills > 0) { st = "DIMATIKAN"; col = AMBER; }
                else if (e.launched2) { st = "Hidup"; col = GREEN; }
                else if (e.launched1) { st = "Step 1"; col = MUTED; }
                else { st = "Menunggu"; col = MUTED; }
                if (d > 0) st = st + " · KEMBAR";
                if (isOld) st = st + " · LAMA";
                if (e.rerolls > 0) st = st + " · ulang " + e.rerolls + "x";
                TextView sv = text(st, 11, col, true);
                sv.setGravity(Gravity.END);
                r.addView(sv, new LinearLayout.LayoutParams(dp(104), -2));
                resultBox.addView(r);
                View line = new View(this);
                line.setBackgroundColor(LINE);
                resultBox.addView(line, new LinearLayout.LayoutParams(-1, 1));
            }
            ev = new ArrayList<>(AuraState.events);
            int dropped = 0;
            for (AuraState.AppEntry e : AuraState.apps) if (e.dropped) dropped++;
            statRow.removeAllViews();
            if (AuraState.apps.isEmpty()) {
                statRow.addView(text("Belum ada proses.", 13, MUTED, false));
            } else {
                statRow.addView(stat(String.valueOf(ids.size()), "dibuat", GREEN), weight());
                statRow.addView(space(6));
                statRow.addView(stat(String.valueOf(dropped), "dibuang", MUTED), weight());
                statRow.addView(space(6));
                statRow.addView(stat(String.valueOf(relog), "relog", relog > 0 ? RED : TEXT), weight());
            }
            if (AuraState.apps.isEmpty()) summaryText.setText("Belum ada proses.");
            else summaryText.setText("ID terbaca " + withId + "/" + AuraState.apps.size() + " · server dibuat " + ids.size()
                    + " · kembar " + dup + " · lama " + old + "\nRelog " + relog + " · dimatikan sistem " + killed);
        }
        int max = Math.min(ev.size(), 60);
        for (int i = 0; i < max; i++) {
            String s = ev.get(i);
            int c = s.contains("RELOG") || s.contains("GAGAL") ? RED : s.contains("DIMATIKAN") ? AMBER
                    : s.contains("ID server") ? GREEN : MUTED;
            TextView t = text(s, 12, c, false);
            t.setTypeface(Typeface.MONOSPACE);
            eventBox.addView(t);
        }
        if (ev.isEmpty()) eventBox.addView(text("Belum ada catatan.", 12, MUTED, false));
        renderStock();
        renderGoal();
        if (ledgerUi != null) ledgerUi.refresh();
    }

    /** Tab Server: total dan jumlah akun per nomor server (dijumlah dari semua putaran hari ini). */
    private void renderStock() {
        if (serverGrid == null) return;
        serverGrid.removeAllViews();
        ArrayList<int[]> l = Stock.list(this);
        int tot = 0, neu = 0, oldN = 0;
        int minS = parse(minServer, 57092);
        for (int[] p : l) { tot += p[1]; if (p[0] >= minS) neu += p[1]; else oldN += p[1]; }
        totalNum.setText(String.valueOf(tot));
        totalSub.setText("baru " + neu + " · lama " + oldN);
        if (l.isEmpty()) { serverGrid.addView(text("Belum ada putaran yang selesai hari ini.", 12, MUTED, false)); return; }
        LinearLayout row = null;
        for (int[] p : l) {
            if (row == null || row.getChildCount() >= 3) {
                row = hrow();
                serverGrid.addView(row, Theme.lp(this, 6));
            }
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER);
            cell.setPadding(0, dp(8), 0, dp(8));
            cell.setBackground(Theme.outlined(this, 0x66101E45, p[0] >= minS ? Theme.GREEN : Theme.AMBER, 12));
            cell.addView(text(String.valueOf(p[0]), 13, TEXT, true));
            cell.addView(text(p[1] + " akun", 11, p[0] >= minS ? GREEN : AMBER, true));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            int n = row.getChildCount();
            lp.leftMargin = n == 0 ? 0 : dp(3);
            lp.rightMargin = n == 2 ? 0 : dp(3);
            row.addView(cell, lp);
        }
        while (row != null && row.getChildCount() < 3) row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
    }

    private void saveSettings() {
        if (prefs == null || delay1 == null) return;
        prefs.edit()
                .putStringSet("selected", new HashSet<>(selected))
                .putString("filter", filter.getText().toString())
                .putInt("delay1", parse(delay1, 8))
                .putInt("delay2", parse(delay2, 8))
                .putInt("order2", order2Val)
                .putInt("modeNext", modeVal)
                .putInt("tgt1", parse(tgt1, 20))
                .putInt("tgt2", parse(tgt2, 97))
                .putInt("maxAlive4", parse(maxAliveEd, 24))
                .putBoolean("closeDone", swCloseDone.isChecked())
                .putBoolean("newOnly", swNewOnly.isChecked())
                .putBoolean("dropUnknown", swDropUnknown.isChecked())
                .putBoolean("autoCancel", swCancel.isChecked())
                .putInt("oldAllowed", parse(oldAllowedEd, 1))
                .putBoolean("panel", swPanel.isChecked())
                .putBoolean("dropDup", swDrop.isChecked())
                .putBoolean("reroll", swReroll.isChecked())
                .putInt("rerollMax", parse(rerollMaxEd, 3))
                .apply();
    }

    // ---------------- helpers ----------------

    private void open(Intent i) {
        try { startActivity(i); } catch (Exception e) {
            try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))); }
            catch (Exception ignored) {}
        }
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    private static int parse(EditText e, int def) {
        try { return Integer.parseInt(e.getText().toString().trim()); } catch (Exception x) { return def; }
    }

    private LinearLayout card(LinearLayout parent, String title) {
        LinearLayout c = Theme.card(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(12);
        parent.addView(c, lp);
        TextView t = text(title, 14, TEXT, true);
        t.setPadding(0, 0, 0, dp(6));
        c.addView(t);
        return c;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        return Theme.plain(this, s, sp, color, bold);
    }

    private EditText edit(String value, String hint, boolean number) {
        return Theme.input(this, value, hint, number);
    }

    private LinearLayout labeled(String label) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        TextView t = text(label, 12, MUTED, false);
        t.setPadding(0, 0, 0, dp(4));
        l.addView(t);
        return l;
    }

    private Button button(String s, View.OnClickListener l) {
        Button b = Theme.ghost(this, s, l);
        b.setPadding(dp(12), 0, dp(12), 0);
        return b;
    }

    private RadioButton radio(String s) {
        RadioButton r = new RadioButton(this);
        r.setText(s);
        r.setTextColor(TEXT);
        r.setTextSize(13);
        r.setButtonTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        return r;
    }

    private CheckBox check(String s, boolean on) {
        CheckBox c = new CheckBox(this);
        c.setText(s);
        c.setTextColor(TEXT);
        c.setTextSize(13);
        c.setChecked(on);
        c.setButtonTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        return c;
    }

    private LinearLayout hrow() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    private View space(int w) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(w), 1));
        return v;
    }

    private static LinearLayout.LayoutParams weight() { return new LinearLayout.LayoutParams(0, -2, 1f); }

    private GradientDrawable round(int color, int r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
